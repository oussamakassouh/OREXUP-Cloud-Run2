import { useState } from "react";
import { AdminLayout } from "@/components/admin-layout";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Dialog, DialogContent, DialogDescription,
  DialogFooter, DialogHeader, DialogTitle, DialogTrigger,
} from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import {
  ShieldOff, AlertOctagon, AlertTriangle, Globe, UserX,
  Activity, LogIn, LogOut, Settings, CreditCard, ShieldCheck,
  Laptop, Trash2, Lock,
  Power, Users, CheckCircle2, XCircle, AlertCircle, KeyRound, Eye, EyeOff,
} from "lucide-react";
import { useGetAdminSecurity } from "@workspace/api-client-react";
import { PeriodFilter, usePeriodFilter } from "@/components/period-filter";

const ACCESS_CODE_KEY = "orexup_admin_access_code";
const DEFAULT_ACCESS_CODE = "OREXUP-2026";

// ─── METRIC CARD CONFIG (values come from DB) ───────────────────────────────
const METRIC_CONFIG = [
  { key: "totalBlocks" as const,       label: "Total Blocks",        sub: "all time",     icon: ShieldOff,    color: "text-red-500",    bg: "bg-red-500/10" },
  { key: "criticalEvents" as const,    label: "Critical Events",     sub: "this week",    icon: AlertOctagon, color: "text-red-500",    bg: "bg-red-500/10" },
  { key: "highSeverity" as const,      label: "High Severity",       sub: "this month",   icon: AlertTriangle,color: "text-amber-500",  bg: "bg-amber-500/10" },
  { key: "vpnEvents" as const,         label: "VPN Events",          sub: "detected",     icon: Globe,        color: "text-purple-500", bg: "bg-purple-500/10" },
  { key: "failedLogins" as const,      label: "Failed Logins",       sub: "last 30 days", icon: UserX,        color: "text-rose-500",   bg: "bg-rose-500/10" },
  { key: "suspiciousActivity" as const,label: "Suspicious Activity", sub: "flagged",      icon: Activity,     color: "text-orange-500", bg: "bg-orange-500/10" },
];

// ─── ROLES (permission matrix is static config; user counts come from DB) ────
const ROLES = [
  { role: "Owner",   countKey: "owner" as const,   badge: "bg-primary/20 text-primary border-primary/30",      permissions: { users: false, payments: false, security: false, settings: false, analytics: false, support: false } },
  { role: "Admin",   countKey: "admin" as const,   badge: "bg-amber-500/20 text-amber-500 border-amber-500/30", permissions: { users: true, payments: true, security: true, settings: true, analytics: true, support: true } },
  { role: "Support", countKey: "support" as const, badge: "bg-blue-500/20 text-blue-500 border-blue-500/30",   permissions: { users: false, payments: false, security: false, settings: false, analytics: false, support: false } },
];

const PERMISSION_LABELS: Record<string, string> = {
  users: "Users", payments: "Payments", security: "Security",
  settings: "Settings", analytics: "Analytics", support: "Support",
};

// ─── SECURITY CONTROLS (static platform config) ─────────────────────────────
const SECURITY_CONTROLS = [
  { key: "rateLimit",    label: "Rate Limiting",          desc: "Cap requests per IP per minute to prevent flood attacks.",          default: true },
  { key: "ipMonitor",   label: "IP Monitoring",           desc: "Track and flag IPs with unusual request patterns.",                default: true },
  { key: "failLogin",   label: "Failed Login Detection",  desc: "Lock accounts after 5 consecutive failed attempts.",               default: true },
  { key: "vpnDetect",   label: "VPN / Proxy Detection",   desc: "Flag or block sessions originating from known VPN exit nodes.",    default: true },
  { key: "botProtect",  label: "Bot Protection",          desc: "Challenge or block automated traffic using heuristics.",           default: true },
  { key: "csrf",        label: "CSRF Protection",         desc: "Validate origin headers and enforce CSRF tokens on mutations.",    default: true },
  { key: "secureCookie",label: "Secure Cookies",          desc: "Set HttpOnly, Secure, and SameSite=Strict on all session cookies.",default: true },
];

const LOG_TYPES = ["All", "Login", "Logout", "Failed Login", "Settings Change", "Payment", "Admin Action"];

const LOG_ICONS: Record<string, typeof LogIn> = {
  "Login": LogIn,
  "Logout": LogOut,
  "Failed Login": UserX,
  "Settings Change": Settings,
  "Payment": CreditCard,
  "Admin Action": ShieldCheck,
};

function severityClass(sev: string) {
  switch (sev) {
    case "Critical": return "bg-red-500/20 text-red-500 border-red-500/30";
    case "High":     return "bg-amber-500/20 text-amber-500 border-amber-500/30";
    case "Medium":   return "bg-yellow-500/20 text-yellow-500 border-yellow-500/30";
    default:         return "bg-white/5 text-muted-foreground border-white/10";
  }
}

// ─── COMPONENT ───────────────────────────────────────────────────────────────
export default function AdminSecurityPage() {
  const { toast } = useToast();
  const { period, setPeriod, customFrom, setCustomFrom, customTo, setCustomTo, apply, queryParams } =
    usePeriodFilter("month");
  const { data, isLoading, isError } = useGetAdminSecurity(queryParams);

  const metrics = data?.metrics;
  const events = data?.events ?? [];
  const adminSessions = data?.adminSessions ?? [];
  const roleUserCounts = data?.roleUserCounts;

  const [revokedIds, setRevokedIds] = useState<string[]>([]);
  const sessions = adminSessions.filter((s) => !revokedIds.includes(s.id));

  const [autoLogout, setAutoLogout] = useState(true);
  const [sessionTimeout, setSessionTimeout] = useState("60");

  // Security controls state (static toggles)
  const [controls, setControls] = useState<Record<string, boolean>>(
    Object.fromEntries(SECURITY_CONTROLS.map((c) => [c.key, c.default]))
  );

  // Admin access code state
  const [accessCode, setAccessCode] = useState(
    () => localStorage.getItem(ACCESS_CODE_KEY) ?? DEFAULT_ACCESS_CODE
  );
  const [newCode, setNewCode] = useState("");
  const [confirmCode, setConfirmCode] = useState("");
  const [showCode, setShowCode] = useState(false);
  const [codeError, setCodeError] = useState("");

  // Logs state
  const [logType, setLogType] = useState("All");

  // Emergency dialogs
  const [forceLogoutOpen, setForceLogoutOpen] = useState(false);
  const [lockAdminOpen, setLockAdminOpen] = useState(false);
  const [disableEmail, setDisableEmail] = useState("");
  const [disableOpen, setDisableOpen] = useState(false);

  const notify = (title: string, description: string) => toast({ title, description });

  const revokeSession = (id: string) => {
    setRevokedIds((prev) => [...prev, id]);
    notify("Session Revoked", `Session ${id} has been terminated.`);
  };

  const filteredLogs = events.filter((l) => logType === "All" || l.type.toLowerCase() === logType.toLowerCase());
  const criticalEvents = events.filter((l) => l.severity === "Critical" || l.severity === "High").slice(0, 5);

  return (
    <AdminLayout title="Security Center">
      {isError && (
        <Card className="border-red-500/20 bg-red-500/5 mb-6">
          <CardContent className="py-4 text-sm text-red-400">Failed to load security data.</CardContent>
        </Card>
      )}

      <div className="mb-6">
        <PeriodFilter
          period={period} onPeriodChange={setPeriod}
          customFrom={customFrom} customTo={customTo}
          onCustomFromChange={setCustomFrom} onCustomToChange={setCustomTo}
          onApply={apply}
        />
      </div>

      <Tabs defaultValue="dashboard" className="w-full">
        <TabsList className="flex flex-wrap gap-1 h-auto mb-6 bg-black/20 p-1">
          <TabsTrigger value="dashboard">Dashboard</TabsTrigger>
          <TabsTrigger value="access">Access Control</TabsTrigger>
          <TabsTrigger value="sessions">Sessions</TabsTrigger>
          <TabsTrigger value="controls">Security Config</TabsTrigger>
          <TabsTrigger value="logs">Logs</TabsTrigger>
          <TabsTrigger value="emergency" className="text-red-400 data-[state=active]:text-red-400">Emergency</TabsTrigger>
        </TabsList>

        {/* ── DASHBOARD ── */}
        <TabsContent value="dashboard" className="space-y-6">
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            {METRIC_CONFIG.map((m) => (
              <Card key={m.label} className="border-white/5 bg-card/50">
                <CardContent className="p-5 flex items-center gap-4">
                  <div className={`p-3 rounded-xl ${m.bg} shrink-0`}>
                    <m.icon className={`h-5 w-5 ${m.color}`} />
                  </div>
                  <div>
                    <p className="text-2xl font-bold font-mono">{isLoading ? "—" : (metrics?.[m.key] ?? 0).toLocaleString()}</p>
                    <p className="text-xs text-muted-foreground mt-0.5">{m.label}</p>
                    <p className="text-[10px] text-muted-foreground/60">{m.sub}</p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          <Card className="border-white/5 bg-card/50">
            <CardHeader className="pb-3">
              <CardTitle className="text-base">Active Security Controls</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                {SECURITY_CONTROLS.map((c) => (
                  <div key={c.key} className="flex items-center gap-2 text-sm">
                    {controls[c.key]
                      ? <CheckCircle2 className="h-4 w-4 text-green-500 shrink-0" />
                      : <XCircle className="h-4 w-4 text-red-500 shrink-0" />}
                    <span className={controls[c.key] ? "" : "text-muted-foreground line-through"}>{c.label}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card className="border-white/5 bg-card/50">
            <CardHeader className="pb-3">
              <CardTitle className="text-base">Recent Critical Events</CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              {criticalEvents.length === 0 ? (
                <p className="text-center py-10 text-muted-foreground text-sm">
                  {isLoading ? "Loading…" : "No data available"}
                </p>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow className="border-white/5 hover:bg-transparent">
                      <TableHead>Time</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead>Actor</TableHead>
                      <TableHead>Severity</TableHead>
                      <TableHead>Details</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {criticalEvents.map((log) => (
                      <TableRow key={log.id} className="border-white/5 hover:bg-white/5">
                        <TableCell className="text-xs text-muted-foreground whitespace-nowrap">{log.time}</TableCell>
                        <TableCell className="text-sm font-medium">{log.type}</TableCell>
                        <TableCell className="text-xs font-mono">{log.actor}</TableCell>
                        <TableCell><Badge variant="outline" className={severityClass(log.severity)}>{log.severity}</Badge></TableCell>
                        <TableCell className="text-xs text-muted-foreground max-w-[200px] truncate">{log.details}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* ── ACCESS CONTROL ── */}
        <TabsContent value="access" className="space-y-6">
          <Card className="border-white/5 bg-card/50 max-w-3xl">
            <CardHeader>
              <CardTitle>Roles & Permissions</CardTitle>
              <CardDescription>Define what each role can access in the admin panel.</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow className="border-white/5 hover:bg-transparent">
                    <TableHead>Role</TableHead>
                    <TableHead className="text-center">Users</TableHead>
                    {Object.keys(PERMISSION_LABELS).map((k) => (
                      <TableHead key={k} className="text-center">{PERMISSION_LABELS[k]}</TableHead>
                    ))}
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {ROLES.map((r) => (
                    <TableRow key={r.role} className="border-white/5 hover:bg-white/5">
                      <TableCell>
                        <Badge variant="outline" className={r.badge}>{r.role}</Badge>
                      </TableCell>
                      <TableCell className="text-center text-sm text-muted-foreground">{roleUserCounts?.[r.countKey] ?? 0}</TableCell>
                      {Object.keys(PERMISSION_LABELS).map((k) => (
                        <TableCell key={k} className="text-center">
                          {r.permissions[k as keyof typeof r.permissions]
                            ? <CheckCircle2 className="h-4 w-4 text-green-500 mx-auto" />
                            : <XCircle className="h-4 w-4 text-muted-foreground/30 mx-auto" />}
                        </TableCell>
                      ))}
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>

          <Card className="border-white/5 bg-card/50 max-w-3xl">
            <CardHeader>
              <CardTitle>Password Policy</CardTitle>
              <CardDescription>Required for all admin accounts.</CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2.5">
                {[
                  "Minimum 12 characters",
                  "At least one uppercase letter (A–Z)",
                  "At least one lowercase letter (a–z)",
                  "At least one number (0–9)",
                  "At least one special character (!@#$%^&*)",
                  "Cannot reuse the last 5 passwords",
                  "Expires every 90 days",
                ].map((rule) => (
                  <li key={rule} className="flex items-center gap-2.5 text-sm">
                    <CheckCircle2 className="h-4 w-4 text-primary shrink-0" />
                    {rule}
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>
        </TabsContent>

        {/* ── SESSIONS ── */}
        <TabsContent value="sessions" className="space-y-6">
          <div className="grid md:grid-cols-2 gap-4 max-w-2xl">
            <Card className="border-white/5 bg-card/50">
              <CardContent className="p-5 flex items-center justify-between">
                <div>
                  <p className="font-medium text-sm">Auto Logout</p>
                  <p className="text-xs text-muted-foreground mt-0.5">Terminate idle sessions automatically</p>
                </div>
                <Switch checked={autoLogout} onCheckedChange={setAutoLogout} />
              </CardContent>
            </Card>
            <Card className="border-white/5 bg-card/50">
              <CardContent className="p-5 space-y-2">
                <Label className="text-sm">Session Timeout</Label>
                <Select value={sessionTimeout} onValueChange={setSessionTimeout}>
                  <SelectTrigger className="bg-black/20">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="15">15 minutes</SelectItem>
                    <SelectItem value="30">30 minutes</SelectItem>
                    <SelectItem value="60">60 minutes</SelectItem>
                    <SelectItem value="120">2 hours</SelectItem>
                  </SelectContent>
                </Select>
              </CardContent>
            </Card>
          </div>

          <Card className="border-white/5 bg-card/50">
            <CardHeader className="pb-3 flex flex-row items-center justify-between">
              <div>
                <CardTitle className="text-base">Active Admin Sessions</CardTitle>
                <CardDescription className="mt-0.5">Device tracking for all signed-in accounts.</CardDescription>
              </div>
              <Badge variant="outline" className="bg-green-500/10 text-green-500 border-green-500/20">
                {sessions.length} active
              </Badge>
            </CardHeader>
            <CardContent className="p-0">
              {sessions.length === 0 ? (
                <p className="text-center py-10 text-muted-foreground text-sm">
                  {isLoading ? "Loading…" : "No data available"}
                </p>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow className="border-white/5 hover:bg-transparent">
                      <TableHead>User</TableHead>
                      <TableHead>Role</TableHead>
                      <TableHead>Device</TableHead>
                      <TableHead>IP / Location</TableHead>
                      <TableHead>Started</TableHead>
                      <TableHead className="text-right">Action</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {sessions.map((s) => (
                      <TableRow key={s.id} className="border-white/5 hover:bg-white/5">
                        <TableCell className="font-mono text-xs">{s.user}</TableCell>
                        <TableCell>
                          <Badge variant="outline" className="text-xs">
                            {s.role}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-1.5 text-sm">
                            <Laptop className="h-3.5 w-3.5 text-muted-foreground" />
                            <span>{s.device}</span>
                          </div>
                        </TableCell>
                        <TableCell className="text-xs text-muted-foreground">
                          <span className="font-mono">{s.ip}</span>
                          <br />{s.location}
                        </TableCell>
                        <TableCell className="text-xs text-muted-foreground whitespace-nowrap">{s.started}</TableCell>
                        <TableCell className="text-right">
                          <Button
                            size="sm"
                            variant="ghost"
                            className="h-7 px-2 text-red-500 hover:text-red-400 hover:bg-red-500/10"
                            onClick={() => revokeSession(s.id)}
                          >
                            <Trash2 className="h-3.5 w-3.5 mr-1" />
                            Revoke
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* ── SECURITY CONFIG ── */}
        <TabsContent value="controls" className="space-y-4 max-w-2xl">
          <Card className="border-white/5 bg-card/50">
            <CardHeader>
              <CardTitle>Security Controls</CardTitle>
              <CardDescription>Enable or disable platform-wide protection layers.</CardDescription>
            </CardHeader>
            <CardContent className="divide-y divide-white/5">
              {SECURITY_CONTROLS.map((c) => (
                <div key={c.key} className="flex items-start justify-between py-4 first:pt-0 last:pb-0 gap-4">
                  <div className="space-y-0.5">
                    <div className="flex items-center gap-2">
                      <Label className="text-sm font-medium">{c.label}</Label>
                      {controls[c.key]
                        ? <Badge className="h-4 px-1.5 text-[10px] bg-green-500/20 text-green-400 border-0">ON</Badge>
                        : <Badge className="h-4 px-1.5 text-[10px] bg-red-500/20 text-red-400 border-0">OFF</Badge>}
                    </div>
                    <p className="text-xs text-muted-foreground max-w-sm">{c.desc}</p>
                  </div>
                  <Switch
                    checked={controls[c.key]}
                    onCheckedChange={(v) => {
                      setControls((prev) => ({ ...prev, [c.key]: v }));
                      notify(c.label, `${c.label} has been ${v ? "enabled" : "disabled"}.`);
                    }}
                  />
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Admin Access Code Manager */}
          <Card className="border-white/5 bg-card/50">
            <CardHeader>
              <div className="flex items-center gap-2">
                <KeyRound className="h-4 w-4 text-primary" />
                <CardTitle className="text-base">Admin Access Code</CardTitle>
              </div>
              <CardDescription>
                This code is required on the first step of the admin login. Keep it secret.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Current code (masked) */}
              <div className="space-y-1.5">
                <Label className="text-xs text-muted-foreground uppercase tracking-widest">Current Code</Label>
                <div className="flex items-center gap-2">
                  <div className="flex-1 flex items-center gap-2 bg-black/30 border border-white/10 rounded-lg px-4 py-2.5 font-mono text-sm tracking-widest">
                    {showCode ? accessCode : "•".repeat(accessCode.length)}
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-9 w-9 shrink-0 text-muted-foreground hover:text-foreground"
                    onClick={() => setShowCode((s) => !s)}
                  >
                    {showCode ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </Button>
                </div>
              </div>

              <div className="border-t border-white/5 pt-4 space-y-3">
                <Label className="text-xs text-muted-foreground uppercase tracking-widest">Change Code</Label>
                <Input
                  placeholder="New access code"
                  value={newCode}
                  onChange={(e) => { setNewCode(e.target.value); setCodeError(""); }}
                  className="bg-black/20 font-mono tracking-widest"
                />
                <Input
                  placeholder="Confirm new access code"
                  value={confirmCode}
                  onChange={(e) => { setConfirmCode(e.target.value); setCodeError(""); }}
                  className="bg-black/20 font-mono tracking-widest"
                />
                {codeError && (
                  <p className="text-xs text-red-500 flex items-center gap-1.5">
                    <AlertCircle className="h-3.5 w-3.5" /> {codeError}
                  </p>
                )}
                <Button
                  className="w-full"
                  disabled={!newCode || !confirmCode}
                  onClick={() => {
                    if (newCode.length < 6) {
                      setCodeError("Code must be at least 6 characters.");
                      return;
                    }
                    if (newCode !== confirmCode) {
                      setCodeError("Codes do not match.");
                      return;
                    }
                    localStorage.setItem(ACCESS_CODE_KEY, newCode);
                    setAccessCode(newCode);
                    setNewCode("");
                    setConfirmCode("");
                    setCodeError("");
                    notify("Access Code Updated", "The admin access code has been changed successfully.");
                  }}
                >
                  Save New Code
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card className="border-white/5 bg-card/50">
            <CardHeader>
              <CardTitle className="text-base">Secrets Policy</CardTitle>
              <CardDescription>These values must never be exposed publicly.</CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2">
                {["API Keys", "Database Credentials", "Environment Variables"].map((s) => (
                  <li key={s} className="flex items-center gap-2 text-sm">
                    <AlertCircle className="h-4 w-4 text-red-500 shrink-0" />
                    <span>{s} — <span className="text-muted-foreground">never expose in logs, responses, or client code</span></span>
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>
        </TabsContent>

        {/* ── LOGS ── */}
        <TabsContent value="logs" className="space-y-4">
          <Card className="border-white/5 bg-card/50">
            <div className="p-4 border-b border-white/5 flex flex-wrap items-center justify-between gap-3">
              <h3 className="font-semibold font-heading">Activity Logs</h3>
              <Select value={logType} onValueChange={setLogType}>
                <SelectTrigger className="w-[180px] h-8 bg-black/20">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {LOG_TYPES.map((t) => (
                    <SelectItem key={t} value={t}>{t}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <Table>
              <TableHeader>
                <TableRow className="border-white/5 hover:bg-transparent">
                  <TableHead>Timestamp</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Actor</TableHead>
                  <TableHead>Target</TableHead>
                  <TableHead>Severity</TableHead>
                  <TableHead>Details</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredLogs.map((log) => {
                  const Icon = LOG_ICONS[log.type] ?? Activity;
                  return (
                    <TableRow key={log.id} className="border-white/5 hover:bg-white/5">
                      <TableCell className="text-xs text-muted-foreground whitespace-nowrap">{log.time}</TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1.5 text-sm font-medium">
                          <Icon className="h-3.5 w-3.5 text-muted-foreground" />
                          {log.type}
                        </div>
                      </TableCell>
                      <TableCell className="font-mono text-xs">{log.actor}</TableCell>
                      <TableCell className="text-xs text-muted-foreground">{log.target}</TableCell>
                      <TableCell>
                        <Badge variant="outline" className={severityClass(log.severity)}>{log.severity}</Badge>
                      </TableCell>
                      <TableCell className="text-xs text-muted-foreground max-w-[220px] truncate" title={log.details}>
                        {log.details}
                      </TableCell>
                    </TableRow>
                  );
                })}
                {filteredLogs.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center py-10 text-muted-foreground">
                      {isLoading ? "Loading…" : "No data available"}
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </Card>
        </TabsContent>

        {/* ── EMERGENCY ── */}
        <TabsContent value="emergency" className="space-y-6 max-w-2xl">
          <div className="rounded-xl border border-red-500/20 bg-red-500/5 p-4 flex items-start gap-3">
            <AlertOctagon className="h-5 w-5 text-red-500 shrink-0 mt-0.5" />
            <p className="text-sm text-muted-foreground">
              These actions are <strong className="text-foreground">irreversible during the session</strong>. Use only in response to a confirmed security incident.
            </p>
          </div>

          <div className="grid gap-4">
            {/* Force Logout All */}
            <Card className="border-red-500/20 bg-card/50">
              <CardContent className="p-5 flex items-center justify-between gap-4">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <Power className="h-4 w-4 text-red-500" />
                    <p className="font-semibold text-sm">Force Logout All</p>
                  </div>
                  <p className="text-xs text-muted-foreground">Immediately terminate every active admin session including your own.</p>
                </div>
                <Dialog open={forceLogoutOpen} onOpenChange={setForceLogoutOpen}>
                  <DialogTrigger asChild>
                    <Button variant="destructive" size="sm">Force Logout All</Button>
                  </DialogTrigger>
                  <DialogContent className="bg-[#0a0f16] border-white/10">
                    <DialogHeader>
                      <DialogTitle className="text-red-500">Confirm: Force Logout All</DialogTitle>
                      <DialogDescription>This will immediately end every admin session. You will be signed out.</DialogDescription>
                    </DialogHeader>
                    <DialogFooter>
                      <Button variant="ghost" onClick={() => setForceLogoutOpen(false)}>Cancel</Button>
                      <Button variant="destructive" onClick={() => {
                        setRevokedIds(adminSessions.map((s) => s.id));
                        setForceLogoutOpen(false);
                        notify("Force Logout Executed", "All admin sessions have been terminated.");
                      }}>
                        Confirm
                      </Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>
              </CardContent>
            </Card>

            {/* Disable Account */}
            <Card className="border-amber-500/20 bg-card/50">
              <CardContent className="p-5 flex items-center justify-between gap-4">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <UserX className="h-4 w-4 text-amber-500" />
                    <p className="font-semibold text-sm">Disable Account</p>
                  </div>
                  <p className="text-xs text-muted-foreground">Suspend an admin account by email. They will be unable to sign in.</p>
                </div>
                <Dialog open={disableOpen} onOpenChange={setDisableOpen}>
                  <DialogTrigger asChild>
                    <Button variant="outline" size="sm" className="border-amber-500/40 text-amber-500 hover:bg-amber-500/10">
                      Disable Account
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="bg-[#0a0f16] border-white/10">
                    <DialogHeader>
                      <DialogTitle className="text-amber-500">Disable Admin Account</DialogTitle>
                      <DialogDescription>Enter the email address of the account to disable.</DialogDescription>
                    </DialogHeader>
                    <div className="py-3">
                      <Input
                        placeholder="admin@example.com"
                        value={disableEmail}
                        onChange={(e) => setDisableEmail(e.target.value)}
                        className="bg-black/20"
                      />
                    </div>
                    <DialogFooter>
                      <Button variant="ghost" onClick={() => setDisableOpen(false)}>Cancel</Button>
                      <Button
                        className="bg-amber-600 hover:bg-amber-700 text-white"
                        disabled={!disableEmail}
                        onClick={() => {
                          setDisableOpen(false);
                          setDisableEmail("");
                          notify("Account Disabled", `${disableEmail} has been suspended.`);
                        }}
                      >
                        Confirm Disable
                      </Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>
              </CardContent>
            </Card>

            {/* Lock Admin Access */}
            <Card className="border-red-500/20 bg-card/50">
              <CardContent className="p-5 flex items-center justify-between gap-4">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <Lock className="h-4 w-4 text-red-500" />
                    <p className="font-semibold text-sm">Lock Admin Access</p>
                  </div>
                  <p className="text-xs text-muted-foreground">Completely block the admin panel. Only the Owner can unlock it via a recovery key.</p>
                </div>
                <Dialog open={lockAdminOpen} onOpenChange={setLockAdminOpen}>
                  <DialogTrigger asChild>
                    <Button variant="destructive" size="sm">Lock Admin Access</Button>
                  </DialogTrigger>
                  <DialogContent className="bg-[#0a0f16] border-white/10">
                    <DialogHeader>
                      <DialogTitle className="text-red-500">Confirm: Lock Admin Access</DialogTitle>
                      <DialogDescription>
                        The admin panel will be inaccessible to everyone until manually unlocked. Type <strong>LOCK</strong> to confirm.
                      </DialogDescription>
                    </DialogHeader>
                    <LockConfirm onConfirm={() => {
                      setLockAdminOpen(false);
                      notify("Admin Panel Locked", "Access has been suspended. Recovery key required.");
                    }} onCancel={() => setLockAdminOpen(false)} />
                  </DialogContent>
                </Dialog>
              </CardContent>
            </Card>
          </div>

          <Card className="border-white/5 bg-card/50">
            <CardHeader className="pb-3">
              <div className="flex items-center gap-2">
                <Users className="h-4 w-4 text-muted-foreground" />
                <CardTitle className="text-sm">Admin Access URL</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <p className="font-mono text-sm bg-black/30 rounded-lg px-4 py-3 border border-white/5 text-primary select-all">
                orexup.com/administrator/login
              </p>
              <p className="text-xs text-muted-foreground mt-2 flex items-center gap-1.5">
                <AlertCircle className="h-3 w-3" />
                Do not share or expose this URL publicly.
              </p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </AdminLayout>
  );
}

function LockConfirm({ onConfirm, onCancel }: { onConfirm: () => void; onCancel: () => void }) {
  const [val, setVal] = useState("");
  return (
    <>
      <div className="py-3">
        <Input
          placeholder="Type LOCK"
          value={val}
          onChange={(e) => setVal(e.target.value)}
          className="bg-black/20"
        />
      </div>
      <DialogFooter>
        <Button variant="ghost" onClick={onCancel}>Cancel</Button>
        <Button variant="destructive" disabled={val !== "LOCK"} onClick={onConfirm}>
          Lock Admin Access
        </Button>
      </DialogFooter>
    </>
  );
}

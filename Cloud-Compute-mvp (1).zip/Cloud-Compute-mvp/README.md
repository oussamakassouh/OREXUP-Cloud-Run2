OREXUP

Cloud Performance Platform for Browser Workloads

Overview

OREXUP is a cloud platform designed to help users run demanding browser workloads through connected cloud performance sessions.

Users connect their browser to OREXUP Cloud and access optimized performance environments without upgrading their physical device.

⸻

Features

Browser Extension

* Connect OREXUP Cloud
* Start / Stop Sessions
* Browser Metrics
* Session Status

user Dashboard

* Cloud Connection
* Analytics
* Billing
* Profile
* Settings
* Support

Admin Panel

* Overview
* Traffic
* Analytics
* Payments
* Security
* add team
* Support Tickets
* Content Management
* setting

Security

* Email Verification
* Admin Access Code
* Two-Factor Authentication
* Session Management
* Device Validation

⸻

Pricing

Starter

$9/month
or
$99/year

120 hours / month

Premium

$29/month
or
$299/year

240 hours / month

Ultimate

$49/month
or
$499/year

Unlimited usage time

⸻

User Flow

Create Account

↓

Verify Email

↓

Sign In

↓

Connect OREXUP Cloud

↓

Start Session

↓

Track Metrics

⸻

Admin Flow

Admin Access Code

↓

 Password

↓

Verify Email

↓

Access Dashboard

⸻

Tech Stack

Frontend:
React
TypeScript

Extension:
Chrome Extension (Manifest V3)

Backend:
API Architecture

Database:
Cloud Database

Deployment:
GitHub
Vercel

⸻

Project Structure

/frontend

/dashboard

/admin

/extension

/backend

/public

/docs

⸻

Current Status

Beta Development

⸻

Vision

Build a platform where browser users can access flexible cloud performance environments through a simple connected experience.

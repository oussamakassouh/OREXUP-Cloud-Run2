import { Router, type IRouter, type Request, type Response, type NextFunction } from "express";
import healthRouter from "./health";
import adminRouter from "./admin";
import adminSessionRouter from "./adminSession";
import partnersRouter from "./partners";
import twoFactorRouter from "./twofa";
import contentRouter from "./content";
import publicContentRouter from "./publicContent";
import cloudRouter from "./cloud";
import billingRouter from "./billing";
import userAuthRouter from "./userAuth";
import userProfileRouter from "./userProfile";
import paymentRouter from "./payment";
import extensionRouter from "./extension";
import cloudV2Router from "./cloudV2";
import analyticsRouter from "./analytics";
import supportRouter from "./support";
import notificationRouter from "./notification";
import userSecurityRouter from "./userSecurity";
import docsRouter from "./docs";
import { adminAuth } from "../middlewares/adminAuth";
import { authLimiter } from "../middlewares/rateLimiter";

const router: IRouter = Router();

// ── API docs ──────────────────────────────────────────────────────────────────
router.use(docsRouter);

// ── Public routes ─────────────────────────────────────────────────────────────
router.use(healthRouter);
router.use(cloudRouter);         // /connect /session/*  /metrics  (legacy browser-SDK paths)
router.use(cloudV2Router);       // /cloud/*
router.use(extensionRouter);     // /extension/*
router.use(publicContentRouter); // /public/*
router.use(billingRouter);       // /billing/*
router.use(supportRouter);       // POST /support/ticket is public; GET/POST /support/tickets,reply use inline userAuth

// ── Auth routes — rate limited ────────────────────────────────────────────────
router.use(authLimiter, adminSessionRouter);
router.use(authLimiter, userAuthRouter);

// ── User-authenticated routes ─────────────────────────────────────────────────
router.use(userProfileRouter);   // /user/*
router.use(paymentRouter);       // /payment/*
router.use(analyticsRouter);     // /analytics/*
router.use(userSecurityRouter);  // /security/*

// ── Admin path aliases (rewrite before hitting admin routers) ─────────────────
router.use((req: Request, _res: Response, next: NextFunction) => {
  if (req.path === "/admin/dashboard") req.url = req.url.replace("/admin/dashboard", "/admin/overview");
  if (req.path === "/admin/tickets")   req.url = req.url.replace("/admin/tickets",   "/admin/support");
  next();
});

// ── Notification (admin-protected inline) ────────────────────────────────────
router.use(notificationRouter);  // /notification/* — adminAuth applied inline per route

// ── Admin-protected routes ────────────────────────────────────────────────────
router.use(adminAuth, adminRouter);
router.use(adminAuth, partnersRouter);
router.use(adminAuth, twoFactorRouter);
router.use(adminAuth, contentRouter);

export default router;

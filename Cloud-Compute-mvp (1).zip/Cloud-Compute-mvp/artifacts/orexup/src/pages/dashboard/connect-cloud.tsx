import { useState, useEffect, useRef } from "react";
import { DashboardLayout } from "@/components/dashboard-layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Cpu, Zap, Monitor, Database, Activity, Play, Square, Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useAppContext } from "@/lib/app-context";
import { cloudApi } from "@/lib/cloud-api";
import type { Profile } from "@/lib/app-context";

const performanceModes: { id: Profile; name: string; icon: typeof Cpu; desc: string; color: string }[] = [
  { id: "balanced", name: "Balanced",    icon: Cpu,      desc: "General workloads",   color: "text-blue-400" },
  { id: "cpu",      name: "High CPU",    icon: Zap,      desc: "Intensive tasks",      color: "text-amber-400" },
  { id: "gpu",      name: "High GPU",    icon: Monitor,  desc: "Graphics & rendering", color: "text-purple-400" },
  { id: "memory",   name: "High Memory", icon: Database, desc: "Large data sets",      color: "text-green-400" },
];

export default function ConnectCloudPage() {
  const {
    cloudConnected, setCloudConnected,
    sessionRunning, setSessionRunning,
    currentProfile, setCurrentProfile,
    setCloudToken, setActiveSessionId,
    cloudRegion, setCloudRegion,
  } = useAppContext();

  const [email, setEmail] = useState("");
  const [elapsed, setElapsed] = useState(0);
  const [connecting, setConnecting] = useState(false);
  const [startingSession, setStartingSession] = useState(false);
  const [latency, setLatency] = useState<number | null>(null);
  const { toast } = useToast();
  const pingRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    let interval: ReturnType<typeof setInterval>;
    if (sessionRunning) interval = setInterval(() => setElapsed((p) => p + 1), 1000);
    else setElapsed(0);
    return () => clearInterval(interval);
  }, [sessionRunning]);

  useEffect(() => {
    if (!cloudConnected) { setLatency(null); return; }
    const ping = async () => {
      const t0 = Date.now();
      try { await cloudApi.sessionStatus(); setLatency(Date.now() - t0); }
      catch { setLatency(null); }
    };
    ping();
    pingRef.current = setInterval(ping, 5000);
    return () => { if (pingRef.current) clearInterval(pingRef.current); };
  }, [cloudConnected]);

  const fmt = (s: number) => {
    const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), sec = s % 60;
    return `${String(h).padStart(2,"0")}:${String(m).padStart(2,"0")}:${String(sec).padStart(2,"0")}`;
  };

  const handleConnect = async () => {
    if (!email || !email.includes("@")) {
      toast({ title: "Email required", description: "Enter your account email.", variant: "destructive" });
      return;
    }
    setConnecting(true);
    try {
      const res = await cloudApi.connect(email, currentProfile);
      cloudApi.saveToken(res.token);
      setCloudToken(res.token);
      setCloudRegion(res.region);
      setCloudConnected(true);
      toast({ title: "Cloud Connected", description: `Connected to ${res.region}. Token issued.` });
    } catch (e) {
      toast({ title: "Connection failed", description: (e as Error).message, variant: "destructive" });
    } finally {
      setConnecting(false);
    }
  };

  const handleDisconnect = () => {
    if (sessionRunning) {
      toast({ title: "Cannot disconnect", description: "Stop the active session first.", variant: "destructive" });
      return;
    }
    cloudApi.clearToken();
    setCloudToken(null);
    setCloudConnected(false);
    toast({ title: "Cloud Disconnected", description: "Connection terminated safely." });
  };

  const handleStartSession = async () => {
    setStartingSession(true);
    try {
      const session = await cloudApi.sessionStart(currentProfile);
      setActiveSessionId(session.sessionId);
      setSessionRunning(true);
      toast({ title: "Session Started", description: `Session #${session.sessionId} running in ${session.profile} mode.` });
    } catch (e) {
      toast({ title: "Session start failed", description: (e as Error).message, variant: "destructive" });
    } finally {
      setStartingSession(false);
    }
  };

  const handleStopSession = async () => {
    try {
      const session = await cloudApi.sessionStop();
      setActiveSessionId(null);
      setSessionRunning(false);
      toast({ title: "Session Stopped", description: `Session #${session.sessionId} ended after ${session.durationSeconds}s.` });
    } catch (e) {
      toast({ title: "Stop failed", description: (e as Error).message, variant: "destructive" });
    }
  };

  return (
    <DashboardLayout title="Connect Cloud">
      <div className="space-y-8 max-w-4xl mx-auto">
        <div className="flex flex-col md:flex-row gap-8 items-start">

          <div className="w-full md:w-1/3 space-y-6">
            <Card className={`border-white/5 overflow-hidden transition-all duration-500 ${
              cloudConnected ? "bg-primary/5 border-primary/20 shadow-[0_0_30px_-10px_rgba(var(--primary),0.2)]" : "bg-card/50"
            }`}>
              <CardContent className="pt-8 pb-8 flex flex-col items-center justify-center text-center">
                <div className="relative mb-6">
                  <div className={`absolute inset-0 rounded-full blur-xl transition-all duration-1000 ${cloudConnected ? "bg-primary/40 animate-pulse" : "bg-white/5"}`} />
                  <div className={`h-24 w-24 rounded-full border-2 flex items-center justify-center relative z-10 transition-all duration-500 ${
                    cloudConnected ? "border-primary bg-primary/10 text-primary" : "border-white/10 bg-white/5 text-muted-foreground"
                  }`}>
                    <Activity className={`h-10 w-10 ${cloudConnected ? "animate-pulse" : ""}`} />
                  </div>
                </div>
                <h2 className="text-2xl font-bold font-heading mb-1">{cloudConnected ? "Connected" : "Disconnected"}</h2>
                {cloudConnected && <p className="text-xs text-primary/70 font-mono mb-1">{cloudRegion}</p>}
                <p className="text-sm text-muted-foreground mb-6">
                  {cloudConnected ? "Secure connection established" : "No active connection to OREXUP Cloud"}
                </p>
                {!cloudConnected && (
                  <div className="w-full space-y-2 mb-4 text-left">
                    <Label htmlFor="cloud-email" className="text-xs">Account Email</Label>
                    <Input id="cloud-email" type="email" placeholder="you@company.com"
                      value={email} onChange={(e) => setEmail(e.target.value)}
                      className="bg-black/30 text-sm" />
                  </div>
                )}
                <Button size="lg" className={`w-full ${cloudConnected ? "bg-white/10 text-white hover:bg-white/20" : ""}`}
                  onClick={cloudConnected ? handleDisconnect : handleConnect}
                  variant={cloudConnected ? "outline" : "default"}
                  disabled={connecting} data-testid="button-toggle-connection">
                  {connecting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  {cloudConnected ? "Disconnect" : "Connect OREXUP Cloud"}
                </Button>
              </CardContent>
            </Card>

            <Card className="border-white/5 bg-card/50">
              <CardHeader><CardTitle className="text-lg">Session Controls</CardTitle></CardHeader>
              <CardContent className="space-y-4">
                <div className="p-4 bg-black/40 rounded-lg font-mono text-3xl text-center tracking-wider text-primary border border-white/5">
                  {fmt(elapsed)}
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <Button onClick={handleStartSession} disabled={!cloudConnected || sessionRunning || startingSession}
                    className="w-full bg-green-600 hover:bg-green-700 text-white" data-testid="button-start-session">
                    {startingSession ? <Loader2 className="h-4 w-4 animate-spin" /> : <><Play className="mr-2 h-4 w-4" />Start</>}
                  </Button>
                  <Button onClick={handleStopSession} disabled={!sessionRunning} variant="destructive" className="w-full" data-testid="button-stop-session">
                    <Square className="mr-2 h-4 w-4" /> Stop
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="w-full md:w-2/3 space-y-6">
            <div>
              <h3 className="text-xl font-semibold font-heading">Performance Mode</h3>
              <p className="text-sm text-muted-foreground mt-1">Select the resource profile for your session. Changes apply on restart.</p>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {performanceModes.map((m) => (
                <div key={m.id} onClick={() => !sessionRunning && setCurrentProfile(m.id)}
                  className={`p-5 rounded-xl border transition-all duration-200 cursor-pointer ${
                    currentProfile === m.id ? "border-primary bg-primary/5 shadow-[0_0_20px_-10px_rgba(var(--primary),0.3)]" : "border-white/5 bg-card/50 hover:bg-white/5"
                  } ${sessionRunning ? "opacity-50 cursor-not-allowed" : ""}`}
                  data-testid={`mode-select-${m.id}`}>
                  <m.icon className={`h-8 w-8 mb-4 ${currentProfile === m.id ? "text-primary" : m.color}`} />
                  <h4 className="font-semibold text-lg mb-1">{m.name}</h4>
                  <p className="text-sm text-muted-foreground">{m.desc}</p>
                </div>
              ))}
            </div>

            <Card className="border-white/5 bg-card/50">
              <CardHeader><CardTitle className="text-lg">Network Diagnostics</CardTitle></CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span className="text-muted-foreground">API Round-trip</span>
                    <span className="font-mono">{cloudConnected && latency !== null ? `${latency}ms` : "--"}</span>
                  </div>
                  <div className="h-2 bg-white/5 rounded-full overflow-hidden">
                    <div className="h-full bg-green-500 transition-all duration-1000"
                      style={{ width: cloudConnected && latency !== null ? `${Math.min(100, (latency / 300) * 100)}%` : "0%" }} />
                  </div>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Region</span>
                  <span className="font-mono text-xs">{cloudConnected ? cloudRegion : "--"}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Connection Status</span>
                  <span className={`font-mono text-xs ${cloudConnected ? "text-green-400" : "text-muted-foreground"}`}>
                    {cloudConnected ? "● Active" : "○ None"}
                  </span>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}

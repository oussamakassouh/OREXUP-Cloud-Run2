import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import {
  ShieldCheck, Lock, CheckCircle2, XCircle,
  Loader2, Smartphone, RefreshCw, Eye, EyeOff, KeyRound,
} from "lucide-react";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import {
  Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Form, FormControl, FormField, FormItem, FormLabel, FormMessage,
} from "@/components/ui/form";
import { InputOTP, InputOTPGroup, InputOTPSlot } from "@/components/ui/input-otp";
import { Badge } from "@/components/ui/badge";

const API_BASE = "/api";

type Mode = "loading" | "setup" | "totp" | "password" | "granted";

const PASSWORD_RULES = [
  { label: "At least 12 characters",        test: (p: string) => p.length >= 12 },
  { label: "One uppercase letter (A–Z)",    test: (p: string) => /[A-Z]/.test(p) },
  { label: "One lowercase letter (a–z)",    test: (p: string) => /[a-z]/.test(p) },
  { label: "One number (0–9)",              test: (p: string) => /[0-9]/.test(p) },
  { label: "One special character (!@#$…)", test: (p: string) => /[^A-Za-z0-9]/.test(p) },
];

const passwordSchema = z.object({
  password: z.string().min(1, { message: "Password is required" }),
});

const STEP_LABELS = ["Authenticator", "Credentials", "Access"];

export default function AdminLoginPage() {
  const [, setLocation] = useLocation();

  const [mode, setMode]             = useState<Mode>("loading");
  const [qrDataUrl, setQrDataUrl]   = useState("");
  const [setupSecret, setSetupSecret] = useState("");
  const [totpToken, setTotpToken]   = useState("");
  const [nonce, setNonce]           = useState("");
  const [error, setError]           = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [initLoading, setInitLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  const form = useForm<z.infer<typeof passwordSchema>>({
    resolver: zodResolver(passwordSchema),
    defaultValues: { password: "" },
  });
  const passwordVal = form.watch("password");
  const passedRules = PASSWORD_RULES.filter((r) => r.test(passwordVal ?? "")).length;
  const strengthPct = (passedRules / PASSWORD_RULES.length) * 100;
  const strengthColor =
    passedRules <= 1 ? "bg-red-500" :
    passedRules <= 3 ? "bg-amber-500" :
    passedRules === 4 ? "bg-yellow-400" : "bg-green-500";

  const stepIndex =
    mode === "loading" ? 0 :
    mode === "setup" || mode === "totp" ? 1 :
    mode === "password" ? 2 : 3;

  useEffect(() => {
    (async () => {
      try {
        const res = await fetch(`${API_BASE}/admin/auth-status`, { credentials: "include" });
        const data = (await res.json()) as { hasTwoFactor: boolean };
        if (data.hasTwoFactor) { setMode("totp"); }
        else { await triggerInit(); }
      } catch {
        setError("Could not reach the server. Please refresh.");
        setMode("totp");
      }
    })();
  }, []);

  async function triggerInit() {
    setInitLoading(true); setError("");
    try {
      const res = await fetch(`${API_BASE}/admin/2fa/init`, { method: "POST", credentials: "include" });
      const data = (await res.json()) as { qrCodeDataUrl?: string; secret?: string; error?: string };
      if (!res.ok) { setError(data.error ?? "Setup failed. Please refresh."); }
      else { setQrDataUrl(data.qrCodeDataUrl ?? ""); setSetupSecret(data.secret ?? ""); setMode("setup"); }
    } catch { setError("Connection error. Please refresh."); setMode("setup"); }
    finally { setInitLoading(false); }
  }

  async function handleConfirmSetup() {
    if (totpToken.length !== 6) return;
    setSubmitting(true); setError("");
    try {
      const res = await fetch(`${API_BASE}/admin/2fa/confirm`, {
        method: "POST", headers: { "Content-Type": "application/json" }, credentials: "include",
        body: JSON.stringify({ token: totpToken }),
      });
      const data = (await res.json()) as { ok?: boolean; nonce?: string; error?: string };
      if (res.ok && data.ok && data.nonce) { setNonce(data.nonce); setTotpToken(""); setMode("password"); }
      else { setError(data.error ?? "Invalid code."); setTotpToken(""); }
    } catch { setError("Connection error. Please try again."); }
    finally { setSubmitting(false); }
  }

  async function handleVerifyTotp() {
    if (totpToken.length !== 6) return;
    setSubmitting(true); setError("");
    try {
      const res = await fetch(`${API_BASE}/admin/session`, {
        method: "POST", headers: { "Content-Type": "application/json" }, credentials: "include",
        body: JSON.stringify({ token: totpToken }),
      });
      const data = (await res.json()) as { ok?: boolean; nonce?: string; error?: string };
      if (res.ok && data.ok && data.nonce) { setNonce(data.nonce); setTotpToken(""); setMode("password"); }
      else { setError(data.error ?? "Invalid code. Codes refresh every 30 s."); setTotpToken(""); }
    } catch { setError("Connection error. Please try again."); }
    finally { setSubmitting(false); }
  }

  async function handlePassword(values: z.infer<typeof passwordSchema>) {
    setSubmitting(true); setError("");
    try {
      const res = await fetch(`${API_BASE}/admin/verify-password`, {
        method: "POST", headers: { "Content-Type": "application/json" }, credentials: "include",
        body: JSON.stringify({ password: values.password, nonce }),
      });
      const data = (await res.json()) as { ok?: boolean; error?: string };
      if (res.ok && data.ok) {
        setMode("granted");
        setTimeout(() => { setLocation("/administrator/overview"); }, 1400);
      } else {
        if (data.error?.toLowerCase().includes("password")) form.setError("password", { message: data.error });
        else setError(data.error ?? "Verification failed.");
      }
    } catch { setError("Connection error. Please try again."); }
    finally { setSubmitting(false); }
  }

  const title: Record<Mode, string> = {
    loading:  "Checking status…",
    setup:    "Set Up Authenticator",
    totp:     "Admin Sign In",
    password: "Verify Credentials",
    granted:  "Access Granted",
  };
  const description: Record<Mode, string> = {
    loading:  "Please wait.",
    setup:    "Scan the QR code with Google Authenticator or Authy, then enter the 6-digit code.",
    totp:     "This area is restricted to authorised administrators only. All access is logged and monitored.",
    password: "Enter your admin password to complete sign-in.",
    granted:  "Redirecting to the admin dashboard…",
  };

  return (
    <div className="min-h-screen bg-[#05080c] flex items-center justify-center p-4 relative overflow-hidden">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-primary/10 via-background to-background pointer-events-none" />
      <div className="absolute top-8 left-8 flex items-center gap-2 pointer-events-none opacity-50">
        <ShieldCheck className="h-6 w-6 text-primary" />
        <span className="font-heading font-bold text-xl tracking-tighter text-white">OREXUP</span>
      </div>

      <Card className="w-full max-w-md bg-card/60 backdrop-blur-xl border-white/10 shadow-2xl relative z-10">
        <CardHeader className="space-y-4 pb-6">
          <div className="flex justify-between items-start">
            <Badge className="bg-red-500/20 text-red-500 border-red-500/30 font-semibold px-3 py-1">Admin Access</Badge>
            {mode !== "loading" && mode !== "granted" && (
              <div className="flex items-center gap-1 text-xs font-medium text-muted-foreground">
                {STEP_LABELS.map((label, idx) => (
                  <span key={label} className="flex items-center gap-1">
                    <span className={`w-5 h-5 rounded-full text-[10px] flex items-center justify-center border transition-colors ${
                      idx + 1 < stepIndex ? "bg-primary border-primary text-white" :
                      idx + 1 === stepIndex ? "border-primary text-primary" :
                      "border-muted-foreground/30 text-muted-foreground/30"}`}>
                      {idx + 1 < stepIndex ? "✓" : idx + 1}
                    </span>
                    {idx < STEP_LABELS.length - 1 && <span className="text-muted-foreground/30 text-[10px]">›</span>}
                  </span>
                ))}
              </div>
            )}
          </div>
          <div>
            <CardTitle className="text-2xl font-bold tracking-tight">{title[mode]}</CardTitle>
            <CardDescription className="text-muted-foreground mt-1">{description[mode]}</CardDescription>
          </div>
        </CardHeader>

        <CardContent className="space-y-6">

          {/* ── Loading ── */}
          {mode === "loading" && (
            <div className="flex justify-center py-8">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          )}

          {/* ── First-time QR setup ── */}
          {mode === "setup" && (
            <div className="space-y-6">
              {initLoading ? (
                <div className="flex flex-col items-center gap-3 py-6">
                  <Loader2 className="h-8 w-8 animate-spin text-primary" />
                  <p className="text-sm text-muted-foreground">Generating QR code…</p>
                </div>
              ) : qrDataUrl ? (
                <>
                  <div className="flex flex-col items-center gap-4">
                    <div className="p-3 bg-white rounded-xl shadow-lg">
                      <img src={qrDataUrl} alt="2FA QR Code" className="w-48 h-48" />
                    </div>
                    <div className="flex items-center gap-2 text-xs text-muted-foreground">
                      <Smartphone className="h-3.5 w-3.5 shrink-0" />
                      Open Google Authenticator or Authy and scan this code
                    </div>
                    {setupSecret && (
                      <details className="text-center w-full">
                        <summary className="text-xs text-muted-foreground cursor-pointer hover:text-foreground select-none">
                          Can&apos;t scan? Enter manually
                        </summary>
                        <code className="mt-2 block text-xs font-mono bg-black/30 rounded-lg px-3 py-2 text-primary tracking-widest break-all">
                          {setupSecret}
                        </code>
                      </details>
                    )}
                  </div>
                  <div className="space-y-3">
                    <p className="text-sm font-medium text-center">Enter the 6-digit code from your app</p>
                    <div className="flex justify-center">
                      <InputOTP maxLength={6} value={totpToken} onChange={(v) => { setTotpToken(v); setError(""); }}>
                        <InputOTPGroup>
                          {[0,1,2,3,4,5].map((i) => <InputOTPSlot key={i} index={i} className="w-11 h-12 text-lg bg-black/20" />)}
                        </InputOTPGroup>
                      </InputOTP>
                    </div>
                    {error && <p className="text-xs text-red-500 flex items-center justify-center gap-1.5"><XCircle className="h-3.5 w-3.5 shrink-0" />{error}</p>}
                    <Button className="w-full" onClick={handleConfirmSetup} disabled={totpToken.length !== 6 || submitting}>
                      {submitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                      Confirm &amp; Continue
                    </Button>
                  </div>
                </>
              ) : (
                <div className="flex flex-col items-center gap-4 py-4">
                  <p className="text-sm text-red-400">{error || "Failed to load QR code."}</p>
                  <Button variant="outline" onClick={triggerInit} className="gap-2">
                    <RefreshCw className="h-4 w-4" /> Try Again
                  </Button>
                </div>
              )}
            </div>
          )}

          {/* ── TOTP login ── */}
          {mode === "totp" && (
            <div className="space-y-5">
              <div className="flex flex-col items-center gap-4">
                <div className="flex justify-center">
                  <InputOTP maxLength={6} value={totpToken} onChange={(v) => { setTotpToken(v); setError(""); }}>
                    <InputOTPGroup>
                      {[0,1,2,3,4,5].map((i) => <InputOTPSlot key={i} index={i} className="w-11 h-12 text-lg bg-black/20" />)}
                    </InputOTPGroup>
                  </InputOTP>
                </div>
                {error && <p className="text-xs text-red-500 flex items-center gap-1.5"><XCircle className="h-3.5 w-3.5 shrink-0" />{error}</p>}
              </div>
              <Button className="w-full" onClick={handleVerifyTotp} disabled={totpToken.length !== 6 || submitting}>
                {submitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                Continue
              </Button>
            </div>
          )}

          {/* ── Password ── */}
          {mode === "password" && (
            <Form {...form}>
              <form onSubmit={form.handleSubmit(handlePassword)} className="space-y-5">
                <FormField control={form.control} name="password" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Password</FormLabel>
                    <FormControl>
                      <div className="relative">
                        <Lock className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
                        <Input
                          type={showPassword ? "text" : "password"}
                          placeholder="••••••••••••"
                          className="pl-9 pr-10 bg-black/20"
                          {...field}
                        />
                        <Button type="button" variant="ghost" size="icon"
                          aria-label={showPassword ? "Hide password" : "Show password"}
                          className="absolute right-1 top-1 h-7 w-7 text-muted-foreground hover:text-foreground"
                          onClick={() => setShowPassword((s) => !s)}>
                          {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                        </Button>
                      </div>
                    </FormControl>
                    <FormMessage />
                    {(passwordVal?.length ?? 0) > 0 && (
                      <div className="mt-2 space-y-2">
                        <div className="h-1.5 w-full rounded-full bg-white/10 overflow-hidden">
                          <div className={`h-full rounded-full transition-all duration-300 ${strengthColor}`} style={{ width: `${strengthPct}%` }} />
                        </div>
                        <ul className="space-y-1 pt-0.5">
                          {PASSWORD_RULES.map((rule) => {
                            const ok = rule.test(passwordVal ?? "");
                            return (
                              <li key={rule.label} className="flex items-center gap-2 text-xs">
                                {ok
                                  ? <CheckCircle2 className="h-3.5 w-3.5 text-green-500 shrink-0" />
                                  : <XCircle className="h-3.5 w-3.5 text-muted-foreground/40 shrink-0" />}
                                <span className={ok ? "text-foreground" : "text-muted-foreground"}>{rule.label}</span>
                              </li>
                            );
                          })}
                        </ul>
                      </div>
                    )}
                  </FormItem>
                )} />
                {error && <p className="text-xs text-red-500 flex items-center gap-1.5"><XCircle className="h-3.5 w-3.5 shrink-0" />{error}</p>}
                <Button type="submit" className="w-full" disabled={submitting}>
                  {submitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  Sign In
                </Button>
              </form>
            </Form>
          )}

          {/* ── Access granted ── */}
          {mode === "granted" && (
            <div className="flex flex-col items-center py-6 gap-4">
              <div className="p-5 bg-green-500/10 rounded-full animate-pulse">
                <CheckCircle2 className="h-12 w-12 text-green-500" />
              </div>
              <p className="text-lg font-semibold text-green-400">Access Granted</p>
              <p className="text-sm text-muted-foreground text-center">Identity verified. Redirecting…</p>
              <div className="mt-2 space-y-1.5 text-xs text-muted-foreground w-full bg-black/20 rounded-lg p-4 border border-white/5">
                <p className="font-semibold text-foreground mb-2 text-sm">Security Active</p>
                {["TOTP Authenticator", "Password Verification", "Session Timeout", "Failed Attempts Monitoring"].map((item) => (
                  <div key={item} className="flex items-center gap-2">
                    <ShieldCheck className="h-3 w-3 text-primary shrink-0" />{item}
                  </div>
                ))}
              </div>
            </div>
          )}

        </CardContent>

        <CardFooter className="pt-0 pb-6 flex justify-center border-t border-white/5 mt-4">
          <p className="text-xs text-muted-foreground mt-4 flex items-center gap-1.5">
            <KeyRound className="h-3 w-3" /> Unauthorized access attempts are logged
          </p>
        </CardFooter>
      </Card>
    </div>
  );
}

import { Router, type IRouter, type Request, type Response } from "express";
import { eq, desc } from "drizzle-orm";
import { authenticator } from "otplib";
import {
  db,
  cloudConnectionsTable,
  sessionsTable,
  securityEventsTable,
  userAccountsTable,
} from "@workspace/db";
import { userAuth, type AuthRequest } from "../middlewares/userJwtAuth";
import { logger } from "../lib/logger";

const router: IRouter = Router();
router.use(userAuth);

// GET /security/sessions — list user's cloud connections / sessions
router.get("/security/sessions", async (req: Request, res: Response): Promise<void> => {
  const { userEmail } = req as AuthRequest;
  try {
    const connections = await db
      .select()
      .from(cloudConnectionsTable)
      .where(eq(cloudConnectionsTable.userEmail, userEmail))
      .orderBy(desc(cloudConnectionsTable.connectedAt))
      .limit(20);

    res.json({
      sessions: connections.map((c) => ({
        id: c.id,
        profile: c.profile,
        region: c.region,
        status: c.status,
        connectedAt: c.connectedAt,
        lastSeenAt: c.lastSeenAt,
        disconnectedAt: c.disconnectedAt ?? null,
      })),
    });
  } catch (err) {
    logger.error({ err }, "Get sessions error");
    res.status(500).json({ error: "Failed to fetch sessions." });
  }
});

// POST /security/logout-all — terminate all cloud connections and active sessions
router.post("/security/logout-all", async (req: Request, res: Response): Promise<void> => {
  const { userEmail } = req as AuthRequest;
  try {
    await db
      .update(cloudConnectionsTable)
      .set({ status: "disconnected", disconnectedAt: new Date(), activeSessionId: null })
      .where(eq(cloudConnectionsTable.userEmail, userEmail));

    await db
      .update(sessionsTable)
      .set({ status: "stopped", endedAt: new Date() })
      .where(eq(sessionsTable.userEmail, userEmail));

    await db.insert(securityEventsTable).values({
      type: "logout_all",
      severity: "Low",
      description: `All sessions terminated for ${userEmail}`,
      userEmail,
      ipAddress: req.ip ?? req.socket.remoteAddress ?? null,
      status: "resolved",
    });

    logger.info({ userEmail }, "All sessions terminated");
    res.json({ terminated: true, message: "All active sessions have been disconnected." });
  } catch (err) {
    logger.error({ err }, "Logout all error");
    res.status(500).json({ error: "Failed to terminate sessions." });
  }
});

// GET /security/activity — recent security events for the authenticated user
router.get("/security/activity", async (req: Request, res: Response): Promise<void> => {
  const { userEmail } = req as AuthRequest;
  const limit = Math.min(Number(req.query.limit ?? 20), 100);
  try {
    const events = await db
      .select()
      .from(securityEventsTable)
      .where(eq(securityEventsTable.userEmail, userEmail))
      .orderBy(desc(securityEventsTable.createdAt))
      .limit(limit);

    res.json({ activity: events });
  } catch (err) {
    logger.error({ err }, "Security activity error");
    res.status(500).json({ error: "Failed to fetch security activity." });
  }
});

// POST /security/2fa — manage TOTP 2FA (action: setup | enable | disable)
router.post("/security/2fa", async (req: Request, res: Response): Promise<void> => {
  const { userId, userEmail } = req as AuthRequest;
  const { action, code } = req.body as { action?: string; code?: string };

  if (!action || !["setup", "enable", "disable"].includes(action)) {
    res.status(400).json({ error: "action must be setup, enable, or disable." });
    return;
  }

  try {
    const [account] = await db
      .select()
      .from(userAccountsTable)
      .where(eq(userAccountsTable.id, userId))
      .limit(1);

    if (!account) {
      res.status(404).json({ error: "User not found." });
      return;
    }

    if (action === "setup") {
      const secret = authenticator.generateSecret();
      const otpauth = authenticator.keyuri(userEmail, "OREXUP", secret);
      await db
        .update(userAccountsTable)
        .set({ totpSecret: secret, totpEnabled: false })
        .where(eq(userAccountsTable.id, userId));
      res.json({
        secret,
        otpauthUrl: otpauth,
        qrCodeUrl: `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(otpauth)}`,
        instructions: "Scan the QR code with your authenticator app, then call this endpoint with action=enable and your 6-digit code.",
      });
      return;
    }

    if (action === "enable") {
      if (!code) { res.status(400).json({ error: "code is required to enable 2FA." }); return; }
      if (!account.totpSecret) { res.status(400).json({ error: "Run setup first to generate a secret." }); return; }
      if (account.totpEnabled) { res.status(409).json({ error: "2FA is already enabled." }); return; }
      const valid = authenticator.verify({ token: code, secret: account.totpSecret });
      if (!valid) { res.status(400).json({ error: "Invalid TOTP code. Check your authenticator app." }); return; }
      await db.update(userAccountsTable).set({ totpEnabled: true }).where(eq(userAccountsTable.id, userId));
      logger.info({ userId }, "2FA enabled");
      res.json({ enabled: true, message: "Two-factor authentication has been enabled." });
      return;
    }

    // action === "disable"
    if (!code) { res.status(400).json({ error: "code is required to disable 2FA." }); return; }
    if (!account.totpSecret || !account.totpEnabled) { res.status(409).json({ error: "2FA is not currently enabled." }); return; }
    const valid = authenticator.verify({ token: code, secret: account.totpSecret });
    if (!valid) { res.status(400).json({ error: "Invalid TOTP code." }); return; }
    await db.update(userAccountsTable).set({ totpEnabled: false, totpSecret: null }).where(eq(userAccountsTable.id, userId));
    logger.info({ userId }, "2FA disabled");
    res.json({ disabled: true, message: "Two-factor authentication has been disabled." });
  } catch (err) {
    logger.error({ err }, "2FA management error");
    res.status(500).json({ error: "2FA operation failed." });
  }
});

export default router;

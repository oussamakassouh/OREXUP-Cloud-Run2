import { Check } from "lucide-react";

const STEPS = [
  { n: 1, label: "Create Account" },
  { n: 2, label: "Verify Email" },
  { n: 3, label: "Sign In" },
  { n: 4, label: "Dashboard" },
];

export function AuthSteps({ current }: { current: 1 | 2 | 3 | 4 }) {
  return (
    <div className="flex items-end justify-center gap-0 mb-8">
      {STEPS.map((step, i) => (
        <div key={step.n} className="flex items-center">
          <div className="flex flex-col items-center">
            <div
              className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold border-2 transition-colors ${
                step.n < current
                  ? "bg-primary border-primary text-primary-foreground"
                  : step.n === current
                  ? "border-primary text-primary bg-primary/10"
                  : "border-white/20 text-muted-foreground"
              }`}
            >
              {step.n < current ? <Check className="h-3.5 w-3.5" /> : step.n}
            </div>
            <span
              className={`text-[10px] mt-1.5 font-medium w-[60px] text-center leading-tight ${
                step.n === current
                  ? "text-foreground"
                  : "text-muted-foreground/60"
              }`}
            >
              {step.label}
            </span>
          </div>
          {i < STEPS.length - 1 && (
            <div
              className={`h-px w-8 mb-5 ${
                step.n < current ? "bg-primary" : "bg-white/10"
              }`}
            />
          )}
        </div>
      ))}
    </div>
  );
}

import crypto from "crypto";
import { Router, type IRouter, type Request, type Response } from "express";
import { eq } from "drizzle-orm";
import { authenticator } from "otplib";
import QRCode from "qrcode";
import bcrypt from "bcryptjs";
import { db, adminTwoFactorTable } from "@workspace/db";
import { setAdminSession, clearAdminSession, isValidAdminToken } from "../middlewares/adminAuth";

const router: IRouter = Router();

const ADMIN_EMAIL = process.env.ADMIN_EMAIL ?? "admin@orexup.com";
const ISSUER      = "OREXUP Admin";

// ── Partial-auth nonce store (step1=TOTP done) ───────────────────────────────
interface PartialEntry { step1: boolean; expires: Date; }
const partialStore = new Map<string, PartialEntry>();

function cleanExpired() {
  const now = new Date();
  for (const [k, v] of partialStore) if (v.expires < now) partialStore.delete(k);
}
function createNonce(): string {
  cleanExpired();
  const nonce = crypto.randomUUID();
  partialStore.set(nonce, { step1: true, expires: new Date(Date.now() + 10 * 60 * 1000) });
  return nonce;
}
function getEntry(nonce: string): PartialEntry | null {
  cleanExpired();
  const e = partialStore.get(nonce);
  if (!e || e.expires < new Date()) { partialStore.delete(nonce); return null; }
  return e;
}

// ── 2FA helper ───────────────────────────────────────────────────────────────
async function getTwoFactorRecord() {
  const rows = await db.select().from(adminTwoFactorTable)
    .where(eq(adminTwoFactorTable.adminEmail, ADMIN_EMAIL)).limit(1);
  return rows[0] ?? null;
}

// ── Password helper ──────────────────────────────────────────────────────────
async function checkPassword(plain: string): Promise<boolean> {
  const stored = process.env.ADMIN_PASSWORD ?? "";
  if (!stored) return false;
  if (stored.startsWith("$2")) return bcrypt.compare(plain, stored);
  return plain === stored;
}

// ── Public routes ─────────────────────────────────────────────────────────────

// Check 2FA status
router.get("/admin/auth-status", async (_req: Request, res: Response): Promise<void> => {
  const record = await getTwoFactorRecord();
  res.json({ hasTwoFactor: record?.enabled ?? false });
});

// First-time setup: generate secret + QR
router.post("/admin/2fa/init", async (_req: Request, res: Response): Promise<void> => {
  const existing = await getTwoFactorRecord();
  if (existing?.enabled) {
    res.status(400).json({ error: "2FA already enabled. Use your authenticator app to sign in." });
    return;
  }
  const secret = authenticator.generateSecret();
  const otpauthUrl = authenticator.keyuri(ADMIN_EMAIL, ISSUER, secret);
  const qrCodeDataUrl = await QRCode.toDataURL(otpauthUrl);
  if (existing) {
    await db.update(adminTwoFactorTable)
      .set({ secret, enabled: false, updatedAt: new Date() })
      .where(eq(adminTwoFactorTable.adminEmail, ADMIN_EMAIL));
  } else {
    await db.insert(adminTwoFactorTable).values({ adminEmail: ADMIN_EMAIL, secret, enabled: false });
  }
  res.json({ qrCodeDataUrl, secret });
});

// Confirm first-time setup: verify TOTP → enable 2FA → return nonce for password step
router.post("/admin/2fa/confirm", async (req: Request, res: Response): Promise<void> => {
  const { token } = req.body as { token?: string };
  if (!token) { res.status(400).json({ error: "Authenticator code is required." }); return; }
  const record = await getTwoFactorRecord();
  if (!record || record.enabled) {
    res.status(400).json({ error: "No pending setup. Start setup again." });
    return;
  }
  const isValid = authenticator.verify({ token: token.replace(/\s/g, ""), secret: record.secret });
  if (!isValid) {
    res.status(401).json({ error: "Invalid code. Make sure your app clock is synced." });
    return;
  }
  await db.update(adminTwoFactorTable)
    .set({ enabled: true, updatedAt: new Date() })
    .where(eq(adminTwoFactorTable.adminEmail, ADMIN_EMAIL));
  res.json({ ok: true, nonce: createNonce() });
});

// Regular sign-in: verify TOTP → return nonce for password step
router.post("/admin/session", async (req: Request, res: Response): Promise<void> => {
  const { token } = req.body as { token?: string };
  if (!token) { res.status(400).json({ error: "Authenticator code is required." }); return; }
  const record = await getTwoFactorRecord();
  if (!record || !record.enabled) {
    res.status(401).json({ error: "2FA not configured. Please complete setup first." });
    return;
  }
  const isValid = authenticator.verify({ token: token.replace(/\s/g, ""), secret: record.secret });
  if (!isValid) {
    res.status(401).json({ error: "Invalid code. Codes refresh every 30 s — try again." });
    return;
  }
  res.json({ ok: true, nonce: createNonce() });
});

// Step 2: verify password → grant session (email is implicit — only one admin account)
router.post("/admin/verify-password", async (req: Request, res: Response): Promise<void> => {
  const { password, nonce } = req.body as { password?: string; nonce?: string };
  if (!password || !nonce) {
    res.status(400).json({ error: "Password and session token are required." });
    return;
  }
  const entry = getEntry(nonce);
  if (!entry?.step1) {
    res.status(401).json({ error: "Session expired. Please start again." });
    return;
  }
  const ok = await checkPassword(password);
  if (!ok) {
    res.status(401).json({ error: "Incorrect password." });
    return;
  }
  partialStore.delete(nonce);
  setAdminSession(res);
  res.json({ ok: true });
});

// Session check — direct cookie verification, no adminAuth middleware in the chain
router.get("/admin/me", (req: Request, res: Response): void => {
  const token = req.cookies?.["orexup_admin_session"] as string | undefined;
  if (isValidAdminToken(token)) {
    res.json({ ok: true, authenticated: true });
  } else {
    res.status(401).json({ error: "Not authenticated" });
  }
});

// Sign out
router.delete("/admin/session", (_req: Request, res: Response): void => {
  clearAdminSession(res);
  res.json({ ok: true });
});

export default router;

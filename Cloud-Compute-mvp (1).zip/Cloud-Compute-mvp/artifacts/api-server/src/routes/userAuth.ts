import crypto, { createHmac, timingSafeEqual } from "crypto";
import { Router, type IRouter, type Request, type Response } from "express";
import { eq } from "drizzle-orm";
import bcrypt from "bcryptjs";
import { SignJWT, jwtVerify } from "jose";
import { Resend } from "resend";
import { authenticator } from "otplib";
import { db, userAccountsTable } from "@workspace/db";
import { logger } from "../lib/logger";

const router: IRouter = Router();

const JWT_SECRET_RAW = process.env.USER_JWT_SECRET ?? "orexup-user-jwt-dev-secret-change-in-production";
const JWT_SECRET = new TextEncoder().encode(JWT_SECRET_RAW);
const JWT_TTL = "7d";
const COOKIE_NAME = "orexup_user_session";
const TWO_FA_PENDING_COOKIE = "orexup_2fa_pending";
const COOKIE_MAX_AGE = 7 * 24 * 60 * 60 * 1000;
const TWO_FA_TTL_MS = 5 * 60 * 1000;
const APP_URL = process.env.APP_URL ?? "http://localhost:5173";
const resend = process.env.RESEND_API_KEY ? new Resend(process.env.RESEND_API_KEY) : null;

function sign2faPending(userId: number): string {
  const payload = `${userId}.${Date.now()}`;
  const sig = createHmac("sha256", JWT_SECRET_RAW).update(payload).digest("hex");
  return `${payload}.${sig}`;
}

function verify2faPending(token: string): number | null {
  const parts = token.split(".");
  if (parts.length !== 3) return null;
  const [userIdStr, tsStr, sig] = parts;
  const payload = `${userIdStr}.${tsStr}`;
  const expected = createHmac("sha256", JWT_SECRET_RAW).update(payload).digest("hex");
  try {
    if (!timingSafeEqual(Buffer.from(sig, "hex"), Buffer.from(expected, "hex"))) return null;
  } catch { return null; }
  if (Date.now() - Number(tsStr) > TWO_FA_TTL_MS) return null;
  return Number(userIdStr);
}

async function issueJwt(userId: number, email: string): Promise<string> {
  return new SignJWT({ sub: String(userId), email })
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setExpirationTime(JWT_TTL)
    .sign(JWT_SECRET);
}

function setUserSession(res: Response, token: string) {
  res.cookie(COOKIE_NAME, token, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    maxAge: COOKIE_MAX_AGE,
    path: "/",
  });
}

async function sendVerificationEmail(email: string, token: string) {
  if (!resend) {
    logger.warn("RESEND_API_KEY not set — skipping verification email");
    return;
  }
  const url = `${APP_URL}/verify-email?token=${token}`;
  await resend.emails.send({
    from: "OREXUP <noreply@orexup.com>",
    to: email,
    subject: "Verify your OREXUP account",
    html: `
      <div style="font-family:sans-serif;max-width:480px;margin:0 auto;padding:32px 24px">
        <h2 style="color:#7c3aed;margin-bottom:8px">Verify your email</h2>
        <p style="color:#555;margin-bottom:24px">Click the button below to verify your OREXUP account.</p>
        <a href="${url}" style="display:inline-block;background:#7c3aed;color:#fff;padding:12px 28px;border-radius:8px;text-decoration:none;font-weight:600">
          Verify Email
        </a>
        <p style="color:#999;font-size:12px;margin-top:24px">This link expires in 24 hours. If you didn't sign up, you can ignore this email.</p>
      </div>
    `,
  });
}

async function sendPasswordResetEmail(email: string, token: string) {
  if (!resend) {
    logger.warn("RESEND_API_KEY not set — skipping reset email");
    return;
  }
  const url = `${APP_URL}/reset-password?token=${token}`;
  await resend.emails.send({
    from: "OREXUP <noreply@orexup.com>",
    to: email,
    subject: "Reset your OREXUP password",
    html: `
      <div style="font-family:sans-serif;max-width:480px;margin:0 auto;padding:32px 24px">
        <h2 style="color:#7c3aed;margin-bottom:8px">Reset your password</h2>
        <p style="color:#555;margin-bottom:24px">Click the button below to reset your OREXUP password.</p>
        <a href="${url}" style="display:inline-block;background:#7c3aed;color:#fff;padding:12px 28px;border-radius:8px;text-decoration:none;font-weight:600">
          Reset Password
        </a>
        <p style="color:#999;font-size:12px;margin-top:24px">This link expires in 1 hour. If you didn't request this, you can ignore this email.</p>
      </div>
    `,
  });
}

// ── POST /auth/signup ─────────────────────────────────────────────────────────
router.post("/auth/signup", async (req: Request, res: Response) => {
  const { email, password, name } = req.body as {
    email?: string; password?: string; name?: string;
  };

  if (!email || !password) {
    res.status(400).json({ error: "Email and password are required." });
    return;
  }
  if (password.length < 8) {
    res.status(400).json({ error: "Password must be at least 8 characters." });
    return;
  }

  const normalizedEmail = email.toLowerCase().trim();

  try {
    const existing = await db
      .select({ id: userAccountsTable.id })
      .from(userAccountsTable)
      .where(eq(userAccountsTable.email, normalizedEmail))
      .limit(1);

    if (existing.length > 0) {
      res.status(409).json({ error: "An account with this email already exists." });
      return;
    }

    const passwordHash = await bcrypt.hash(password, 12);
    const verifyToken = crypto.randomBytes(32).toString("hex");
    const verifyTokenExpiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000);

    await db.insert(userAccountsTable).values({
      email: normalizedEmail,
      name: name?.trim() || normalizedEmail.split("@")[0],
      passwordHash,
      verifyToken,
      verifyTokenExpiresAt,
      emailVerified: false,
    });

    await sendVerificationEmail(normalizedEmail, verifyToken);

    logger.info({ email: normalizedEmail }, "User signed up");
    res.status(201).json({ message: "Account created. Please check your email to verify your account." });
  } catch (err) {
    logger.error({ err }, "Signup error");
    res.status(500).json({ error: "Failed to create account." });
  }
});

// ── GET /auth/verify-email ────────────────────────────────────────────────────
router.get("/auth/verify-email", async (req: Request, res: Response) => {
  const { token } = req.query as { token?: string };

  if (!token || typeof token !== "string" || token.length > 128) {
    res.status(400).json({ error: "Verification token is required." });
    return;
  }

  try {
    const [account] = await db
      .select({
        id: userAccountsTable.id,
        email: userAccountsTable.email,
        emailVerified: userAccountsTable.emailVerified,
        verifyTokenExpiresAt: userAccountsTable.verifyTokenExpiresAt,
      })
      .from(userAccountsTable)
      .where(eq(userAccountsTable.verifyToken, token))
      .limit(1);

    if (!account) {
      res.status(400).json({ error: "Invalid or expired verification link." });
      return;
    }
    if (account.emailVerified) {
      res.json({ message: "Email already verified. You can sign in." });
      return;
    }
    if (account.verifyTokenExpiresAt && account.verifyTokenExpiresAt < new Date()) {
      res.status(410).json({ error: "Verification link has expired.", code: "TOKEN_EXPIRED" });
      return;
    }

    await db
      .update(userAccountsTable)
      .set({ emailVerified: true, verifyToken: null, verifyTokenExpiresAt: null })
      .where(eq(userAccountsTable.id, account.id));

    logger.info({ email: account.email }, "Email verified");
    res.json({ message: "Email verified successfully. You can now sign in." });
  } catch (err) {
    logger.error({ err }, "Email verification error");
    res.status(500).json({ error: "Verification failed." });
  }
});

// ── POST /auth/resend-verification ───────────────────────────────────────────
router.post("/auth/resend-verification", async (req: Request, res: Response) => {
  const { email } = req.body as { email?: string };
  // Always respond 200 to avoid account enumeration
  res.json({ message: "If this email is registered and unverified, a new link has been sent." });

  if (!email || typeof email !== "string") return;
  const normalizedEmail = email.toLowerCase().trim();

  try {
    const [account] = await db
      .select({
        id: userAccountsTable.id,
        email: userAccountsTable.email,
        emailVerified: userAccountsTable.emailVerified,
      })
      .from(userAccountsTable)
      .where(eq(userAccountsTable.email, normalizedEmail))
      .limit(1);

    if (!account || account.emailVerified) return;

    const verifyToken = crypto.randomBytes(32).toString("hex");
    const verifyTokenExpiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000);

    await db
      .update(userAccountsTable)
      .set({ verifyToken, verifyTokenExpiresAt })
      .where(eq(userAccountsTable.id, account.id));

    await sendVerificationEmail(account.email, verifyToken);
    logger.info({ email: normalizedEmail }, "Verification email resent");
  } catch (err) {
    logger.error({ err }, "Resend verification error");
  }
});

// ── POST /auth/signin ─────────────────────────────────────────────────────────
router.post("/auth/signin", async (req: Request, res: Response) => {
  const { email, password } = req.body as { email?: string; password?: string };

  if (!email || !password) {
    res.status(400).json({ error: "Email and password are required." });
    return;
  }

  const normalizedEmail = email.toLowerCase().trim();

  try {
    const [account] = await db
      .select()
      .from(userAccountsTable)
      .where(eq(userAccountsTable.email, normalizedEmail))
      .limit(1);

    if (!account) {
      res.status(401).json({ error: "Invalid email or password." });
      return;
    }

    const passwordMatch = await bcrypt.compare(password, account.passwordHash);
    if (!passwordMatch) {
      res.status(401).json({ error: "Invalid email or password." });
      return;
    }

    if (!account.emailVerified) {
      res.status(403).json({ error: "Please verify your email before signing in.", code: "EMAIL_NOT_VERIFIED" });
      return;
    }

    // 2FA check — issue short-lived pending cookie and halt if TOTP is enabled
    if (account.totpEnabled) {
      const pendingToken = sign2faPending(account.id);
      res.cookie(TWO_FA_PENDING_COOKIE, pendingToken, {
        httpOnly: true,
        sameSite: "lax",
        secure: process.env.NODE_ENV === "production",
        maxAge: TWO_FA_TTL_MS,
        path: "/",
      });
      res.json({ requiresTwoFactor: true });
      return;
    }

    const token = await issueJwt(account.id, account.email);
    setUserSession(res, token);

    await db
      .update(userAccountsTable)
      .set({ lastLoginAt: new Date() })
      .where(eq(userAccountsTable.id, account.id));

    logger.info({ email: account.email }, "User signed in");
    res.json({
      user: { id: account.id, email: account.email, name: account.name },
    });
  } catch (err) {
    logger.error({ err }, "Signin error");
    res.status(500).json({ error: "Sign in failed." });
  }
});

// ── POST /auth/signout ────────────────────────────────────────────────────────
router.post("/auth/signout", (_req: Request, res: Response) => {
  res.clearCookie(COOKIE_NAME, { path: "/" });
  res.json({ message: "Signed out." });
});

// ── GET /auth/me ──────────────────────────────────────────────────────────────
router.get("/auth/me", async (req: Request, res: Response) => {
  const token = req.cookies?.[COOKIE_NAME] as string | undefined;
  if (!token) {
    res.status(401).json({ error: "Not authenticated." });
    return;
  }

  try {
    const { payload } = await jwtVerify(token, JWT_SECRET);
    const userId = Number(payload.sub);

    const [account] = await db
      .select({ id: userAccountsTable.id, email: userAccountsTable.email, name: userAccountsTable.name })
      .from(userAccountsTable)
      .where(eq(userAccountsTable.id, userId))
      .limit(1);

    if (!account) {
      res.clearCookie(COOKIE_NAME, { path: "/" });
      res.status(401).json({ error: "User not found." });
      return;
    }

    res.json({ user: account });
  } catch (err) {
    // Distinguish JWT verification failures from unexpected DB errors
    const isJwtError = err instanceof Error && (
      err.message.includes("JWTExpired") ||
      err.message.includes("JWSInvalid") ||
      err.message.includes("JWSSignatureVerificationFailed") ||
      err.constructor?.name?.startsWith("JWT")
    );
    if (isJwtError) {
      res.clearCookie(COOKIE_NAME, { path: "/" });
      res.status(401).json({ error: "Session expired." });
    } else {
      req.log.error({ err }, "Unexpected error in /auth/me");
      res.status(500).json({ error: "An unexpected error occurred." });
    }
  }
});

// ── POST /auth/forgot-password ────────────────────────────────────────────────
router.post("/auth/forgot-password", async (req: Request, res: Response) => {
  const { email } = req.body as { email?: string };
  // Always respond 200 to avoid email enumeration
  res.json({ message: "If an account exists for this email, a reset link has been sent." });

  if (!email) return;
  const normalizedEmail = email.toLowerCase().trim();

  try {
    const [account] = await db
      .select({ id: userAccountsTable.id, email: userAccountsTable.email })
      .from(userAccountsTable)
      .where(eq(userAccountsTable.email, normalizedEmail))
      .limit(1);

    if (!account) return;

    const resetToken = crypto.randomBytes(32).toString("hex");
    const resetTokenExpiresAt = new Date(Date.now() + 60 * 60 * 1000);

    await db
      .update(userAccountsTable)
      .set({ resetToken, resetTokenExpiresAt })
      .where(eq(userAccountsTable.id, account.id));

    await sendPasswordResetEmail(account.email, resetToken);
    logger.info({ email: normalizedEmail }, "Password reset requested");
  } catch (err) {
    logger.error({ err }, "Forgot password error");
  }
});

// ── POST /auth/reset-password ─────────────────────────────────────────────────
router.post("/auth/reset-password", async (req: Request, res: Response) => {
  const { token, password } = req.body as { token?: string; password?: string };

  if (!token || !password) {
    res.status(400).json({ error: "Token and new password are required." });
    return;
  }
  if (password.length < 8) {
    res.status(400).json({ error: "Password must be at least 8 characters." });
    return;
  }

  try {
    const [account] = await db
      .select()
      .from(userAccountsTable)
      .where(eq(userAccountsTable.resetToken, token))
      .limit(1);

    if (!account || !account.resetTokenExpiresAt || account.resetTokenExpiresAt < new Date()) {
      res.status(400).json({ error: "Invalid or expired reset link." });
      return;
    }

    const passwordHash = await bcrypt.hash(password, 12);
    await db
      .update(userAccountsTable)
      .set({ passwordHash, resetToken: null, resetTokenExpiresAt: null })
      .where(eq(userAccountsTable.id, account.id));

    logger.info({ email: account.email }, "Password reset");
    res.json({ message: "Password reset successfully. You can now sign in." });
  } catch (err) {
    logger.error({ err }, "Reset password error");
    res.status(500).json({ error: "Password reset failed." });
  }
});

// ── POST /auth/logout — clear the user session cookie ─────────────────────────
router.post("/auth/logout", (req: Request, res: Response) => {
  res.clearCookie(COOKIE_NAME, { path: "/" });
  res.clearCookie(TWO_FA_PENDING_COOKIE, { path: "/" });
  res.json({ loggedOut: true });
});

// ── POST /auth/verify-email — body-based token verification ───────────────────
router.post("/auth/verify-email", async (req: Request, res: Response) => {
  const { token } = req.body as { token?: string };
  if (!token || typeof token !== "string" || token.length > 128) {
    res.status(400).json({ error: "token is required." });
    return;
  }
  try {
    const [account] = await db
      .select({
        id: userAccountsTable.id,
        email: userAccountsTable.email,
        emailVerified: userAccountsTable.emailVerified,
        verifyTokenExpiresAt: userAccountsTable.verifyTokenExpiresAt,
      })
      .from(userAccountsTable)
      .where(eq(userAccountsTable.verifyToken, token))
      .limit(1);

    if (!account) {
      res.status(400).json({ error: "Invalid or expired verification link." });
      return;
    }
    if (account.emailVerified) {
      res.json({ verified: true, message: "Email already verified. You can sign in." });
      return;
    }
    if (!account.verifyTokenExpiresAt || account.verifyTokenExpiresAt < new Date()) {
      res.status(410).json({ error: "Verification link has expired.", code: "TOKEN_EXPIRED" });
      return;
    }
    await db
      .update(userAccountsTable)
      .set({ emailVerified: true, verifyToken: null, verifyTokenExpiresAt: null })
      .where(eq(userAccountsTable.id, account.id));

    logger.info({ email: account.email }, "Email verified via POST");
    res.json({ verified: true, message: "Email address verified. You can now sign in." });
  } catch (err) {
    logger.error({ err }, "POST verify-email error");
    res.status(500).json({ error: "Verification failed." });
  }
});

// ── POST /auth/2fa/verify — verify TOTP code after pending signin ─────────────
router.post("/auth/2fa/verify", async (req: Request, res: Response) => {
  const pendingToken = req.cookies?.[TWO_FA_PENDING_COOKIE] as string | undefined;
  if (!pendingToken) {
    res.status(401).json({ error: "No pending 2FA session. Please sign in first." });
    return;
  }
  const userId = verify2faPending(pendingToken);
  if (!userId) {
    res.clearCookie(TWO_FA_PENDING_COOKIE, { path: "/" });
    res.status(401).json({ error: "2FA session expired. Please sign in again." });
    return;
  }

  const { code } = req.body as { code?: string };
  if (!code || code.length !== 6) {
    res.status(400).json({ error: "A 6-digit code is required." });
    return;
  }

  try {
    const [account] = await db
      .select()
      .from(userAccountsTable)
      .where(eq(userAccountsTable.id, userId))
      .limit(1);

    if (!account || !account.totpSecret || !account.totpEnabled) {
      res.clearCookie(TWO_FA_PENDING_COOKIE, { path: "/" });
      res.status(401).json({ error: "2FA is not configured for this account." });
      return;
    }

    const valid = authenticator.verify({ token: code, secret: account.totpSecret });
    if (!valid) {
      res.status(400).json({ error: "Invalid code. Please try again." });
      return;
    }

    res.clearCookie(TWO_FA_PENDING_COOKIE, { path: "/" });
    const sessionToken = await issueJwt(account.id, account.email);
    setUserSession(res, sessionToken);

    await db
      .update(userAccountsTable)
      .set({ lastLoginAt: new Date() })
      .where(eq(userAccountsTable.id, account.id));

    logger.info({ userId: account.id }, "2FA verified, session issued");
    res.json({ user: { id: account.id, email: account.email, name: account.name } });
  } catch (err) {
    logger.error({ err }, "2FA verify error");
    res.status(500).json({ error: "2FA verification failed." });
  }
});

export default router;

import { Router, type IRouter } from "express";
import { and, count, desc, eq, gte, ilike, inArray, lte, sum, sql, type SQL } from "drizzle-orm";
import { type PgTable } from "drizzle-orm/pg-core";
import {
  db,
  usersTable,
  paymentsTable,
  sessionsTable,
  trafficEventsTable,
  securityEventsTable,
  supportTicketsTable,
  ticketMessagesTable,
} from "@workspace/db";
import {
  GetAdminOverviewResponse,
  GetAdminTrafficResponse,
  GetAdminAnalyticsResponse,
  GetAdminUsersResponse,
  GetAdminPaymentsResponse,
  GetAdminSecurityResponse,
  GetAdminSupportResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

// Run a raw SQL query and return typed rows. Used for grouped/date aggregations.
async function rawRows<T>(query: ReturnType<typeof sql>): Promise<T[]> {
  const result = await db.execute(query);
  const rows = (result as unknown as { rows?: unknown[] }).rows;
  return (rows ?? (result as unknown as unknown[])) as T[];
}

async function scalarCount(
  table: PgTable,
  where?: SQL | undefined,
): Promise<number> {
  const q = db.select({ c: count() }).from(table);
  const rows = where ? await q.where(where) : await q;
  return Number(rows[0]?.c ?? 0);
}

function num(value: unknown): number {
  return Number(value ?? 0);
}

function cap(value: string): string {
  if (!value) return value;
  return value.charAt(0).toUpperCase() + value.slice(1);
}

function formatDuration(seconds: number): string {
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = seconds % 60;
  return [h, m, s].map((n) => String(n).padStart(2, "0")).join(":");
}

// ─── OVERVIEW ────────────────────────────────────────────────────────────────
router.get("/admin/overview", async (req, res): Promise<void> => {
  const period = (req.query.period as string) || "month";

  // Determine the time window boundaries
  let periodStart: Date;
  let periodEnd: Date = new Date();

  if (period === "custom") {
    const fromStr = req.query.from as string | undefined;
    const toStr   = req.query.to   as string | undefined;
    periodStart = fromStr ? new Date(fromStr) : new Date(Date.now() - 30 * 86_400_000);
    periodEnd   = toStr   ? new Date(new Date(toStr).setHours(23, 59, 59, 999)) : new Date();
  } else {
    const periodMs: Record<string, number> = {
      today:  1 * 86_400_000,
      week:   7 * 86_400_000,
      month:  30 * 86_400_000,
      year:  365 * 86_400_000,
    };
    const windowMs = periodMs[period] ?? periodMs.month;
    periodStart = new Date(Date.now() - windowMs);
  }

  // Trend grouping: today→hour, week/two-week→day, month→day, year→month
  type TrendRow = { k: string; label: string; revenue_cents: number };
  type UserRow  = { k: string; label: string; users: number };

  let payTrend: TrendRow[];
  let userTrend: UserRow[];

  // Pick trend granularity: today→hour, year→month, custom(>90d)→month, else→day
  const customRangeDays = period === "custom"
    ? Math.ceil((periodEnd.getTime() - periodStart.getTime()) / 86_400_000)
    : 0;
  const useMonthly = period === "year" || (period === "custom" && customRangeDays > 90);
  const useHourly  = period === "today";

  if (useHourly) {
    payTrend = await rawRows<TrendRow>(sql`
      select to_char(date_trunc('hour', created_at), 'HH24:00') as k,
             to_char(date_trunc('hour', created_at), 'HH24:MI') as label,
             coalesce(sum(amount_cents) filter (where status = 'paid'), 0)::int as revenue_cents
      from payments
      where created_at >= ${periodStart} and created_at <= ${periodEnd}
      group by 1, 2 order by 1
    `);
    userTrend = await rawRows<UserRow>(sql`
      select to_char(date_trunc('hour', created_at), 'HH24:00') as k,
             to_char(date_trunc('hour', created_at), 'HH24:MI') as label,
             count(*)::int as users
      from app_users
      where created_at >= ${periodStart} and created_at <= ${periodEnd}
      group by 1, 2 order by 1
    `);
  } else if (useMonthly) {
    payTrend = await rawRows<TrendRow>(sql`
      select to_char(date_trunc('month', created_at), 'YYYY-MM') as k,
             to_char(date_trunc('month', created_at), 'Mon') as label,
             coalesce(sum(amount_cents) filter (where status = 'paid'), 0)::int as revenue_cents
      from payments
      where created_at >= ${periodStart} and created_at <= ${periodEnd}
      group by 1, 2 order by 1
    `);
    userTrend = await rawRows<UserRow>(sql`
      select to_char(date_trunc('month', created_at), 'YYYY-MM') as k,
             to_char(date_trunc('month', created_at), 'Mon') as label,
             count(*)::int as users
      from app_users
      where created_at >= ${periodStart} and created_at <= ${periodEnd}
      group by 1, 2 order by 1
    `);
  } else {
    // week, two-week, month, custom(≤90d) → daily buckets
    payTrend = await rawRows<TrendRow>(sql`
      select to_char(date_trunc('day', created_at), 'YYYY-MM-DD') as k,
             to_char(date_trunc('day', created_at), 'Mon DD') as label,
             coalesce(sum(amount_cents) filter (where status = 'paid'), 0)::int as revenue_cents
      from payments
      where created_at >= ${periodStart} and created_at <= ${periodEnd}
      group by 1, 2 order by 1
    `);
    userTrend = await rawRows<UserRow>(sql`
      select to_char(date_trunc('day', created_at), 'YYYY-MM-DD') as k,
             to_char(date_trunc('day', created_at), 'Mon DD') as label,
             count(*)::int as users
      from app_users
      where created_at >= ${periodStart} and created_at <= ${periodEnd}
      group by 1, 2 order by 1
    `);
  }

  const trendMap = new Map<string, { month: string; revenueCents: number; users: number }>();
  for (const r of payTrend) {
    trendMap.set(r.k, { month: r.label, revenueCents: num(r.revenue_cents), users: 0 });
  }
  for (const r of userTrend) {
    const existing = trendMap.get(r.k);
    if (existing) existing.users = num(r.users);
    else trendMap.set(r.k, { month: r.label, revenueCents: 0, users: num(r.users) });
  }
  const revenueTrend = [...trendMap.entries()]
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([, v]) => v);

  const totalUsers = await scalarCount(usersTable);
  const activeSessions = await scalarCount(
    sessionsTable,
    eq(sessionsTable.status, "active"),
  );

  const revRows = await db
    .select({ v: sum(paymentsTable.amountCents) })
    .from(paymentsTable)
    .where(
      and(
        eq(paymentsTable.status, "paid"),
        gte(paymentsTable.createdAt, periodStart),
      ),
    );
  const monthlyRevenueCents = num(revRows[0]?.v);

  const newSignups = await scalarCount(
    usersTable,
    gte(usersTable.createdAt, periodStart),
  );

  const recentActivity = await rawRows<{
    id: number;
    type: string;
    description: string;
    timestamp: Date;
  }>(sql`
    (select id, 'signup' as type, name || ' signed up' as description, created_at as timestamp
       from app_users where created_at >= ${periodStart} order by created_at desc limit 5)
    union all
    (select id, 'payment' as type, user_email || ' completed a payment' as description, created_at as timestamp
       from payments where created_at >= ${periodStart} order by created_at desc limit 5)
    union all
    (select id, 'ticket' as type, 'New ticket: ' || subject as description, created_at as timestamp
       from support_tickets where created_at >= ${periodStart} order by created_at desc limit 5)
    order by timestamp desc
    limit 10
  `);

  res.json(
    GetAdminOverviewResponse.parse({
      totalUsers,
      activeSessions,
      monthlyRevenueCents,
      newSignups,
      revenueTrend,
      recentActivity,
    }),
  );
});

// ─── SHARED PERIOD HELPER ────────────────────────────────────────────────────
function parsePeriod(
  query: Record<string, unknown>,
  defaultPeriod = "month",
): { periodStart: Date; periodEnd: Date } {
  const period = (query.period as string) || defaultPeriod;
  let periodStart: Date;
  let periodEnd: Date = new Date();

  if (period === "custom") {
    const fromStr = query.from as string | undefined;
    const toStr   = query.to   as string | undefined;
    periodStart = fromStr ? new Date(fromStr) : new Date(Date.now() - 30 * 86_400_000);
    periodEnd   = toStr   ? new Date(new Date(toStr).setHours(23, 59, 59, 999)) : new Date();
  } else {
    const ms: Record<string, number> = {
      today:  1 * 86_400_000,
      week:   7 * 86_400_000,
      month:  30 * 86_400_000,
      year:  365 * 86_400_000,
    };
    periodStart = new Date(Date.now() - (ms[period] ?? ms[defaultPeriod] ?? ms.month));
  }
  return { periodStart, periodEnd };
}

// ─── TRAFFIC ─────────────────────────────────────────────────────────────────
router.get("/admin/traffic", async (req, res): Promise<void> => {
  const { periodStart, periodEnd } = parsePeriod(req.query as Record<string, unknown>, "week");
  const activeSessions = await scalarCount(
    sessionsTable,
    eq(sessionsTable.status, "active"),
  );
  const totalVisits = await scalarCount(trafficEventsTable);

  // visits series — hourly for today, daily otherwise
  const visitsSeries =
    (req.query.period as string) === "today"
      ? await rawRows<{ time: string; visits: number }>(sql`
          select to_char(date_trunc('hour', created_at), 'HH24:MI') as time,
                 count(*)::int as visits
          from traffic_events
          where created_at >= ${periodStart} and created_at <= ${periodEnd}
          group by date_trunc('hour', created_at)
          order by date_trunc('hour', created_at)
        `)
      : await rawRows<{ time: string; visits: number }>(sql`
          select to_char(date_trunc('day', created_at), 'Mon DD') as time,
                 count(*)::int as visits
          from traffic_events
          where created_at >= ${periodStart} and created_at <= ${periodEnd}
          group by date_trunc('day', created_at)
          order by date_trunc('day', created_at)
        `);

  const countryRows = await rawRows<{ name: string; visits: number }>(sql`
    select coalesce(country, 'Unknown') as name, count(*)::int as visits
    from traffic_events
    where created_at >= ${periodStart} and created_at <= ${periodEnd}
    group by country
    order by count(*) desc
    limit 10
  `);
  const topCountries = countryRows.map((c) => ({
    name: c.name,
    visits: num(c.visits),
    share: totalVisits > 0 ? Math.round((num(c.visits) * 100) / totalVisits) : 0,
  }));

  const deviceRows = await rawRows<{ type: string; count: number }>(sql`
    select coalesce(device, 'Unknown') as type, count(*)::int as count
    from traffic_events
    where created_at >= ${periodStart} and created_at <= ${periodEnd}
    group by device
    order by count(*) desc
  `);
  const devices = deviceRows.map((d) => ({
    type: d.type,
    count: num(d.count),
    share: totalVisits > 0 ? Math.round((num(d.count) * 100) / totalVisits) : 0,
  }));

  const sessRows = await db
    .select()
    .from(sessionsTable)
    .where(eq(sessionsTable.status, "active"))
    .orderBy(desc(sessionsTable.startedAt))
    .limit(8);
  const activeSessionsList = sessRows.map((s) => ({
    id: `S-${s.id}`,
    user: s.userEmail,
    duration: formatDuration(s.durationSeconds),
    location: s.location ?? "—",
    profile: s.profile,
  }));

  res.json(
    GetAdminTrafficResponse.parse({
      activeSessions,
      totalVisits,
      visitsSeries,
      topCountries,
      devices,
      activeSessionsList,
    }),
  );
});

// ─── ANALYTICS ───────────────────────────────────────────────────────────────
router.get("/admin/analytics", async (req, res): Promise<void> => {
  const { periodStart, periodEnd } = parsePeriod(req.query as Record<string, unknown>, "month");

  const signupRows = await rawRows<{ k: string; name: string; signups: number }>(sql`
    select to_char(date_trunc('month', created_at), 'YYYY-MM') as k,
           to_char(date_trunc('month', created_at), 'Mon') as name,
           count(*)::int as signups
    from app_users
    where created_at >= ${periodStart} and created_at <= ${periodEnd}
    group by 1, 2
  `);
  const activeRows = await rawRows<{ k: string; name: string; active: number }>(sql`
    select to_char(date_trunc('month', started_at), 'YYYY-MM') as k,
           to_char(date_trunc('month', started_at), 'Mon') as name,
           count(distinct user_email)::int as active
    from sessions
    where started_at >= ${periodStart} and started_at <= ${periodEnd}
    group by 1, 2
  `);
  const growthMap = new Map<string, { name: string; signups: number; active: number }>();
  for (const r of signupRows)
    growthMap.set(r.k, { name: r.name, signups: num(r.signups), active: 0 });
  for (const r of activeRows) {
    const e = growthMap.get(r.k);
    if (e) e.active = num(r.active);
    else growthMap.set(r.k, { name: r.name, signups: 0, active: num(r.active) });
  }
  const newUsersSeries = [...growthMap.entries()]
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([, v]) => v);

  const featureUsage = (
    await rawRows<{ name: string; value: number }>(sql`
      select event_type as name, coalesce(sum(value), 0)::int as value
      from analytics_events
      group by event_type
      order by sum(value) desc
      limit 10
    `)
  ).map((r) => ({ name: r.name, value: num(r.value) }));

  const sessionVolume = (
    await rawRows<{ name: string; standard: number; premium: number }>(sql`
      select to_char(date_trunc('day', started_at), 'Mon DD') as name,
             count(*) filter (where profile = 'Standard')::int as standard,
             count(*) filter (where profile = 'Premium')::int as premium
      from sessions
      where started_at >= ${periodStart} and started_at <= ${periodEnd}
      group by date_trunc('day', started_at)
      order by date_trunc('day', started_at)
    `)
  ).map((r) => ({ name: r.name, standard: num(r.standard), premium: num(r.premium) }));

  const retention = (
    await rawRows<{
      cohort: string;
      users: number;
      w1: number;
      w2: number;
      w4: number;
      w8: number;
    }>(sql`
      select to_char(date_trunc('month', created_at), 'Mon YYYY') as cohort,
             count(*)::int as users,
             coalesce(round(100.0 * count(*) filter (where last_active_at >= created_at + interval '1 week') / nullif(count(*), 0)), 0)::int as w1,
             coalesce(round(100.0 * count(*) filter (where last_active_at >= created_at + interval '2 weeks') / nullif(count(*), 0)), 0)::int as w2,
             coalesce(round(100.0 * count(*) filter (where last_active_at >= created_at + interval '4 weeks') / nullif(count(*), 0)), 0)::int as w4,
             coalesce(round(100.0 * count(*) filter (where last_active_at >= created_at + interval '8 weeks') / nullif(count(*), 0)), 0)::int as w8
      from app_users
      group by date_trunc('month', created_at)
      order by date_trunc('month', created_at) desc
      limit 6
    `)
  ).map((r) => ({
    cohort: r.cohort,
    users: num(r.users),
    w1: num(r.w1),
    w2: num(r.w2),
    w4: num(r.w4),
    w8: num(r.w8),
  }));

  res.json(
    GetAdminAnalyticsResponse.parse({
      newUsersSeries,
      featureUsage,
      sessionVolume,
      retention,
    }),
  );
});

// ─── USERS ───────────────────────────────────────────────────────────────────
router.get("/admin/users", async (req, res): Promise<void> => {
  const { periodStart, periodEnd } = parsePeriod(req.query as Record<string, unknown>, "year");
  const users = await db
    .select()
    .from(usersTable)
    .where(and(gte(usersTable.createdAt, periodStart), lte(usersTable.createdAt, periodEnd)))
    .orderBy(desc(usersTable.createdAt));

  const sessRows = await db
    .select({ email: sessionsTable.userEmail, c: count() })
    .from(sessionsTable)
    .groupBy(sessionsTable.userEmail);
  const payRows = await db
    .select({ email: paymentsTable.userEmail, s: sum(paymentsTable.amountCents) })
    .from(paymentsTable)
    .where(eq(paymentsTable.status, "paid"))
    .groupBy(paymentsTable.userEmail);

  const sessMap = new Map(sessRows.map((r) => [r.email, num(r.c)]));
  const payMap = new Map(payRows.map((r) => [r.email, num(r.s)]));

  const payload = users.map((u) => ({
    id: u.id,
    name: u.name,
    email: u.email,
    plan: u.plan,
    status: u.status,
    created: u.createdAt,
    sessions: sessMap.get(u.email) ?? 0,
    spendCents: payMap.get(u.email) ?? 0,
  }));

  res.json(GetAdminUsersResponse.parse(payload));
});

// ─── PAYMENTS ────────────────────────────────────────────────────────────────
router.get("/admin/payments", async (req, res): Promise<void> => {
  const { periodStart, periodEnd } = parsePeriod(req.query as Record<string, unknown>, "month");
  const pays = await db
    .select()
    .from(paymentsTable)
    .where(and(gte(paymentsTable.createdAt, periodStart), lte(paymentsTable.createdAt, periodEnd)))
    .orderBy(desc(paymentsTable.createdAt));
  const payments = pays.map((p) => ({
    id: p.id,
    user: p.userEmail,
    plan: p.plan,
    amountCents: p.amountCents,
    status: p.status,
    date: p.createdAt,
    method: p.method,
  }));

  const revRows = await db
    .select({ v: sum(paymentsTable.amountCents) })
    .from(paymentsTable)
    .where(and(eq(paymentsTable.status, "paid"), gte(paymentsTable.createdAt, periodStart), lte(paymentsTable.createdAt, periodEnd)));
  const refundRows = await db
    .select({ c: count(), v: sum(paymentsTable.amountCents) })
    .from(paymentsTable)
    .where(and(eq(paymentsTable.status, "refunded"), gte(paymentsTable.createdAt, periodStart), lte(paymentsTable.createdAt, periodEnd)));

  const activeSubscriptions = await scalarCount(
    usersTable,
    and(
      inArray(usersTable.plan, ["standard", "premium"]),
      eq(usersTable.status, "active"),
    ),
  );
  const standardCount = await scalarCount(usersTable, eq(usersTable.plan, "standard"));
  const premiumCount = await scalarCount(usersTable, eq(usersTable.plan, "premium"));

  res.json(
    GetAdminPaymentsResponse.parse({
      summary: {
        revenueCents: num(revRows[0]?.v),
        activeSubscriptions,
        standardCount,
        premiumCount,
        refundCount: num(refundRows[0]?.c),
        refundAmountCents: num(refundRows[0]?.v),
      },
      payments,
    }),
  );
});

// ─── SECURITY ────────────────────────────────────────────────────────────────
router.get("/admin/security", async (req, res): Promise<void> => {
  const { periodStart, periodEnd } = parsePeriod(req.query as Record<string, unknown>, "month");

  const totalBlocks = await scalarCount(
    securityEventsTable,
    and(eq(securityEventsTable.status, "blocked"), gte(securityEventsTable.createdAt, periodStart), lte(securityEventsTable.createdAt, periodEnd)),
  );
  const criticalEvents = await scalarCount(
    securityEventsTable,
    and(eq(securityEventsTable.severity, "critical"), gte(securityEventsTable.createdAt, periodStart), lte(securityEventsTable.createdAt, periodEnd)),
  );
  const highSeverity = await scalarCount(
    securityEventsTable,
    and(eq(securityEventsTable.severity, "high"), gte(securityEventsTable.createdAt, periodStart), lte(securityEventsTable.createdAt, periodEnd)),
  );
  const vpnEvents = await scalarCount(
    securityEventsTable,
    and(ilike(securityEventsTable.type, "%vpn%"), gte(securityEventsTable.createdAt, periodStart), lte(securityEventsTable.createdAt, periodEnd)),
  );
  const failedLogins = await scalarCount(
    securityEventsTable,
    and(ilike(securityEventsTable.type, "%failed%"), gte(securityEventsTable.createdAt, periodStart), lte(securityEventsTable.createdAt, periodEnd)),
  );
  const suspiciousActivity = await scalarCount(
    securityEventsTable,
    and(ilike(securityEventsTable.type, "%suspicious%"), gte(securityEventsTable.createdAt, periodStart), lte(securityEventsTable.createdAt, periodEnd)),
  );

  const eventRows = await db
    .select()
    .from(securityEventsTable)
    .where(and(gte(securityEventsTable.createdAt, periodStart), lte(securityEventsTable.createdAt, periodEnd)))
    .orderBy(desc(securityEventsTable.createdAt))
    .limit(50);
  const events = eventRows.map((e) => ({
    id: e.id,
    time: e.createdAt,
    type: e.type,
    actor: e.userEmail ?? e.ipAddress ?? "System",
    target: e.ipAddress ?? "—",
    severity: cap(e.severity),
    details: e.description,
  }));

  res.json(
    GetAdminSecurityResponse.parse({
      metrics: {
        totalBlocks,
        criticalEvents,
        highSeverity,
        vpnEvents,
        failedLogins,
        suspiciousActivity,
      },
      events,
      adminSessions: [],
      roleUserCounts: { owner: 0, admin: 0, support: 0 },
    }),
  );
});

// ─── SUPPORT ─────────────────────────────────────────────────────────────────
router.get("/admin/support", async (req, res): Promise<void> => {
  const { periodStart, periodEnd } = parsePeriod(req.query as Record<string, unknown>, "month");
  const tickets = await db
    .select()
    .from(supportTicketsTable)
    .where(and(gte(supportTicketsTable.createdAt, periodStart), lte(supportTicketsTable.createdAt, periodEnd)))
    .orderBy(desc(supportTicketsTable.createdAt));
  const payload = tickets.map((t) => ({
    id: t.id,
    subject: t.subject,
    user: t.userEmail,
    priority: t.priority,
    status: t.status,
    createdAt: t.createdAt,
  }));

  res.json(GetAdminSupportResponse.parse(payload));
});

router.post("/admin/support/:id/reply", async (req, res): Promise<void> => {
  const ticketId = Number(req.params.id);
  if (!Number.isInteger(ticketId) || ticketId <= 0) { res.status(400).json({ error: "Invalid ticket id." }); return; }
  const { message } = req.body as { message?: string };
  if (!message?.trim()) { res.status(400).json({ error: "Message is required." }); return; }
  try {
    const [ticket] = await db.select().from(supportTicketsTable).where(eq(supportTicketsTable.id, ticketId)).limit(1);
    if (!ticket) { res.status(404).json({ error: "Ticket not found." }); return; }
    await db.insert(ticketMessagesTable).values({ ticketId, userEmail: "admin", message: message.trim(), isStaff: true });
    if (ticket.status === "Open") {
      await db.update(supportTicketsTable).set({ status: "Pending" }).where(eq(supportTicketsTable.id, ticketId));
    }
    res.json({ ok: true });
  } catch (err) {
    req.log.error({ err, ticketId }, "Failed to send admin reply");
    res.status(500).json({ error: "Failed to send reply." });
  }
});

router.patch("/admin/support/:id/status", async (req, res): Promise<void> => {
  const ticketId = Number(req.params.id);
  if (!Number.isInteger(ticketId) || ticketId <= 0) { res.status(400).json({ error: "Invalid ticket id." }); return; }
  const { status } = req.body as { status?: string };
  const allowed = ["Open", "Pending", "Closed"];
  if (!status || !allowed.includes(status)) { res.status(400).json({ error: "Invalid status." }); return; }
  try {
    const [updated] = await db
      .update(supportTicketsTable)
      .set({ status: status as "Open" | "Pending" | "Closed" })
      .where(eq(supportTicketsTable.id, ticketId))
      .returning();
    if (!updated) { res.status(404).json({ error: "Ticket not found." }); return; }
    res.json({ ok: true, status: updated.status });
  } catch (err) {
    req.log.error({ err, ticketId }, "Failed to update ticket status");
    res.status(500).json({ error: "Failed to update ticket status." });
  }
});

export default router;

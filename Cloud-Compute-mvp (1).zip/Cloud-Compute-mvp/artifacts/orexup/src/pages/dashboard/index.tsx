import { Link } from "wouter";
import { DashboardLayout } from "@/components/dashboard-layout";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Cloud, Activity, Shield, Puzzle, BarChart2, PlayCircle, HeadphonesIcon, Settings, Clock } from "lucide-react";
import { useAppContext } from "@/lib/app-context";
import { useUserAuth } from "@/lib/user-auth";

const PLAN_LABELS: Record<string, string> = {
  standard: "Standard",
  premium: "Premium",
  custom: "Custom",
};

export default function DashboardPage() {
  const { cloudConnected, sessionRunning, extensionInstalled, currentPlan } = useAppContext();
  const { user } = useUserAuth();

  return (
    <DashboardLayout title="Dashboard">
      <div className="space-y-8">
        <div>
          <h2 className="text-3xl font-bold font-heading tracking-tight">
            Welcome back, {user?.name?.split(" ")[0] ?? "there"}
          </h2>
          <p className="text-muted-foreground mt-2">Here's what's happening with your cloud environment today.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <Link href="/dashboard/connect-cloud">
            <Card className="border-white/5 bg-card/50 backdrop-blur-sm hover:bg-white/5 transition-colors cursor-pointer">
              <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
                <CardTitle className="text-sm font-medium">Cloud Status</CardTitle>
                <Cloud className={`h-4 w-4 ${cloudConnected ? "text-green-500" : "text-muted-foreground"}`} />
              </CardHeader>
              <CardContent>
                <Badge
                  variant={cloudConnected ? "default" : "destructive"}
                  className={cloudConnected ? "bg-green-500/10 text-green-500 hover:bg-green-500/20" : ""}
                >
                  {cloudConnected ? "Connected" : "Disconnected"}
                </Badge>
                <p className="text-xs text-muted-foreground mt-2">
                  {cloudConnected ? "Active connection" : "Click to connect"}
                </p>
              </CardContent>
            </Card>
          </Link>

          <Link href="/dashboard/cloud-session">
            <Card className="border-white/5 bg-card/50 backdrop-blur-sm hover:bg-white/5 transition-colors cursor-pointer">
              <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
                <CardTitle className="text-sm font-medium">Session</CardTitle>
                <Activity className={`h-4 w-4 ${sessionRunning ? "text-primary" : "text-muted-foreground"}`} />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold font-heading mb-1">
                  {sessionRunning ? "Running" : "Not Running"}
                </div>
                <p className="text-xs text-muted-foreground">
                  {sessionRunning ? "Session active" : "Ready to start"}
                </p>
              </CardContent>
            </Card>
          </Link>

          <Link href="/dashboard/billing">
            <Card className="border-white/5 bg-card/50 backdrop-blur-sm hover:bg-white/5 transition-colors cursor-pointer">
              <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
                <CardTitle className="text-sm font-medium">Current Plan</CardTitle>
                <Shield className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-2 mb-1">
                  <div className="text-2xl font-bold font-heading">{PLAN_LABELS[currentPlan]}</div>
                  <Badge variant="outline" className="text-xs">Active</Badge>
                </div>
                <p className="text-xs text-primary hover:underline">
                  {currentPlan === "standard" ? "Upgrade to Premium" : "Manage plan"}
                </p>
              </CardContent>
            </Card>
          </Link>

          <Link href="/dashboard/install-extension">
            <Card className="border-white/5 bg-card/50 backdrop-blur-sm hover:bg-white/5 transition-colors cursor-pointer">
              <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
                <CardTitle className="text-sm font-medium">Extension</CardTitle>
                <Puzzle className={`h-4 w-4 ${extensionInstalled ? "text-green-500" : "text-amber-500"}`} />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold font-heading mb-1">
                  {extensionInstalled ? "Installed" : "Not Installed"}
                </div>
                <p className="text-xs text-muted-foreground">
                  {extensionInstalled ? "Up to date" : "Required for full features"}
                </p>
              </CardContent>
            </Card>
          </Link>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <Card className="border-white/5 bg-card/50 backdrop-blur-sm">
            <CardHeader>
              <CardTitle>Recent Activity</CardTitle>
              <CardDescription>Your latest interactions and system events.</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col items-center justify-center py-10 text-center gap-3">
                <div className="p-3 rounded-full bg-white/5">
                  <Clock className="h-5 w-5 text-muted-foreground" />
                </div>
                <p className="text-sm text-muted-foreground">No recent activity yet.</p>
                <p className="text-xs text-muted-foreground/60">
                  Activity will appear here once you start using cloud sessions.
                </p>
              </div>
            </CardContent>
          </Card>

          <Card className="border-white/5 bg-card/50 backdrop-blur-sm overflow-hidden relative">
            <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-transparent to-transparent pointer-events-none" />
            <CardHeader>
              <CardTitle>Quick Actions</CardTitle>
            </CardHeader>
            <CardContent className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              <Link href="/dashboard/connect-cloud">
                <div className="p-4 border border-white/5 rounded-lg bg-white/5 hover:bg-white/10 transition-colors cursor-pointer group" data-testid="quick-action-cloud">
                  <Cloud className="h-5 w-5 text-primary mb-2 group-hover:scale-110 transition-transform" />
                  <h3 className="font-medium text-sm mb-0.5">Cloud Config</h3>
                  <p className="text-xs text-muted-foreground">Set up region &amp; resources</p>
                </div>
              </Link>
              <Link href="/dashboard/analytics">
                <div className="p-4 border border-white/5 rounded-lg bg-white/5 hover:bg-white/10 transition-colors cursor-pointer group" data-testid="quick-action-analytics">
                  <BarChart2 className="h-5 w-5 text-primary mb-2 group-hover:scale-110 transition-transform" />
                  <h3 className="font-medium text-sm mb-0.5">Analytics</h3>
                  <p className="text-xs text-muted-foreground">Session performance data</p>
                </div>
              </Link>
              <Link href="/dashboard/cloud-session">
                <div className="p-4 border border-white/5 rounded-lg bg-white/5 hover:bg-white/10 transition-colors cursor-pointer group" data-testid="quick-action-session">
                  <PlayCircle className="h-5 w-5 text-primary mb-2 group-hover:scale-110 transition-transform" />
                  <h3 className="font-medium text-sm mb-0.5">Sessions</h3>
                  <p className="text-xs text-muted-foreground">Start or view sessions</p>
                </div>
              </Link>
              <Link href="/dashboard/support">
                <div className="p-4 border border-white/5 rounded-lg bg-white/5 hover:bg-white/10 transition-colors cursor-pointer group" data-testid="quick-action-support">
                  <HeadphonesIcon className="h-5 w-5 text-primary mb-2 group-hover:scale-110 transition-transform" />
                  <h3 className="font-medium text-sm mb-0.5">Support</h3>
                  <p className="text-xs text-muted-foreground">Get help or open a ticket</p>
                </div>
              </Link>
              <Link href="/dashboard/settings">
                <div className="p-4 border border-white/5 rounded-lg bg-white/5 hover:bg-white/10 transition-colors cursor-pointer group" data-testid="quick-action-settings">
                  <Settings className="h-5 w-5 text-primary mb-2 group-hover:scale-110 transition-transform" />
                  <h3 className="font-medium text-sm mb-0.5">Settings</h3>
                  <p className="text-xs text-muted-foreground">Security &amp; preferences</p>
                </div>
              </Link>
            </CardContent>
          </Card>
        </div>
      </div>
    </DashboardLayout>
  );
}

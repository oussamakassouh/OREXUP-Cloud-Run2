import { pgTable, text, serial, boolean, timestamp } from "drizzle-orm/pg-core";

export const adminTwoFactorTable = pgTable("admin_two_factor", {
  id: serial("id").primaryKey(),
  adminEmail: text("admin_email").notNull().unique(),
  secret: text("secret").notNull(),
  enabled: boolean("enabled").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export type AdminTwoFactor = typeof adminTwoFactorTable.$inferSelect;

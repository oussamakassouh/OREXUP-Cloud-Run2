import { pgTable, text, serial, timestamp, index } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const trafficEventsTable = pgTable("traffic_events", {
  id: serial("id").primaryKey(),
  path: text("path").notNull(),
  country: text("country"),
  device: text("device"),
  source: text("source").notNull().default("direct"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [
  index("traffic_created_at_idx").on(t.createdAt),
  index("traffic_country_idx").on(t.country),
  index("traffic_source_idx").on(t.source),
]);

export const insertTrafficEventSchema = createInsertSchema(trafficEventsTable).omit({
  id: true,
  createdAt: true,
});
export type InsertTrafficEvent = z.infer<typeof insertTrafficEventSchema>;
export type TrafficEvent = typeof trafficEventsTable.$inferSelect;

import { useState, useEffect, useRef } from "react";
import { DashboardLayout } from "@/components/dashboard-layout";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Cpu, Zap, Monitor, Database, Play, Square, Loader2 } from "lucide-react";
import { useAppContext } from "@/lib/app-context";
import { cloudApi } from "@/lib/cloud-api";
import { useToast } from "@/hooks/use-toast";
import type { Profile } from "@/lib/app-context";

type SessionState = "Idle" | "Starting..." | "Running" | "Stopping..." | "Stopped";

const performanceModes: { id: Profile; name: string; icon: typeof Cpu; specs: string }[] = [
  { id: "balanced", name: "Balanced",    icon: Cpu,      specs: "CPU: 4 cores / RAM: 8 GB / Network: Standard" },
  { id: "cpu",      name: "High CPU",    icon: Zap,      specs: "CPU: 16 cores / RAM: 16 GB / Network: Standard" },
  { id: "gpu",      name: "High GPU",    icon: Monitor,  specs: "CPU: 8 cores / RAM: 16 GB / GPU: Accelerated" },
  { id: "memory",   name: "High Memory", icon: Database, specs: "CPU: 8 cores / RAM: 64 GB / Network: Standard" },
];

export default function CloudSessionPage() {
  const { sessionRunning, setSessionRunning, currentProfile, setCurrentProfile, setActiveSessionId, cloudRegion } = useAppContext();
  const { toast } = useToast();
  const [sessionState, setSessionState] = useState<SessionState>(sessionRunning ? "Running" : "Idle");
  const [elapsed, setElapsed] = useState(0);
  const [logs, setLogs] = useState<string[]>([
    `[${new Date().toLocaleTimeString("en", { hour12: false })}] Session terminal ready`,
    `[${new Date().toLocaleTimeString("en", { hour12: false })}] Region: ${cloudRegion}`,
  ]);
  const logEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => { logEndRef.current?.scrollIntoView({ behavior: "smooth" }); }, [logs]);

  useEffect(() => {
    let interval: ReturnType<typeof setInterval>;
    if (sessionState === "Running") interval = setInterval(() => setElapsed((p) => p + 1), 1000);
    else if (sessionState === "Idle") setElapsed(0);
    return () => clearInterval(interval);
  }, [sessionState]);

  const addLog = (msg: string) => {
    const t = new Date().toLocaleTimeString("en", { hour12: false });
    setLogs((prev) => [...prev, `[${t}] ${msg}`]);
  };

  const handleStart = async () => {
    const profile = performanceModes.find((m) => m.id === currentProfile)?.name ?? currentProfile;
    setSessionState("Starting...");
    addLog(`Initializing ${profile} profile...`);
    addLog(`Connecting to cloud node ${cloudRegion}...`);
    try {
      const session = await cloudApi.sessionStart(currentProfile);
      setActiveSessionId(session.sessionId);
      setSessionRunning(true);
      setSessionState("Running");
      addLog(`Session #${session.sessionId} started — ${profile} mode active`);
      addLog(`Started at ${new Date(session.startedAt).toLocaleTimeString("en", { hour12: false })}`);
    } catch (e) {
      setSessionState("Idle");
      addLog(`ERROR: ${(e as Error).message}`);
      toast({ title: "Session start failed", description: (e as Error).message, variant: "destructive" });
    }
  };

  const handleStop = async () => {
    setSessionState("Stopping...");
    addLog("Stopping session...");
    try {
      const session = await cloudApi.sessionStop();
      setActiveSessionId(null);
      setSessionRunning(false);
      addLog(`Session #${session.sessionId} stopped — duration: ${session.durationSeconds}s`);
      setSessionState("Stopped");
      setTimeout(() => { setSessionState("Idle"); addLog("Terminal ready."); }, 1200);
    } catch (e) {
      setSessionState("Running");
      addLog(`ERROR: ${(e as Error).message}`);
      toast({ title: "Stop failed", description: (e as Error).message, variant: "destructive" });
    }
  };

  const formatTime = (seconds: number) => {
    if (sessionState === "Idle") return "--:--:--";
    const h = Math.floor(seconds / 3600), m = Math.floor((seconds % 3600) / 60), s = seconds % 60;
    return `${String(h).padStart(2,"0")}:${String(m).padStart(2,"0")}:${String(s).padStart(2,"0")}`;
  };

  const isRunning = sessionState === "Running";
  const isBusy = sessionState === "Starting..." || sessionState === "Stopping...";

  return (
    <DashboardLayout title="Cloud Session">
      <div className="space-y-6">
        <Card className="border-white/5 bg-card/50 overflow-hidden">
          <CardContent className="p-8 flex flex-col items-center justify-center">
            <h2 className="text-sm font-medium text-muted-foreground uppercase tracking-wider mb-2">Session State</h2>
            <div className="flex items-center gap-3">
              {isBusy && <Loader2 className="h-8 w-8 text-amber-500 animate-spin" />}
              {isRunning && <div className="h-6 w-6 rounded-full bg-green-500 animate-pulse shadow-[0_0_20px_rgba(34,197,94,0.6)]" />}
              {sessionState === "Stopped" && <div className="h-6 w-6 rounded-full bg-red-500" />}
              {sessionState === "Idle" && <div className="h-6 w-6 rounded-full bg-muted-foreground" />}
              <span className={`text-4xl font-bold font-heading ${
                isBusy ? "text-amber-500" : isRunning ? "text-green-500"
                : sessionState === "Stopped" ? "text-red-500" : "text-muted-foreground"
              }`}>{sessionState}</span>
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card className="border-white/5 bg-card/50">
            <CardContent className="p-6">
              <div className="text-sm text-muted-foreground mb-1">Duration</div>
              <div className="text-2xl font-mono text-primary">{formatTime(elapsed)}</div>
            </CardContent>
          </Card>
          <Card className="border-white/5 bg-card/50">
            <CardContent className="p-6">
              <div className="text-sm text-muted-foreground mb-1">Status</div>
              <div className="text-2xl font-semibold">{sessionState}</div>
            </CardContent>
          </Card>
          <Card className="border-white/5 bg-card/50">
            <CardContent className="p-6">
              <div className="text-sm text-muted-foreground mb-1">Current Profile</div>
              <div className="text-2xl font-semibold capitalize">
                {performanceModes.find((m) => m.id === currentProfile)?.name ?? currentProfile}
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {performanceModes.map((m) => (
            <div key={m.id} onClick={() => !isRunning && !isBusy && setCurrentProfile(m.id)}
              className={`p-4 rounded-xl border transition-all duration-200 cursor-pointer ${
                currentProfile === m.id ? "border-primary bg-primary/5 shadow-[0_0_15px_-5px_rgba(var(--primary),0.3)]"
                : "border-white/5 bg-card/50 hover:bg-white/5"
              } ${isRunning || isBusy ? "opacity-50 cursor-not-allowed" : ""}`}
              data-testid={`session-profile-${m.id}`}>
              <div className="flex items-center gap-3 mb-2">
                <m.icon className={`h-5 w-5 ${currentProfile === m.id ? "text-primary" : "text-muted-foreground"}`} />
                <h4 className="font-semibold">{m.name}</h4>
              </div>
              <p className="text-xs text-muted-foreground">{m.specs}</p>
            </div>
          ))}
        </div>

        <div className="flex gap-4">
          <Button size="lg" className="flex-1 bg-green-600 hover:bg-green-700 text-white"
            onClick={handleStart} disabled={isRunning || isBusy} data-testid="cloud-session-start">
            {isBusy && sessionState === "Starting..." ? <Loader2 className="mr-2 h-5 w-5 animate-spin" /> : <Play className="mr-2 h-5 w-5" />}
            Start Session
          </Button>
          <Button size="lg" variant="outline" className="flex-1 border-red-500/50 text-red-500 hover:bg-red-500/10"
            onClick={handleStop} disabled={!isRunning} data-testid="cloud-session-stop">
            {isBusy && sessionState === "Stopping..." ? <Loader2 className="mr-2 h-5 w-5 animate-spin" /> : <Square className="mr-2 h-5 w-5" />}
            Stop Session
          </Button>
        </div>

        <div className="bg-black/50 border border-white/10 rounded-xl p-4 h-48 overflow-y-auto font-mono text-sm text-primary/80">
          {logs.map((log, i) => <div key={i} className="mb-1">{log}</div>)}
          <div ref={logEndRef} />
        </div>
      </div>
    </DashboardLayout>
  );
}

import { Router, type IRouter, type Request, type Response } from "express";
import { eq, desc } from "drizzle-orm";
import { db, userAccountsTable, paymentsTable, sessionsTable } from "@workspace/db";
import { userAuth, type AuthRequest } from "../middlewares/userJwtAuth";
import { logger } from "../lib/logger";

const router: IRouter = Router();
router.use(userAuth);

// GET /user/profile
router.get("/user/profile", async (req: Request, res: Response): Promise<void> => {
  const { userId } = req as AuthRequest;
  try {
    const [account] = await db
      .select({
        id: userAccountsTable.id,
        email: userAccountsTable.email,
        name: userAccountsTable.name,
        emailVerified: userAccountsTable.emailVerified,
        totpEnabled: userAccountsTable.totpEnabled,
        createdAt: userAccountsTable.createdAt,
        lastLoginAt: userAccountsTable.lastLoginAt,
      })
      .from(userAccountsTable)
      .where(eq(userAccountsTable.id, userId))
      .limit(1);

    if (!account) {
      res.status(404).json({ error: "User not found." });
      return;
    }
    res.json({ profile: account });
  } catch (err) {
    logger.error({ err }, "Get profile error");
    res.status(500).json({ error: "Failed to fetch profile." });
  }
});

// PUT /user/profile
router.put("/user/profile", async (req: Request, res: Response): Promise<void> => {
  const { userId } = req as AuthRequest;
  const { name } = req.body as { name?: string };
  if (!name || name.trim().length === 0) {
    res.status(400).json({ error: "Name is required." });
    return;
  }
  if (name.trim().length > 100) {
    res.status(400).json({ error: "Name must be 100 characters or fewer." });
    return;
  }
  try {
    const [updated] = await db
      .update(userAccountsTable)
      .set({ name: name.trim() })
      .where(eq(userAccountsTable.id, userId))
      .returning({
        id: userAccountsTable.id,
        email: userAccountsTable.email,
        name: userAccountsTable.name,
      });
    if (!updated) {
      res.status(404).json({ error: "User not found." });
      return;
    }
    logger.info({ userId }, "User profile updated");
    res.json({ profile: updated });
  } catch (err) {
    logger.error({ err }, "Update profile error");
    res.status(500).json({ error: "Failed to update profile." });
  }
});

// GET /user/subscription
router.get("/user/subscription", async (req: Request, res: Response): Promise<void> => {
  const { userEmail } = req as AuthRequest;
  try {
    const [latest] = await db
      .select()
      .from(paymentsTable)
      .where(eq(paymentsTable.userEmail, userEmail))
      .orderBy(desc(paymentsTable.createdAt))
      .limit(1);

    res.json({
      subscription: latest
        ? {
            plan: latest.plan,
            status: latest.status,
            amountCents: latest.amountCents,
            amountFormatted: `$${(latest.amountCents / 100).toFixed(2)}`,
            renewedAt: latest.createdAt,
          }
        : { plan: "free", status: "none", amountCents: 0, amountFormatted: "$0.00", renewedAt: null },
    });
  } catch (err) {
    logger.error({ err }, "Get subscription error");
    res.status(500).json({ error: "Failed to fetch subscription." });
  }
});

// GET /user/usage
router.get("/user/usage", async (req: Request, res: Response): Promise<void> => {
  const { userEmail } = req as AuthRequest;
  try {
    const sessions = await db
      .select()
      .from(sessionsTable)
      .where(eq(sessionsTable.userEmail, userEmail))
      .orderBy(desc(sessionsTable.startedAt))
      .limit(100);

    const totalSeconds = sessions.reduce((acc, s) => acc + (s.durationSeconds ?? 0), 0);
    const activeSessions = sessions.filter((s) => s.status === "active").length;

    res.json({
      usage: {
        totalSessions: sessions.length,
        activeSessions,
        totalDurationSeconds: totalSeconds,
        avgDurationSeconds: sessions.length > 0 ? Math.floor(totalSeconds / sessions.length) : 0,
        recentSessions: sessions.slice(0, 5).map((s) => ({
          id: s.id,
          profile: s.profile,
          status: s.status,
          location: s.location ?? null,
          durationSeconds: s.durationSeconds,
          startedAt: s.startedAt,
          endedAt: s.endedAt ?? null,
        })),
      },
    });
  } catch (err) {
    logger.error({ err }, "Get usage error");
    res.status(500).json({ error: "Failed to fetch usage." });
  }
});

export default router;

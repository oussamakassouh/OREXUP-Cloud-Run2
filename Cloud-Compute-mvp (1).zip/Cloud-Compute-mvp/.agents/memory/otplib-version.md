---
name: otplib version for TOTP
description: Which otplib major to use for the simple authenticator API in this api-server
---

Use **otplib v12** (`otplib@12.0.1`) for TOTP in `artifacts/api-server`.

**Why:** otplib v13 dropped the convenient `authenticator` singleton and switched to a
plugin-based API (functional `generate`/`verify`/`generateSecret` + `TOTP` class, requiring
crypto/base32 plugins). `import { authenticator } from "otplib"` fails to typecheck on v13.
v12 re-exports `@otplib/preset-default` so `authenticator.generateSecret()`,
`authenticator.keyuri(user, issuer, secret)`, and `authenticator.verify({token, secret})` work directly.

**How to apply:** If TOTP code throws "Module 'otplib' has no exported member 'authenticator'",
the installed major is 13 — pin to 12. The api-server is ESM + esbuild-bundled; v12 bundles fine.

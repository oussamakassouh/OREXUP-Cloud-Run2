import { useState } from "react";
import { AdminLayout } from "@/components/admin-layout";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Search, Eye, Ban, Trash2, Download } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription } from "@/components/ui/sheet";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { useGetAdminUsers, type AdminUser } from "@workspace/api-client-react";
import { PeriodFilter, usePeriodFilter } from "@/components/period-filter";

const PAGE_SIZE = 8;

function cap(s: string) {
  return s.charAt(0).toUpperCase() + s.slice(1);
}
function formatDate(iso: string) {
  return new Date(iso).toISOString().split("T")[0];
}
function formatCents(cents: number) {
  return `$${(cents / 100).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

export default function AdminUsersPage() {
  const { period, setPeriod, customFrom, setCustomFrom, customTo, setCustomTo, apply, queryParams } =
    usePeriodFilter("year");

  const { data, isLoading, isError } = useGetAdminUsers(queryParams);
  const users: AdminUser[] = data ?? [];
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState("All");
  const [page, setPage] = useState(1);
  const [selectedUser, setSelectedUser] = useState<AdminUser | null>(null);
  const [deleteUser, setDeleteUser] = useState<AdminUser | null>(null);
  const { toast } = useToast();

  const filteredUsers = users.filter((u) => {
    if (filter !== "All" && filter.toLowerCase() !== u.status.toLowerCase() && filter.toLowerCase() !== u.plan.toLowerCase()) return false;
    if (search && !u.email.includes(search) && !String(u.id).includes(search)) return false;
    return true;
  });

  const totalPages = Math.max(1, Math.ceil(filteredUsers.length / PAGE_SIZE));
  const currentPage = Math.min(page, totalPages);
  const pagedUsers = filteredUsers.slice((currentPage - 1) * PAGE_SIZE, currentPage * PAGE_SIZE);

  const handleSearchChange = (val: string) => { setSearch(val); setPage(1); };
  const handleFilterChange = (val: string) => { setFilter(val); setPage(1); };

  const handleExportCSV = () => {
    const headers = ["User ID", "Name", "Email", "Plan", "Status", "Created", "Sessions", "Spend"];
    const rows = filteredUsers.map((u) => [u.id, u.name, u.email, cap(u.plan), cap(u.status), formatDate(u.created), u.sessions, formatCents(u.spendCents)]);
    const csv = [headers, ...rows].map((r) => r.map((c) => `"${String(c).replace(/"/g, '""')}"`).join(",")).join("\n");
    const blob = new Blob(["\uFEFF" + csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `orexup-users-${new Date().toISOString().split("T")[0]}.csv`;
    link.click();
    URL.revokeObjectURL(url);
    toast({ title: "Export complete", description: `${filteredUsers.length} users exported to CSV.` });
  };

  const handleSuspend = (user: AdminUser) => {
    toast({ title: "Action recorded", description: `Suspension toggle for ${user.email} is not yet wired to the database.` });
  };

  const handleDelete = () => {
    if (deleteUser) {
      toast({ title: "Action recorded", description: `Deletion for ${deleteUser.email} is not yet wired to the database.`, variant: "destructive" });
      setDeleteUser(null);
    }
  };

  return (
    <AdminLayout title="User Management">
      <div className="space-y-4">
        <PeriodFilter
          period={period} onPeriodChange={setPeriod}
          customFrom={customFrom} customTo={customTo}
          onCustomFromChange={setCustomFrom} onCustomToChange={setCustomTo}
          onApply={apply}
        />

        <div className="flex flex-col sm:flex-row gap-4 justify-between items-start sm:items-center">
          <div className="flex items-center gap-2 w-full sm:w-auto">
            <div className="relative w-full sm:w-64">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search email or ID..."
                className="pl-9 bg-card/50"
                value={search}
                onChange={(e) => handleSearchChange(e.target.value)}
              />
            </div>
            <Select value={filter} onValueChange={handleFilterChange}>
              <SelectTrigger className="w-[140px] bg-card/50">
                <SelectValue placeholder="Filter" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="All">All Users</SelectItem>
                <SelectItem value="Active">Active</SelectItem>
                <SelectItem value="Suspended">Suspended</SelectItem>
                <SelectItem value="Free">Free Plan</SelectItem>
                <SelectItem value="Standard">Standard Plan</SelectItem>
                <SelectItem value="Premium">Premium Plan</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <Button variant="outline" className="bg-card/50" onClick={handleExportCSV} data-testid="button-export-csv" disabled={filteredUsers.length === 0}>
            <Download className="mr-2 h-4 w-4" />
            Export CSV
          </Button>
        </div>

        <Card className="border-white/5 bg-card/50">
          <Table>
            <TableHeader>
              <TableRow className="border-white/5 hover:bg-transparent">
                <TableHead>User ID</TableHead>
                <TableHead>Email</TableHead>
                <TableHead>Plan</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Created Date</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {pagedUsers.map((user) => (
                <TableRow key={user.id} className="border-white/5 hover:bg-white/5">
                  <TableCell className="font-medium font-mono text-xs">USR-{user.id}</TableCell>
                  <TableCell>{user.email}</TableCell>
                  <TableCell>
                    <Badge variant="outline" className={
                      user.plan.toLowerCase() === "premium" ? "text-purple-400 border-purple-400/20 bg-purple-400/10" :
                      user.plan.toLowerCase() === "standard" ? "text-primary border-primary/20 bg-primary/10" : ""
                    }>
                      {cap(user.plan)}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <Badge variant={user.status.toLowerCase() === "active" ? "default" : "destructive"} className={
                      user.status.toLowerCase() === "active" ? "bg-green-500/10 text-green-500 hover:bg-green-500/20" : ""
                    }>
                      {cap(user.status)}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-muted-foreground text-sm">{formatDate(user.created)}</TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end gap-1">
                      <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-white" onClick={() => setSelectedUser(user)}>
                        <Eye className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-amber-500 hover:bg-amber-500/10" onClick={() => handleSuspend(user)}>
                        <Ban className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-red-500 hover:bg-red-500/10" onClick={() => setDeleteUser(user)}>
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
              {filteredUsers.length === 0 && (
                <TableRow>
                  <TableCell colSpan={6} className="text-center py-8 text-muted-foreground">
                    {isLoading ? "Loading…" : isError ? "Failed to load users." : "No data available"}
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>

          <div className="p-4 border-t border-white/5 flex items-center justify-between text-sm text-muted-foreground">
            <div>
              {filteredUsers.length === 0
                ? "No results"
                : `Showing ${(currentPage - 1) * PAGE_SIZE + 1}–${Math.min(currentPage * PAGE_SIZE, filteredUsers.length)} of ${filteredUsers.length} users`}
            </div>
            <div className="flex items-center gap-2">
              <span className="text-xs">Page {currentPage} of {totalPages}</span>
              <Button variant="outline" size="sm" disabled={currentPage <= 1} onClick={() => setPage((p) => Math.max(1, p - 1))} data-testid="button-prev-page">
                Previous
              </Button>
              <Button variant="outline" size="sm" disabled={currentPage >= totalPages} onClick={() => setPage((p) => Math.min(totalPages, p + 1))} data-testid="button-next-page">
                Next
              </Button>
            </div>
          </div>
        </Card>
      </div>

      <Sheet open={!!selectedUser} onOpenChange={(o) => !o && setSelectedUser(null)}>
        <SheetContent className="bg-[#0a0f16] border-white/10 sm:max-w-md">
          <SheetHeader className="pb-6 border-b border-white/5">
            <SheetTitle>User Details</SheetTitle>
            <SheetDescription>Detailed view of user account.</SheetDescription>
          </SheetHeader>
          {selectedUser && (
            <div className="py-6 space-y-6">
              <div className="flex items-center gap-4">
                <Avatar className="h-16 w-16 border border-white/10">
                  <AvatarFallback className="bg-primary/20 text-primary text-xl">
                    {selectedUser.name.charAt(0)}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <h3 className="font-semibold text-lg">{selectedUser.name}</h3>
                  <p className="text-muted-foreground text-sm">{selectedUser.email}</p>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <p className="text-xs text-muted-foreground">User ID</p>
                  <p className="font-mono text-sm">USR-{selectedUser.id}</p>
                </div>
                <div className="space-y-1">
                  <p className="text-xs text-muted-foreground">Joined</p>
                  <p className="text-sm">{formatDate(selectedUser.created)}</p>
                </div>
                <div className="space-y-1">
                  <p className="text-xs text-muted-foreground">Status</p>
                  <Badge variant={selectedUser.status.toLowerCase() === "active" ? "default" : "destructive"} className={
                    selectedUser.status.toLowerCase() === "active" ? "bg-green-500/10 text-green-500" : ""
                  }>
                    {cap(selectedUser.status)}
                  </Badge>
                </div>
                <div className="space-y-1">
                  <p className="text-xs text-muted-foreground">Plan</p>
                  <p className="text-sm font-medium">{cap(selectedUser.plan)}</p>
                </div>
                <div className="space-y-1">
                  <p className="text-xs text-muted-foreground">Total Sessions</p>
                  <p className="text-sm font-medium">{selectedUser.sessions}</p>
                </div>
                <div className="space-y-1">
                  <p className="text-xs text-muted-foreground">Total Spend</p>
                  <p className="text-sm font-medium">{formatCents(selectedUser.spendCents)}</p>
                </div>
              </div>
            </div>
          )}
        </SheetContent>
      </Sheet>

      <AlertDialog open={!!deleteUser} onOpenChange={(o) => !o && setDeleteUser(null)}>
        <AlertDialogContent className="bg-[#0a0f16] border-white/10">
          <AlertDialogHeader>
            <AlertDialogTitle>Delete user {deleteUser?.email}?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone. This will permanently delete the user account and remove their data from our servers.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="bg-white/5 border-white/10 hover:bg-white/10">Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-red-500 hover:bg-red-600 text-white">Delete User</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </AdminLayout>
  );
}

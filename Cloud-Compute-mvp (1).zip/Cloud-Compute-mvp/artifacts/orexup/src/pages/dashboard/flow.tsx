import { DashboardLayout } from "@/components/dashboard-layout";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Check, BookOpen, Video, Users } from "lucide-react";
import { Link } from "wouter";

const steps = [
  { id: 1, title: "Install Extension", desc: "Download and install the OREXUP browser extension from the Chrome Web Store", status: "completed" },
  { id: 2, title: "Connect Cloud", desc: "Link your OREXUP account to the cloud performance network", status: "completed" },
  { id: 3, title: "Choose Mode", desc: "Select a performance profile that fits your workload", status: "current" },
  { id: 4, title: "Start Session", desc: "Launch your cloud-accelerated browser session", status: "pending" },
  { id: 5, title: "Track Metrics", desc: "Monitor real-time performance data across all dimensions", status: "pending" },
  { id: 6, title: "Stop Session", desc: "End the session and review your performance report", status: "pending" },
];

export default function FlowPage() {
  return (
    <DashboardLayout title="Setup Flow">
      <div className="max-w-3xl mx-auto space-y-12 pb-12">
        
        <div className="relative pl-8 md:pl-12">
          {/* Vertical Line */}
          <div className="absolute left-[27px] md:left-[43px] top-4 bottom-4 w-0.5 bg-gradient-to-b from-green-500 via-primary to-white/10" />

          <div className="space-y-8">
            {steps.map((step, idx) => (
              <div key={step.id} className="relative">
                {/* Step Circle */}
                <div className={`absolute -left-12 md:-left-16 top-1 h-8 w-8 rounded-full border-4 border-background flex items-center justify-center z-10
                  ${step.status === 'completed' ? 'bg-green-500 text-background' : 
                    step.status === 'current' ? 'bg-primary text-background shadow-[0_0_15px_rgba(var(--primary),0.8)] animate-pulse' : 
                    'bg-muted text-muted-foreground border-white/20'}`}
                >
                  {step.status === 'completed' ? <Check className="h-4 w-4" /> : <span className="text-xs font-bold">{step.id}</span>}
                </div>

                <Card className={`border-white/5 ${step.status === 'current' ? 'bg-primary/5 border-primary/30' : 'bg-card/50 opacity-80'}`}>
                  <CardContent className="p-6">
                    <div className="flex justify-between items-start gap-4">
                      <div>
                        <h3 className={`font-bold font-heading text-lg mb-1 ${step.status === 'current' ? 'text-primary' : ''}`}>
                          {step.title}
                        </h3>
                        <p className="text-sm text-muted-foreground">{step.desc}</p>
                      </div>
                      <div className="hidden sm:block">
                        <span className={`text-xs px-2 py-1 rounded-full uppercase tracking-wider font-semibold
                          ${step.status === 'completed' ? 'bg-green-500/10 text-green-500' : 
                            step.status === 'current' ? 'bg-primary/10 text-primary' : 
                            'bg-white/5 text-muted-foreground'}`}
                        >
                          {step.status}
                        </span>
                      </div>
                    </div>
                    {step.status === 'current' && (
                      <div className="mt-6">
                        <Link href="/dashboard/cloud-session">
                          <Button className="bg-primary text-primary-foreground hover:bg-primary/90">
                            Continue Setup
                          </Button>
                        </Link>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>
            ))}
          </div>
        </div>

        <div className="pt-8 border-t border-white/5">
          <h3 className="text-xl font-bold font-heading mb-6">Getting Started Guide</h3>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="block group cursor-default">
              <Card className="border-white/5 bg-card/50 h-full">
                <CardContent className="p-6 flex flex-col items-center text-center">
                  <BookOpen className="h-8 w-8 text-primary mb-3" />
                  <div className="font-semibold mb-1">Documentation</div>
                  <div className="text-xs text-muted-foreground">Coming soon</div>
                </CardContent>
              </Card>
            </div>
            <div className="block group cursor-default">
              <Card className="border-white/5 bg-card/50 h-full">
                <CardContent className="p-6 flex flex-col items-center text-center">
                  <Video className="h-8 w-8 text-primary mb-3" />
                  <div className="font-semibold mb-1">Video Tutorial</div>
                  <div className="text-xs text-muted-foreground">Coming soon</div>
                </CardContent>
              </Card>
            </div>
            <div className="block group cursor-default">
              <Card className="border-white/5 bg-card/50 h-full">
                <CardContent className="p-6 flex flex-col items-center text-center">
                  <Users className="h-8 w-8 text-primary mb-3" />
                  <div className="font-semibold mb-1">Community</div>
                  <div className="text-xs text-muted-foreground">Coming soon</div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>

      </div>
    </DashboardLayout>
  );
}

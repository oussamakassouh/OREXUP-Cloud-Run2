import { Router, type IRouter, type Request, type Response } from "express";
import { randomUUID } from "crypto";
import { eq } from "drizzle-orm";
import { db, cloudConnectionsTable, sessionsTable } from "@workspace/db";
import { logger } from "../lib/logger";

const router: IRouter = Router();

const RESOURCE_PROFILES = [
  { id: "balanced", name: "Balanced",          description: "Balanced CPU and memory for general workloads",       cpuCores: 2, memoryGb: 4  },
  { id: "cpu",      name: "CPU Optimized",      description: "High-performance CPU for compute-intensive tasks",    cpuCores: 8, memoryGb: 8  },
  { id: "gpu",      name: "GPU Accelerated",    description: "GPU-accelerated processing for graphics workloads",  cpuCores: 4, memoryGb: 16 },
  { id: "memory",   name: "Memory Optimized",   description: "Large memory for data-intensive workloads",          cpuCores: 4, memoryGb: 32 },
];

const REGIONS = [
  { id: "us-east-1",      name: "US East (N. Virginia)" },
  { id: "eu-west-1",      name: "Europe (Ireland)"       },
  { id: "ap-southeast-1", name: "Asia Pacific (Singapore)" },
];

async function requireBearerConn(req: Request, res: Response): Promise<typeof cloudConnectionsTable.$inferSelect | null> {
  const auth = req.headers.authorization ?? "";
  const token = auth.startsWith("Bearer ") ? auth.slice(7).trim() : "";
  if (!token) {
    res.status(401).json({ error: "Missing Bearer token. Call POST /api/cloud/connect first." });
    return null;
  }
  const [conn] = await db
    .select()
    .from(cloudConnectionsTable)
    .where(eq(cloudConnectionsTable.token, token))
    .limit(1);
  if (!conn) {
    res.status(401).json({ error: "Invalid or expired token." });
    return null;
  }
  await db
    .update(cloudConnectionsTable)
    .set({ lastSeenAt: new Date() })
    .where(eq(cloudConnectionsTable.id, conn.id));
  return conn;
}

// POST /cloud/connect
router.post("/cloud/connect", async (req: Request, res: Response): Promise<void> => {
  const { email, profile, region } = req.body as { email?: string; profile?: string; region?: string };
  if (!email || !email.includes("@")) {
    res.status(400).json({ error: "Valid email required." });
    return;
  }
  const validProfiles = RESOURCE_PROFILES.map((p) => p.id);
  const safeProfile = validProfiles.includes(profile ?? "") ? profile! : "balanced";
  const validRegions = REGIONS.map((r) => r.id);
  const safeRegion = validRegions.includes(region ?? "") ? region! : "us-east-1";
  const token = randomUUID();

  await db
    .update(cloudConnectionsTable)
    .set({ status: "disconnected", disconnectedAt: new Date() })
    .where(eq(cloudConnectionsTable.userEmail, email.toLowerCase().trim()));

  const [conn] = await db
    .insert(cloudConnectionsTable)
    .values({ token, userEmail: email.toLowerCase().trim(), profile: safeProfile, region: safeRegion, status: "connected" })
    .returning();

  logger.info({ email, profile: safeProfile, region: safeRegion }, "Cloud connected");
  res.json({ token: conn.token, connectionId: conn.id, region: conn.region, profile: conn.profile, connectedAt: conn.connectedAt });
});

// POST /cloud/disconnect
router.post("/cloud/disconnect", async (req: Request, res: Response): Promise<void> => {
  const conn = await requireBearerConn(req, res);
  if (!conn) return;

  if (conn.activeSessionId) {
    await db
      .update(sessionsTable)
      .set({ status: "stopped", endedAt: new Date() })
      .where(eq(sessionsTable.id, conn.activeSessionId));
  }

  await db
    .update(cloudConnectionsTable)
    .set({ status: "disconnected", disconnectedAt: new Date(), activeSessionId: null })
    .where(eq(cloudConnectionsTable.id, conn.id));

  logger.info({ connectionId: conn.id }, "Cloud disconnected");
  res.json({ disconnected: true, connectionId: conn.id });
});

// GET /cloud/status
router.get("/cloud/status", async (req: Request, res: Response): Promise<void> => {
  const conn = await requireBearerConn(req, res);
  if (!conn) return;

  let session = null;
  if (conn.activeSessionId) {
    const [s] = await db.select().from(sessionsTable).where(eq(sessionsTable.id, conn.activeSessionId)).limit(1);
    if (s) {
      const dur = s.status === "active"
        ? Math.floor((Date.now() - new Date(s.startedAt).getTime()) / 1000)
        : s.durationSeconds;
      session = { sessionId: s.id, profile: s.profile, status: s.status, startedAt: s.startedAt, endedAt: s.endedAt ?? null, durationSeconds: dur };
    }
  }

  res.json({
    connected: conn.status === "connected",
    connectionId: conn.id,
    region: conn.region,
    profile: conn.profile,
    session,
    connectedAt: conn.connectedAt,
    lastSeenAt: conn.lastSeenAt,
  });
});

// GET /cloud/resources
router.get("/cloud/resources", (_req: Request, res: Response): void => {
  res.json({ profiles: RESOURCE_PROFILES, regions: REGIONS });
});

export default router;

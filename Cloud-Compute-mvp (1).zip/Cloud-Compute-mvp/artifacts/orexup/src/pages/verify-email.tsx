import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { MailCheck, ArrowLeft, RefreshCw, CheckCircle2, Loader2 } from "lucide-react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Layout } from "@/components/layout";
import { AuthSteps } from "@/components/auth-steps";
import { useToast } from "@/hooks/use-toast";
import { useI18n } from "@/lib/i18n";

const BASE = import.meta.env.BASE_URL?.replace(/\/$/, "") ?? "";

function getToken(): string | null {
  const params = new URLSearchParams(window.location.search);
  return params.get("token");
}

function getPendingEmail(): string | null {
  try { return sessionStorage.getItem("orexup_pending_email"); } catch { return null; }
}

export default function VerifyEmail() {
  const { toast } = useToast();
  const { t } = useI18n();
  const [, setLocation] = useLocation();
  const [verifying, setVerifying] = useState(false);
  const [verified, setVerified] = useState(false);
  const [resendLoading, setResendLoading] = useState(false);
  const [resendSent, setResendSent] = useState(false);
  const token = getToken();
  const pendingEmail = getPendingEmail();

  useEffect(() => {
    if (!token) return;
    setVerifying(true);
    fetch(`${BASE}/api/auth/verify-email?token=${token}`, { credentials: "include" })
      .then(async (res) => {
        if (res.ok) {
          setVerified(true);
          toast({ title: t.verifyEmail.toastVerifiedTitle, description: t.verifyEmail.toastVerifiedDesc });
          setTimeout(() => setLocation("/signin"), 2000);
        } else {
          const data = await res.json() as { error?: string };
          toast({ title: t.verifyEmail.toastFailTitle, description: data.error ?? t.verifyEmail.toastFailDefault, variant: "destructive" });
        }
      })
      .catch(() => {
        toast({ title: t.verifyEmail.toastNetworkTitle, description: t.verifyEmail.toastNetworkDesc, variant: "destructive" });
      })
      .finally(() => setVerifying(false));
  }, [token]);

  async function handleResend() {
    if (!pendingEmail) {
      toast({ title: t.verifyEmail.toastNoPendingTitle, description: t.verifyEmail.toastNoPendingDesc, variant: "destructive" });
      return;
    }
    setResendLoading(true);
    try {
      await fetch(`${BASE}/api/auth/resend-verification`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: pendingEmail }),
        credentials: "include",
      });
      // Always show success — endpoint is anti-enumeration and always returns 200
      toast({ title: t.verifyEmail.toastResendTitle, description: `Check ${pendingEmail} for the link.` });
      setResendSent(true);
    } catch {
      toast({ title: t.verifyEmail.toastNetworkTitle, description: t.verifyEmail.toastNetworkDesc, variant: "destructive" });
    } finally {
      setResendLoading(false);
    }
  }

  return (
    <Layout>
      <div className="min-h-[calc(100vh-16rem)] flex items-center justify-center p-4 relative">
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#80808012_1px,transparent_1px),linear-gradient(to_bottom,#80808012_1px,transparent_1px)] bg-[size:24px_24px] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_0%,#000_70%,transparent_100%)] pointer-events-none" />

        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.4 }}
          className="w-full max-w-md relative z-10"
        >
          <AuthSteps current={2} />

          <Card className="border-white/10 bg-card/80 backdrop-blur-xl shadow-2xl text-center">
            <CardHeader className="pt-10 pb-6">
              <div className="mx-auto w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mb-6">
                {verified
                  ? <CheckCircle2 className="h-8 w-8 text-green-500" />
                  : verifying
                  ? <Loader2 className="h-8 w-8 text-primary animate-spin" />
                  : <MailCheck className="h-8 w-8 text-primary" />}
              </div>
              <CardTitle className="text-2xl font-bold font-heading">
                {verified ? t.verifyEmail.titleDone : t.verifyEmail.titlePending}
              </CardTitle>
              <CardDescription className="text-base mt-2">
                {verified ? (
                  t.verifyEmail.descDone
                ) : verifying ? (
                  t.verifyEmail.descVerifying
                ) : pendingEmail ? (
                  <>
                    {t.verifyEmail.descPendingPrefix}{" "}
                    <span className="font-medium text-foreground">{pendingEmail}</span>
                    {t.verifyEmail.descPendingSuffix}
                  </>
                ) : (
                  t.verifyEmail.descGeneric
                )}
              </CardDescription>
            </CardHeader>

            {!verified && !verifying && (
              <CardContent className="pb-2 space-y-3 px-6">
                <p className="text-xs text-muted-foreground bg-amber-500/10 border border-amber-500/20 text-amber-400 rounded-lg px-4 py-2">
                  {t.verifyEmail.inactiveWarning}
                </p>

                <Button
                  variant="outline"
                  className="w-full"
                  onClick={handleResend}
                  disabled={resendLoading || resendSent}
                  data-testid="button-resend-email"
                >
                  {resendLoading
                    ? <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    : <RefreshCw className="mr-2 h-4 w-4" />}
                  {resendSent ? t.verifyEmail.resentBtn : t.verifyEmail.resendBtn}
                </Button>
              </CardContent>
            )}

            <CardFooter className="flex justify-center border-t border-white/5 pt-6 pb-8 mt-4">
              <a
                href="/signin"
                className="flex items-center text-sm text-muted-foreground hover:text-foreground transition-colors"
                data-testid="link-back-to-login"
              >
                <ArrowLeft className="mr-2 h-4 w-4" />
                {t.verifyEmail.backToSignIn}
              </a>
            </CardFooter>
          </Card>
        </motion.div>
      </div>
    </Layout>
  );
}

import DOMPurify from "dompurify";
import { Layout } from "@/components/layout";
import { useGetPublicJobListings } from "@workspace/api-client-react";
import { Loader2, MapPin, Clock, Briefcase, AlertCircle, Mail } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription,
} from "@/components/ui/dialog";
import { useState } from "react";
import type { JobListing } from "@workspace/api-client-react";

export default function CareersPage() {
  const { data: jobs = [], isLoading, isError } = useGetPublicJobListings();
  const [selected, setSelected] = useState<JobListing | null>(null);

  return (
    <Layout>
      <div className="container mx-auto px-4 py-16 max-w-4xl">
        <div className="mb-12">
          <h1 className="text-3xl md:text-4xl font-bold font-heading tracking-tight mb-3">Careers</h1>
          <p className="text-muted-foreground">Join the OREXUP team and help shape the future of cloud performance.</p>
        </div>

        {isLoading && (
          <div className="flex items-center justify-center py-24">
            <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
          </div>
        )}

        {isError && (
          <div className="flex flex-col items-center justify-center py-24 gap-3 text-muted-foreground">
            <AlertCircle className="h-6 w-6 text-destructive" />
            <p className="text-sm">Failed to load positions. Please try again later.</p>
          </div>
        )}

        {!isLoading && !isError && jobs.length === 0 && (
          <div className="text-center py-24 text-muted-foreground">
            No open positions right now. Check back soon.
          </div>
        )}

        <div className="space-y-4">
          {jobs.map((job) => (
            <Card key={job.id} className="border-white/5 bg-card/50 hover:bg-card/80 transition">
              <CardContent className="p-6">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2.5 flex-wrap mb-2">
                      <h2 className="text-base font-semibold font-heading">{job.title}</h2>
                      {job.department && (
                        <Badge variant="outline" className="text-xs bg-primary/10 text-primary border-primary/20">{job.department}</Badge>
                      )}
                    </div>
                    <div className="flex items-center gap-4 text-xs text-muted-foreground mb-4">
                      <span className="flex items-center gap-1.5"><MapPin className="h-3.5 w-3.5" />{job.location}</span>
                      <span className="flex items-center gap-1.5"><Clock className="h-3.5 w-3.5" />{job.type}</span>
                    </div>
                  </div>
                  <Button size="sm" onClick={() => setSelected(job)}>
                    <Briefcase className="h-4 w-4 mr-2" />View Role
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      <Dialog open={!!selected} onOpenChange={(o) => { if (!o) setSelected(null); }}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{selected?.title}</DialogTitle>
            <DialogDescription className="flex items-center gap-4 text-xs mt-1">
              {selected?.department && <span>{selected.department}</span>}
              <span className="flex items-center gap-1"><MapPin className="h-3 w-3" />{selected?.location}</span>
              <span className="flex items-center gap-1"><Clock className="h-3 w-3" />{selected?.type}</span>
            </DialogDescription>
          </DialogHeader>
          {selected?.description && (
            <div>
              <h3 className="text-sm font-semibold mb-2">About the role</h3>
              <div className="prose prose-invert prose-sm max-w-none" dangerouslySetInnerHTML={{ __html: DOMPurify.sanitize(selected.description) }} />
            </div>
          )}
          {selected?.requirements && (
            <div>
              <h3 className="text-sm font-semibold mb-2 mt-4">Requirements</h3>
              <div className="prose prose-invert prose-sm max-w-none" dangerouslySetInnerHTML={{ __html: DOMPurify.sanitize(selected.requirements) }} />
            </div>
          )}
          <div className="pt-4">
            <Button
              className="w-full"
              onClick={() => {
                window.location.href = `mailto:careers@orexup.com?subject=Application for ${encodeURIComponent(selected?.title ?? "Position")}`;
              }}
            >
              <Mail className="h-4 w-4 mr-2" /> Apply for this Position
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </Layout>
  );
}

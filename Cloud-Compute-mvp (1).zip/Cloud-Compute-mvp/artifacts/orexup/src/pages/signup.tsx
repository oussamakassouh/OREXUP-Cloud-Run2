import { useState } from "react";
import { Link, useLocation } from "wouter";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import * as z from "zod";
import { Eye, EyeOff, Lock, Mail, ArrowRight, CheckCircle2, XCircle, Loader2 } from "lucide-react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { Layout } from "@/components/layout";
import { AuthSteps } from "@/components/auth-steps";
import { useUserAuth } from "@/lib/user-auth";
import { useI18n } from "@/lib/i18n";

const DISPOSABLE_DOMAINS = [
  "mailinator.com", "tempmail.com", "guerrillamail.com",
  "10minutemail.com", "yopmail.com", "throwawaymail.com",
];

const PW_TESTS = [
  (p: string) => p.length >= 8,
  (p: string) => /[A-Z]/.test(p),
  (p: string) => /[a-z]/.test(p),
  (p: string) => /[0-9]/.test(p),
];

const signUpSchema = z.object({
  name: z.string().min(1, { message: "Name is required." }).max(64),
  email: z
    .string()
    .email({ message: "Invalid email address." })
    .refine((e) => !DISPOSABLE_DOMAINS.includes(e.split("@")[1]?.toLowerCase() ?? ""), {
      message: "Disposable email addresses are not allowed.",
    }),
  password: z
    .string()
    .min(8, { message: "Password must be at least 8 characters." })
    .regex(/[A-Z]/, { message: "Must include an uppercase letter." })
    .regex(/[a-z]/, { message: "Must include a lowercase letter." })
    .regex(/[0-9]/, { message: "Must include a number." }),
});

export default function SignUp() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const { signup } = useUserAuth();
  const { t } = useI18n();
  const [showPassword, setShowPassword] = useState(false);
  const [passwordVal, setPasswordVal] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  const form = useForm<z.infer<typeof signUpSchema>>({
    resolver: zodResolver(signUpSchema),
    defaultValues: { name: "", email: "", password: "" },
  });

  const passedCount = PW_TESTS.filter((fn) => fn(passwordVal)).length;
  const strengthPct = (passedCount / PW_TESTS.length) * 100;
  const strengthColor =
    passedCount <= 1 ? "bg-red-500" :
    passedCount === 2 ? "bg-amber-500" :
    passedCount === 3 ? "bg-yellow-400" :
    "bg-green-500";

  async function onSubmit(values: z.infer<typeof signUpSchema>) {
    setIsSubmitting(true);
    const result = await signup(values.email, values.password, values.name);
    setIsSubmitting(false);

    if (!result.ok) {
      toast({ title: t.signUp.toastFailTitle, description: result.error, variant: "destructive" });
      return;
    }

    toast({ title: t.signUp.toastSuccessTitle, description: t.signUp.toastSuccessDesc });
    setLocation("/verify-email");
  }

  return (
    <Layout>
      <div className="min-h-[calc(100vh-16rem)] flex items-center justify-center p-4 relative">
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#80808012_1px,transparent_1px),linear-gradient(to_bottom,#80808012_1px,transparent_1px)] bg-[size:24px_24px] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_0%,#000_70%,transparent_100%)] pointer-events-none" />
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
          className="w-full max-w-md relative z-10"
        >
          <AuthSteps current={1} />

          <Card className="border-white/10 bg-card/80 backdrop-blur-xl shadow-2xl">
            <CardHeader className="space-y-1">
              <CardTitle className="text-2xl font-bold font-heading">{t.signUp.title}</CardTitle>
              <CardDescription>{t.signUp.desc}</CardDescription>
            </CardHeader>
            <CardContent>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-5">

                  <FormField control={form.control} name="name" render={({ field }) => (
                    <FormItem>
                      <FormLabel>{t.signUp.nameLabel}</FormLabel>
                      <FormControl>
                        <Input placeholder="Jane Smith" {...field} data-testid="input-signup-name" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )} />

                  <FormField control={form.control} name="email" render={({ field }) => (
                    <FormItem>
                      <FormLabel>{t.signUp.emailLabel}</FormLabel>
                      <FormControl>
                        <div className="relative">
                          <Mail className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                          <Input placeholder="Email" className="pl-9" {...field} data-testid="input-signup-email" />
                        </div>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )} />

                  <FormField control={form.control} name="password" render={({ field }) => (
                    <FormItem>
                      <FormLabel>{t.signUp.passwordLabel}</FormLabel>
                      <FormControl>
                        <div className="relative">
                          <Lock className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                          <Input
                            type={showPassword ? "text" : "password"}
                            placeholder="••••••••"
                            className="pl-9 pr-10"
                            {...field}
                            onChange={(e) => { field.onChange(e); setPasswordVal(e.target.value); }}
                            data-testid="input-signup-password"
                          />
                          <button
                            type="button"
                            aria-label={showPassword ? "Hide password" : "Show password"}
                            onClick={() => setShowPassword(!showPassword)}
                            className="absolute right-3 top-3 text-muted-foreground hover:text-foreground transition-colors"
                            data-testid="button-toggle-password"
                          >
                            {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                          </button>
                        </div>
                      </FormControl>

                      {passwordVal.length > 0 && (
                        <div className="mt-2 space-y-2">
                          <div className="h-1.5 w-full rounded-full bg-white/10 overflow-hidden">
                            <div
                              className={`h-full rounded-full transition-all duration-300 ${strengthColor}`}
                              style={{ width: `${strengthPct}%` }}
                            />
                          </div>
                          <ul className="space-y-1 pt-0.5">
                            {t.signUp.pwRules.map((label, i) => {
                              const ok = PW_TESTS[i](passwordVal);
                              return (
                                <li key={i} className="flex items-center gap-2 text-xs">
                                  {ok
                                    ? <CheckCircle2 className="h-3.5 w-3.5 text-green-500 shrink-0" />
                                    : <XCircle className="h-3.5 w-3.5 text-muted-foreground/40 shrink-0" />}
                                  <span className={ok ? "text-foreground" : "text-muted-foreground"}>{label}</span>
                                </li>
                              );
                            })}
                          </ul>
                        </div>
                      )}
                      <FormMessage />
                    </FormItem>
                  )} />

                  <Button type="submit" className="w-full h-11" disabled={isSubmitting} data-testid="button-submit-signup">
                    {isSubmitting ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null}
                    {isSubmitting ? t.signUp.submittingBtn : t.signUp.submitBtn}
                    {!isSubmitting && <ArrowRight className="ml-2 h-4 w-4" />}
                  </Button>
                </form>
              </Form>
            </CardContent>
            <CardFooter className="flex justify-center border-t border-white/5 pt-6">
              <p className="text-sm text-muted-foreground">
                {t.signUp.hasAccount}{" "}
                <Link href="/signin" className="text-primary hover:underline font-medium" data-testid="link-to-signin">
                  {t.signUp.signInLink}
                </Link>
              </p>
            </CardFooter>
          </Card>
        </motion.div>
      </div>
    </Layout>
  );
}

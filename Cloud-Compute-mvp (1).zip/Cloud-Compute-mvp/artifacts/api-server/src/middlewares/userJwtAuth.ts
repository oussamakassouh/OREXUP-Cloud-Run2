import { jwtVerify } from "jose";
import type { Request, Response, NextFunction } from "express";

const FALLBACK_JWT_SECRET = "orexup-user-jwt-dev-secret-change-in-production";
const rawSecret = process.env.USER_JWT_SECRET ?? FALLBACK_JWT_SECRET;
if (rawSecret === FALLBACK_JWT_SECRET && process.env.NODE_ENV === "production") {
  console.error("[SECURITY] USER_JWT_SECRET is not set — using insecure default in production!");
}
const JWT_SECRET = new TextEncoder().encode(rawSecret);
const COOKIE_NAME = "orexup_user_session";

export interface AuthRequest extends Request {
  userId: number;
  userEmail: string;
}

export async function userAuth(req: Request, res: Response, next: NextFunction): Promise<void> {
  const token = req.cookies?.[COOKIE_NAME] as string | undefined;
  if (!token) {
    res.status(401).json({ error: "Authentication required." });
    return;
  }
  try {
    const { payload } = await jwtVerify(token, JWT_SECRET);
    const userId = Number(payload.sub);
    if (!Number.isFinite(userId) || userId <= 0) {
      res.clearCookie(COOKIE_NAME, { path: "/" });
      res.status(401).json({ error: "Invalid session. Please sign in again." });
      return;
    }
    (req as AuthRequest).userId = userId;
    (req as AuthRequest).userEmail = payload.email as string;
    next();
  } catch {
    res.clearCookie(COOKIE_NAME, { path: "/" });
    res.status(401).json({ error: "Session expired. Please sign in again." });
  }
}

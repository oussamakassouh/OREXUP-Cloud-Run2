import { useState } from "react";
import { useLocation } from "wouter";
import { DashboardLayout } from "@/components/dashboard-layout";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog, DialogContent, DialogDescription, DialogFooter,
  DialogHeader, DialogTitle, DialogTrigger,
} from "@/components/ui/dialog";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Check, Receipt, CreditCard, Pencil, AlertTriangle, Plus } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useAppContext } from "@/lib/app-context";
import type { Plan } from "@/lib/app-context";

const PLAN_CONFIG: Record<Plan, { label: string; monthly: number; annual: number; features: string[] }> = {
  standard: {
    label: "Starter",
    monthly: 9,
    annual: 99,
    features: ["120 hours / month"],
  },
  premium: {
    label: "Premium",
    monthly: 29,
    annual: 299,
    features: ["240 hours / month"],
  },
  custom: {
    label: "Ultimate",
    monthly: 49,
    annual: 499,
    features: ["Unlimited usage time"],
  },
};

export default function BillingPage() {
  const [annual, setAnnual] = useState(false);
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const { currentPlan } = useAppContext();

  const [cardEditOpen, setCardEditOpen] = useState(false);
  const [cancelOpen, setCancelOpen] = useState(false);
  const [savedCard, setSavedCard] = useState<{ number: string; expiry: string } | null>(null);
  const [newCard, setNewCard] = useState({ number: "", expiry: "", cvc: "" });

  const activePlan = PLAN_CONFIG[currentPlan];

  const handleUpgrade = (plan: Plan) => {
    if (plan === currentPlan) return;
    const q = new URLSearchParams({ plan, billing: annual ? "annual" : "monthly" });
    setLocation(`/dashboard/checkout?${q.toString()}`);
  };

  const handleManageSubscription = async () => {
    toast({ title: "Opening billing portal…", description: "Redirecting to Stripe." });
    try {
      const res  = await fetch("/api/billing/portal", {
        method:  "POST",
        headers: { "Content-Type": "application/json" },
        body:    JSON.stringify({}),
      });
      const data = await res.json() as { url?: string; error?: string };
      if (data.url) {
        window.location.href = data.url;
      } else {
        toast({ title: "No active subscription", description: "Select a plan below to get started.", variant: "destructive" });
      }
    } catch {
      toast({ title: "Error", description: "Could not open the billing portal.", variant: "destructive" });
    }
  };

  const handleSaveCard = () => {
    if (newCard.number.length < 4) return;
    setSavedCard({
      number: `•••• •••• •••• ${newCard.number.replace(/\s/g, "").slice(-4)}`,
      expiry: newCard.expiry || "—",
    });
    setNewCard({ number: "", expiry: "", cvc: "" });
    setCardEditOpen(false);
    toast({ title: "Payment method updated", description: "New card saved successfully." });
  };

  const handleCancelSubscription = () => {
    setCancelOpen(false);
    toast({ title: "Subscription cancelled", description: "Your plan will end at the next billing date.", variant: "destructive" });
  };

  return (
    <DashboardLayout title="Billing & Plans">
      <div className="space-y-8">

        {/* Current Plan */}
        <section>
          <Card className="border-primary/20 bg-primary/5">
            <CardContent className="p-6 flex flex-col md:flex-row items-start justify-between gap-6">
              <div>
                <p className="text-sm font-medium text-primary mb-1">CURRENT PLAN</p>
                <h3 className="text-2xl font-bold font-heading flex items-center gap-3">
                  {activePlan.label}
                  <span className="text-lg font-normal text-muted-foreground">— ${activePlan.monthly}/month</span>
                  <Badge variant="outline" className="text-xs bg-primary/10 text-primary border-primary/20">Active</Badge>
                </h3>
                <ul className="mt-4 space-y-2">
                  {activePlan.features.map((f) => (
                    <li key={f} className="flex items-center text-sm">
                      <Check className="mr-2 h-4 w-4 text-primary" /> {f}
                    </li>
                  ))}
                </ul>
              </div>
              <div className="flex flex-col gap-3 min-w-[200px]">
                {currentPlan !== "custom" && (
                  <Button onClick={() => handleUpgrade(currentPlan === "standard" ? "premium" : "custom")} className="w-full" data-testid="billing-upgrade-premium">
                    {currentPlan === "standard" ? "Upgrade to Premium" : "Upgrade to Ultimate"}
                  </Button>
                )}
                <Button
                  variant="outline"
                  className="w-full"
                  onClick={handleManageSubscription}
                  data-testid="billing-manage"
                >
                  Manage Subscription
                </Button>
                <Button
                  variant="ghost"
                  className="w-full text-destructive hover:text-destructive hover:bg-destructive/10 text-sm"
                  onClick={() => setCancelOpen(true)}
                  data-testid="billing-cancel"
                >
                  <AlertTriangle className="h-3.5 w-3.5 mr-1.5" />
                  Cancel Subscription
                </Button>
              </div>
            </CardContent>
          </Card>
        </section>

        {/* Payment Method */}
        <section>
          <Card className="border-white/5 bg-card/50 max-w-xl">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <div>
                <CardTitle className="flex items-center gap-2 text-base">
                  <CreditCard className="h-4 w-4 text-muted-foreground" />
                  Payment Method
                </CardTitle>
                <CardDescription className="mt-1">Card on file for subscription billing.</CardDescription>
              </div>
              <Dialog open={cardEditOpen} onOpenChange={setCardEditOpen}>
                <DialogTrigger asChild>
                  <Button variant="outline" size="sm" data-testid="billing-edit-card">
                    {savedCard ? <><Pencil className="h-3.5 w-3.5 mr-1.5" /> Update Card</> : <><Plus className="h-3.5 w-3.5 mr-1.5" /> Add Card</>}
                  </Button>
                </DialogTrigger>
                <DialogContent className="bg-card border-white/10 sm:max-w-sm">
                  <DialogHeader>
                    <DialogTitle>{savedCard ? "Update Payment Method" : "Add Payment Method"}</DialogTitle>
                    <DialogDescription>Enter your card details below.</DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4 py-2">
                    <div className="space-y-1.5">
                      <Label>Card Number</Label>
                      <Input
                        placeholder="1234 5678 9012 3456"
                        className="bg-black/20 font-mono"
                        maxLength={19}
                        value={newCard.number}
                        onChange={(e) => setNewCard({ ...newCard, number: e.target.value })}
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-1.5">
                        <Label>Expiry</Label>
                        <Input
                          placeholder="MM / YY"
                          className="bg-black/20 font-mono"
                          maxLength={7}
                          value={newCard.expiry}
                          onChange={(e) => setNewCard({ ...newCard, expiry: e.target.value })}
                        />
                      </div>
                      <div className="space-y-1.5">
                        <Label>CVC</Label>
                        <Input
                          placeholder="•••"
                          className="bg-black/20 font-mono"
                          maxLength={4}
                          value={newCard.cvc}
                          onChange={(e) => setNewCard({ ...newCard, cvc: e.target.value })}
                        />
                      </div>
                    </div>
                  </div>
                  <DialogFooter>
                    <Button variant="ghost" onClick={() => setCardEditOpen(false)}>Cancel</Button>
                    <Button onClick={handleSaveCard} disabled={!newCard.number}>Save Card</Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </CardHeader>
            <CardContent>
              {savedCard ? (
                <div className="flex items-center gap-4 p-4 bg-black/20 border border-white/10 rounded-xl">
                  <div className="p-2 bg-primary/10 rounded-lg">
                    <CreditCard className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <p className="font-mono font-medium">{savedCard.number}</p>
                    <p className="text-xs text-muted-foreground mt-0.5">Expires {savedCard.expiry}</p>
                  </div>
                  <Badge className="ml-auto bg-green-500/10 text-green-500 border-0">Active</Badge>
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center py-6 text-center gap-2 border border-dashed border-white/10 rounded-xl">
                  <CreditCard className="h-6 w-6 text-muted-foreground/40" />
                  <p className="text-sm text-muted-foreground">No card on file</p>
                  <p className="text-xs text-muted-foreground/60">Add a card to manage your subscription.</p>
                </div>
              )}
            </CardContent>
          </Card>
        </section>

        {/* Available Plans */}
        <section className="space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="text-xl font-heading font-semibold">Available Plans</h3>
            <div className="flex items-center gap-3">
              <span className={`text-sm ${!annual ? "font-medium text-foreground" : "text-muted-foreground"}`}>Monthly</span>
              <Switch checked={annual} onCheckedChange={setAnnual} data-testid="billing-annual-toggle" />
              <span className={`text-sm ${annual ? "font-medium text-foreground" : "text-muted-foreground"}`}>
                Annual <span className="text-primary text-xs ml-1">(Save 20%)</span>
              </span>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {(["standard", "premium", "custom"] as Plan[]).map((planKey) => {
              const plan = PLAN_CONFIG[planKey];
              const isActive = currentPlan === planKey;
              const isPremium = planKey === "premium";
              return (
                <Card
                  key={planKey}
                  className={`flex flex-col relative ${isPremium
                    ? "border-primary bg-primary/5 shadow-[0_0_30px_-10px_rgba(var(--primary),0.2)]"
                    : "border-white/5 bg-card/30"}`}
                >
                  {isPremium && (
                    <div className="absolute top-0 right-0 bg-primary text-primary-foreground text-xs font-bold px-3 py-1 rounded-bl-lg rounded-tr-lg">
                      POPULAR
                    </div>
                  )}
                  <CardHeader>
                    <CardTitle>{plan.label}</CardTitle>
                    <CardDescription>
                      {planKey === "standard" ? "For getting started" : planKey === "premium" ? "For professional developers" : "For power users"}
                    </CardDescription>
                    <div className="mt-4 text-3xl font-bold">
                      ${annual ? plan.annual : plan.monthly}
                      <span className="text-sm font-normal text-muted-foreground">/{annual ? "yr" : "mo"}</span>
                    </div>
                  </CardHeader>
                  <CardContent className="flex-1">
                    <ul className="space-y-3 text-sm">
                      {plan.features.map((f) => (
                        <li key={f} className="flex items-center"><Check className="mr-2 h-4 w-4 text-primary" /> {f}</li>
                      ))}
                    </ul>
                  </CardContent>
                  <CardFooter>
                    {isActive ? (
                      <Button variant="outline" className="w-full" disabled data-testid={`billing-plan-current-${planKey}`}>Current Plan</Button>
                    ) : (
                      <Button
                        className="w-full"
                        variant={isPremium ? "default" : "outline"}
                        onClick={() => handleUpgrade(planKey)}
                        data-testid={`billing-select-${planKey}`}
                      >
                        Select Plan
                      </Button>
                    )}
                  </CardFooter>
                </Card>
              );
            })}
          </div>
        </section>

        {/* Billing History */}
        <section>
          <Card className="border-white/5 bg-card/50">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <div>
                <CardTitle className="text-lg">Billing History</CardTitle>
                <CardDescription>Recent invoices and payments</CardDescription>
              </div>
              <Button variant="ghost" size="sm" data-testid="billing-download-all" disabled>
                <Receipt className="mr-2 h-4 w-4" /> Download All
              </Button>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col items-center justify-center py-10 text-center gap-3 border border-dashed border-white/10 rounded-xl">
                <Receipt className="h-6 w-6 text-muted-foreground/40" />
                <p className="text-sm text-muted-foreground">No billing history yet</p>
                <p className="text-xs text-muted-foreground/60">Your invoices will appear here after your first payment.</p>
              </div>
            </CardContent>
          </Card>
        </section>
      </div>

      {/* Cancel Subscription Confirm */}
      <AlertDialog open={cancelOpen} onOpenChange={setCancelOpen}>
        <AlertDialogContent className="bg-card border-white/10">
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-destructive" />
              Cancel Subscription?
            </AlertDialogTitle>
            <AlertDialogDescription>
              Your <strong>{activePlan.label}</strong> plan will remain active until the end of the current billing period.
              After that, you'll lose access to plan features. This action can be undone by resubscribing.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Keep Subscription</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive hover:bg-destructive/90 text-destructive-foreground"
              onClick={handleCancelSubscription}
            >
              Yes, Cancel
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </DashboardLayout>
  );
}

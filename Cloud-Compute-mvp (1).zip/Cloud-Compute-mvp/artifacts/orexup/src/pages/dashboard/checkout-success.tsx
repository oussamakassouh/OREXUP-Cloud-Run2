import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import { CheckCircle2, Zap, ArrowRight, Receipt, AlertTriangle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Layout } from "@/components/layout";
import { CheckoutSteps } from "@/components/checkout-steps";
import { useAppContext } from "@/lib/app-context";
import { useToast } from "@/hooks/use-toast";
import type { Plan } from "@/lib/app-context";
import { PLAN_CONFIG } from "@/lib/plans";

type SessionData = {
  status: string;
  plan: string | null;
  billing: string | null;
  customerEmail: string | null;
};

export default function CheckoutSuccessPage() {
  const [, setLocation] = useLocation();
  const { setCurrentPlan } = useAppContext();
  const { toast } = useToast();
  const params      = new URLSearchParams(window.location.search);
  const sessionId   = params.get("session_id");
  const planParam   = (params.get("plan") ?? "standard") as Plan;
  const billingParam = params.get("billing") ?? "monthly";

  const [step, setStep]         = useState<3 | 4>(3);
  const [session, setSession]   = useState<SessionData | null>(null);
  const [failed, setFailed]     = useState(false);

  const resolvedPlan    = (session?.plan ?? planParam) as Plan;
  const resolvedBilling = session?.billing ?? billingParam;
  const plan            = PLAN_CONFIG[resolvedPlan] ?? PLAN_CONFIG.standard;
  const price           = resolvedBilling === "annual" ? plan.annual : plan.monthly;
  const period          = resolvedBilling === "annual" ? "year" : "month";

  useEffect(() => {
    async function verify() {
      if (sessionId) {
        try {
          const res  = await fetch(`/api/billing/session/${sessionId}`);
          const data = await res.json() as SessionData & { error?: string };
          if (!res.ok || data.error) throw new Error(data.error ?? "Session error");
          if (data.status !== "paid" && data.status !== "unpaid") {
            setFailed(true);
            return;
          }
          setSession(data);
        } catch {
          setFailed(true);
          return;
        }
      }

      const finalPlan = (session?.plan ?? planParam) as Plan;
      setCurrentPlan(finalPlan);

      const t = setTimeout(() => {
        setStep(4);
        toast({ title: "Subscription activated!", description: `${plan.label} plan is now active on your account.` });
      }, 1400);
      return () => clearTimeout(t);
    }
    verify();
  }, []);

  const invoiceId = `INV-${Date.now().toString().slice(-8)}`;

  if (failed) {
    return (
      <Layout>
        <div className="min-h-[calc(100vh-16rem)] flex flex-col items-center justify-center p-4">
          <Card className="border-red-500/20 bg-card/80 backdrop-blur-xl shadow-2xl max-w-md w-full text-center">
            <CardContent className="pt-10 pb-8 px-8 space-y-4">
              <div className="mx-auto w-16 h-16 rounded-full bg-red-500/10 border border-red-500/20 flex items-center justify-center">
                <AlertTriangle className="h-8 w-8 text-red-400" />
              </div>
              <h2 className="text-xl font-bold font-heading">Payment Verification Failed</h2>
              <p className="text-sm text-muted-foreground">
                We couldn't confirm your payment. If you were charged, please contact support with your session ID.
              </p>
              {sessionId && (
                <p className="text-xs font-mono bg-black/30 rounded-lg px-3 py-2 text-muted-foreground break-all">
                  {sessionId}
                </p>
              )}
              <Button className="w-full" onClick={() => setLocation("/dashboard/billing")}>
                Back to Billing
              </Button>
            </CardContent>
          </Card>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="min-h-[calc(100vh-16rem)] flex flex-col items-center justify-center p-4 relative">
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#80808012_1px,transparent_1px),linear-gradient(to_bottom,#80808012_1px,transparent_1px)] bg-[size:24px_24px] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_0%,#000_70%,transparent_100%)] pointer-events-none" />

        <div className="w-full max-w-md relative z-10">
          <CheckoutSteps current={step} />

          <motion.div
            key={step}
            initial={{ opacity: 0, scale: 0.96 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.4 }}
          >
            <Card className="border-white/10 bg-card/80 backdrop-blur-xl shadow-2xl text-center overflow-hidden">
              <div className="h-1 w-full bg-gradient-to-r from-primary/60 via-primary to-primary/60" />

              <CardContent className="pt-10 pb-8 px-8 space-y-6">
                <div className="relative mx-auto w-20 h-20">
                  <div className="absolute inset-0 rounded-full bg-green-500/10 animate-ping opacity-30" />
                  <div className="relative w-20 h-20 rounded-full bg-green-500/15 border border-green-500/30 flex items-center justify-center">
                    <AnimatePresence mode="wait">
                      {step === 3 ? (
                        <motion.div
                          key="check"
                          initial={{ scale: 0, rotate: -30 }}
                          animate={{ scale: 1, rotate: 0 }}
                          exit={{ scale: 0 }}
                          transition={{ type: "spring", stiffness: 300, damping: 20 }}
                        >
                          <CheckCircle2 className="h-10 w-10 text-green-400" />
                        </motion.div>
                      ) : (
                        <motion.div
                          key="zap"
                          initial={{ scale: 0, rotate: -30 }}
                          animate={{ scale: 1, rotate: 0 }}
                          exit={{ scale: 0 }}
                          transition={{ type: "spring", stiffness: 300, damping: 20 }}
                        >
                          <Zap className="h-10 w-10 text-primary fill-primary" />
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                </div>

                <div className="space-y-2">
                  <AnimatePresence mode="wait">
                    {step === 3 ? (
                      <motion.div key="s3" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }}>
                        <h2 className="text-2xl font-bold font-heading">Payment Successful</h2>
                        <p className="text-sm text-muted-foreground mt-1">Activating your subscription…</p>
                      </motion.div>
                    ) : (
                      <motion.div key="s4" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }}>
                        <h2 className="text-2xl font-bold font-heading">Subscription Active!</h2>
                        <p className="text-sm text-muted-foreground mt-1">You're now on the <strong className="text-foreground">{plan.label}</strong> plan.</p>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>

                <div className="bg-white/5 border border-white/8 rounded-xl p-4 space-y-3 text-left">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-semibold">{plan.label} Plan</span>
                    <Badge variant="outline" className="text-green-400 border-green-500/30 bg-green-500/10 text-[10px]">
                      Active
                    </Badge>
                  </div>
                  <div className="text-xs text-muted-foreground space-y-1.5">
                    {plan.features.map((f) => (
                      <div key={f} className="flex items-center gap-2">
                        <CheckCircle2 className="h-3.5 w-3.5 text-primary shrink-0" />
                        {f}
                      </div>
                    ))}
                  </div>
                  <div className="pt-2 border-t border-white/5 flex items-center justify-between text-xs">
                    <span className="text-muted-foreground">Billed {resolvedBilling === "annual" ? "annually" : "monthly"}</span>
                    <span className="font-semibold">${price} / {period}</span>
                  </div>
                  {session?.customerEmail && (
                    <div className="pt-1 border-t border-white/5 text-xs text-muted-foreground">
                      Receipt sent to <span className="text-foreground">{session.customerEmail}</span>
                    </div>
                  )}
                </div>

                <div className="flex items-center gap-2 justify-center text-xs text-muted-foreground">
                  <Receipt className="h-3.5 w-3.5" />
                  <span>Invoice <span className="font-mono">{invoiceId}</span> sent to your email</span>
                </div>

                <div className="space-y-2 pt-2">
                  <Button className="w-full h-11" onClick={() => setLocation("/dashboard")} data-testid="button-go-dashboard">
                    Go to Dashboard <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="w-full text-muted-foreground hover:text-foreground"
                    onClick={() => setLocation("/dashboard/billing")}
                    data-testid="button-view-billing"
                  >
                    View Billing Details
                  </Button>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </div>
    </Layout>
  );
}

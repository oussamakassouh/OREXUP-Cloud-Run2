import { PublicPage } from "./public-page";
export default function CookiesPage() {
  return <PublicPage slug="cookies" title="Cookies Policy" />;
}

import { createContext, useContext, useState } from "react";

export type Plan = "standard" | "premium" | "custom";
export type Profile = "balanced" | "cpu" | "gpu" | "memory";

interface AppState {
  cloudConnected: boolean;
  setCloudConnected: (v: boolean) => void;
  sessionRunning: boolean;
  setSessionRunning: (v: boolean) => void;
  extensionInstalled: boolean;
  setExtensionInstalled: (v: boolean) => void;
  currentPlan: Plan;
  setCurrentPlan: (v: Plan) => void;
  currentProfile: Profile;
  setCurrentProfile: (v: Profile) => void;
  cloudToken: string | null;
  setCloudToken: (v: string | null) => void;
  activeSessionId: number | null;
  setActiveSessionId: (v: number | null) => void;
  cloudRegion: string;
  setCloudRegion: (v: string) => void;
}

const AppContext = createContext<AppState | null>(null);

function load<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    if (raw === null) return fallback;
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

function save(key: string, value: unknown) {
  try { localStorage.setItem(key, JSON.stringify(value)); } catch {}
}

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [cloudConnected, setCloudConnectedState] = useState<boolean>(() => load("orexup_cloud_connected", false));
  const [sessionRunning, setSessionRunningState] = useState<boolean>(() => load("orexup_session_running", false));
  const [extensionInstalled, setExtensionInstalledState] = useState<boolean>(() => load("orexup_extension_installed", false));
  const [currentPlan, setCurrentPlanState] = useState<Plan>(() => load("orexup_current_plan", "standard"));
  const [currentProfile, setCurrentProfileState] = useState<Profile>(() => load("orexup_current_profile", "balanced"));
  const [cloudToken, setCloudTokenState] = useState<string | null>(null);
  const [activeSessionId, setActiveSessionIdState] = useState<number | null>(() => load("orexup_active_session_id", null));
  const [cloudRegion, setCloudRegionState] = useState<string>(() => load("orexup_cloud_region", "us-east-1"));

  const setCloudConnected = (v: boolean) => {
    setCloudConnectedState(v); save("orexup_cloud_connected", v);
    if (!v) { setSessionRunningState(false); save("orexup_session_running", false); }
  };
  const setSessionRunning = (v: boolean) => { setSessionRunningState(v); save("orexup_session_running", v); };
  const setExtensionInstalled = (v: boolean) => { setExtensionInstalledState(v); save("orexup_extension_installed", v); };
  const setCurrentPlan = (v: Plan) => { setCurrentPlanState(v); save("orexup_current_plan", v); };
  const setCurrentProfile = (v: Profile) => { setCurrentProfileState(v); save("orexup_current_profile", v); };
  const setCloudToken = (v: string | null) => { setCloudTokenState(v); };
  const setActiveSessionId = (v: number | null) => { setActiveSessionIdState(v); save("orexup_active_session_id", v); };
  const setCloudRegion = (v: string) => { setCloudRegionState(v); save("orexup_cloud_region", v); };

  return (
    <AppContext.Provider value={{
      cloudConnected, setCloudConnected,
      sessionRunning, setSessionRunning,
      extensionInstalled, setExtensionInstalled,
      currentPlan, setCurrentPlan,
      currentProfile, setCurrentProfile,
      cloudToken, setCloudToken,
      activeSessionId, setActiveSessionId,
      cloudRegion, setCloudRegion,
    }}>
      {children}
    </AppContext.Provider>
  );
}

export function useAppContext(): AppState {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error("useAppContext must be used within AppProvider");
  return ctx;
}

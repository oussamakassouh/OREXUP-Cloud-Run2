import { Router, type IRouter, type Request, type Response } from "express";
import { eq, desc } from "drizzle-orm";
import { db, supportTicketsTable, ticketMessagesTable } from "@workspace/db";
import { userAuth, type AuthRequest } from "../middlewares/userJwtAuth";
import { logger } from "../lib/logger";

const router: IRouter = Router();

const VALID_PRIORITIES = ["Low", "Normal", "High", "Critical"];

// POST /support/ticket — create a ticket (public; email required in body)
router.post("/support/ticket", async (req: Request, res: Response): Promise<void> => {
  const { subject, message, priority, email } = req.body as {
    subject?: string;
    message?: string;
    priority?: string;
    email?: string;
  };

  if (!subject || subject.trim().length === 0) {
    res.status(400).json({ error: "Subject is required." });
    return;
  }
  if (!email || !email.includes("@")) {
    res.status(400).json({ error: "Valid email is required." });
    return;
  }

  const safePriority = VALID_PRIORITIES.includes(priority ?? "") ? priority! : "Normal";

  try {
    const [ticket] = await db
      .insert(supportTicketsTable)
      .values({
        subject: subject.trim().slice(0, 200),
        userEmail: email.toLowerCase().trim(),
        priority: safePriority,
        status: "Open",
      })
      .returning();

    if (message && message.trim().length > 0) {
      await db.insert(ticketMessagesTable).values({
        ticketId: ticket.id,
        userEmail: ticket.userEmail,
        message: message.trim().slice(0, 5000),
        isStaff: false,
      });
    }

    logger.info({ ticketId: ticket.id, email: ticket.userEmail }, "Support ticket created");
    res.status(201).json({
      ticket: {
        id: ticket.id,
        subject: ticket.subject,
        status: ticket.status,
        priority: ticket.priority,
        createdAt: ticket.createdAt,
      },
    });
  } catch (err) {
    logger.error({ err }, "Create ticket error");
    res.status(500).json({ error: "Failed to create support ticket." });
  }
});

// GET /support/tickets — list tickets for authenticated user
router.get("/support/tickets", userAuth, async (req: Request, res: Response): Promise<void> => {
  const { userEmail } = req as AuthRequest;
  const statusFilter = req.query.status as string | undefined;

  try {
    const tickets = await db
      .select()
      .from(supportTicketsTable)
      .where(eq(supportTicketsTable.userEmail, userEmail))
      .orderBy(desc(supportTicketsTable.createdAt));

    const filtered = statusFilter
      ? tickets.filter((t) => t.status === statusFilter)
      : tickets;

    res.json({ tickets: filtered });
  } catch (err) {
    logger.error({ err }, "List tickets error");
    res.status(500).json({ error: "Failed to fetch tickets." });
  }
});

// POST /support/reply — add a reply to an existing ticket
router.post("/support/reply", userAuth, async (req: Request, res: Response): Promise<void> => {
  const { userEmail } = req as AuthRequest;
  const { ticketId, message } = req.body as { ticketId?: number; message?: string };

  if (!ticketId || !Number.isInteger(Number(ticketId))) {
    res.status(400).json({ error: "Valid ticketId is required." });
    return;
  }
  if (!message || message.trim().length === 0) {
    res.status(400).json({ error: "message is required." });
    return;
  }

  try {
    const [ticket] = await db
      .select()
      .from(supportTicketsTable)
      .where(eq(supportTicketsTable.id, Number(ticketId)))
      .limit(1);

    if (!ticket) {
      res.status(404).json({ error: "Ticket not found." });
      return;
    }
    if (ticket.userEmail !== userEmail) {
      res.status(403).json({ error: "Access denied." });
      return;
    }
    if (ticket.status === "Closed") {
      res.status(409).json({ error: "Cannot reply to a closed ticket." });
      return;
    }

    const [reply] = await db
      .insert(ticketMessagesTable)
      .values({
        ticketId: ticket.id,
        userEmail,
        message: message.trim().slice(0, 5000),
        isStaff: false,
      })
      .returning();

    if (ticket.status === "Open") {
      await db
        .update(supportTicketsTable)
        .set({ status: "In Progress" })
        .where(eq(supportTicketsTable.id, ticket.id));
    }

    logger.info({ ticketId: ticket.id, userEmail }, "Support reply added");
    res.status(201).json({ reply: { id: reply.id, message: reply.message, isStaff: reply.isStaff, createdAt: reply.createdAt } });
  } catch (err) {
    logger.error({ err }, "Reply error");
    res.status(500).json({ error: "Failed to add reply." });
  }
});

export default router;

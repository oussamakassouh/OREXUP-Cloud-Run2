import type { Request, Response, NextFunction } from "express";
import { logger } from "../lib/logger";

export interface AppError extends Error {
  statusCode?: number;
  code?: string;
}

export function errorHandler(
  err: AppError,
  req: Request,
  res: Response,
  _next: NextFunction
): void {
  const statusCode = err.statusCode ?? 500;
  const isProd = process.env.NODE_ENV === "production";

  logger.error(
    { err, method: req.method, url: req.url, statusCode },
    err.message
  );

  res.status(statusCode).json({
    error: {
      message: statusCode < 500 ? err.message : "Internal server error",
      code: err.code ?? "INTERNAL_ERROR",
      ...(isProd ? {} : { stack: err.stack }),
    },
  });
}

export function notFoundHandler(req: Request, res: Response): void {
  res.status(404).json({
    error: {
      message: `Route ${req.method} ${req.path} not found`,
      code: "NOT_FOUND",
    },
  });
}

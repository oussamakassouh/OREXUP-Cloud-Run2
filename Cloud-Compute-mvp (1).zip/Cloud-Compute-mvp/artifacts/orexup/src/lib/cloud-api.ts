const BASE = "/api";

function getToken(): string | null {
  try { return localStorage.getItem("orexup_cloud_token"); } catch { return null; }
}

function headers(extra: Record<string, string> = {}): HeadersInit {
  const token = getToken();
  return {
    "Content-Type": "application/json",
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
    ...extra,
  };
}

async function req<T>(method: string, path: string, body?: unknown): Promise<T> {
  const res = await fetch(`${BASE}${path}`, {
    method,
    headers: headers(),
    ...(body !== undefined ? { body: JSON.stringify(body) } : {}),
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({ error: res.statusText }));
    throw new Error((err as { error?: string }).error ?? `HTTP ${res.status}`);
  }
  return res.json() as Promise<T>;
}

export interface ConnectResponse {
  token: string;
  connectionId: number;
  region: string;
  profile: string;
  connectedAt: string;
}

export interface SessionInfo {
  sessionId: number;
  profile: string;
  status: "active" | "stopped";
  startedAt: string;
  endedAt: string | null;
  durationSeconds: number;
}

export interface SessionStatus {
  connected: boolean;
  status: "active" | "stopped" | "idle";
  connectionId: number | null;
  region: string | null;
  profile: string | null;
  session: SessionInfo | null;
}

export interface SessionsByProfileItem {
  profile: string;
  count: number;
}

export interface MetricsResponse {
  totalSessions: number;
  activeSessions: number;
  totalDurationSeconds: number;
  avgDurationSeconds: number;
  sessionsByProfile: SessionsByProfileItem[];
  recentSessions: SessionInfo[];
}

export const cloudApi = {
  connect: (email: string, profile: string) =>
    req<ConnectResponse>("POST", "/connect", { email, profile }),

  sessionStart: (profile: string) =>
    req<SessionInfo>("POST", "/session/start", { profile }),

  sessionStop: () =>
    req<SessionInfo>("POST", "/session/stop"),

  sessionStatus: () =>
    req<SessionStatus>("GET", "/session/status"),

  metrics: () =>
    req<MetricsResponse>("GET", "/metrics"),

  saveToken: (token: string) => {
    try { localStorage.setItem("orexup_cloud_token", token); } catch {}
  },

  clearToken: () => {
    try { localStorage.removeItem("orexup_cloud_token"); } catch {}
  },

  getToken,
};

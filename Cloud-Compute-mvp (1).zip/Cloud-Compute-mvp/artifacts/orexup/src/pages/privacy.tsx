import { PublicPage } from "./public-page";
export default function PrivacyPage() {
  return <PublicPage slug="privacy" title="Privacy Policy" />;
}

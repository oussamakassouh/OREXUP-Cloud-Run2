import { Router, type IRouter } from "express";
import { desc, eq } from "drizzle-orm";
import { db, partnersTable } from "@workspace/db";
import {
  GetAdminPartnersResponse,
  InvitePartnerBody,
  InvitePartnerResponse,
  UpdatePartnerBody,
  UpdatePartnerResponse,
  RemovePartnerResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

function serialize(p: typeof partnersTable.$inferSelect) {
  return {
    id: p.id,
    companyName: p.companyName,
    contactName: p.contactName,
    businessEmail: p.businessEmail,
    role: p.role,
    status: p.status,
    permissions: p.permissions ?? [],
    notes: p.notes,
    createdAt: p.createdAt,
  };
}

// List partners
router.get("/admin/partners", async (_req, res): Promise<void> => {
  const rows = await db
    .select()
    .from(partnersTable)
    .orderBy(desc(partnersTable.createdAt));
  res.json(GetAdminPartnersResponse.parse(rows.map(serialize)));
});

// Invite (create) a partner
router.post("/admin/partners", async (req, res): Promise<void> => {
  const parsed = InvitePartnerBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid partner data", details: parsed.error.issues });
    return;
  }
  const data = parsed.data;
  const [created] = await db
    .insert(partnersTable)
    .values({
      companyName: data.companyName,
      contactName: data.contactName,
      businessEmail: data.businessEmail,
      role: data.role,
      status: "pending",
      permissions: data.permissions ?? [],
      notes: data.notes ?? null,
    })
    .returning();
  res.status(201).json(InvitePartnerResponse.parse(serialize(created)));
});

// Update a partner (edit fields, approve, disable)
router.patch("/admin/partners/:id", async (req, res): Promise<void> => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id)) {
    res.status(400).json({ error: "Invalid partner id" });
    return;
  }
  const parsed = UpdatePartnerBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid partner data", details: parsed.error.issues });
    return;
  }
  const data = parsed.data;
  const update: Partial<typeof partnersTable.$inferInsert> = {};
  if (data.companyName !== undefined) update.companyName = data.companyName;
  if (data.contactName !== undefined) update.contactName = data.contactName;
  if (data.businessEmail !== undefined) update.businessEmail = data.businessEmail;
  if (data.role !== undefined) update.role = data.role;
  if (data.status !== undefined) update.status = data.status;
  if (data.permissions !== undefined) update.permissions = data.permissions;
  if (data.notes !== undefined) update.notes = data.notes;

  const [updated] = await db
    .update(partnersTable)
    .set(update)
    .where(eq(partnersTable.id, id))
    .returning();
  if (!updated) {
    res.status(404).json({ error: "Partner not found" });
    return;
  }
  res.json(UpdatePartnerResponse.parse(serialize(updated)));
});

// Remove a partner
router.delete("/admin/partners/:id", async (req, res): Promise<void> => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id)) {
    res.status(400).json({ error: "Invalid partner id" });
    return;
  }
  const deleted = await db
    .delete(partnersTable)
    .where(eq(partnersTable.id, id))
    .returning();
  res.json(RemovePartnerResponse.parse({ success: deleted.length > 0 }));
});

export default router;

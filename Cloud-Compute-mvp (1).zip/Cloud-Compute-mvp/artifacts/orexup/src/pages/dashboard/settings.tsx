import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { DashboardLayout } from "@/components/dashboard-layout";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Key, ShieldAlert, MonitorSmartphone, X, CheckCircle2, XCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useI18n } from "@/lib/i18n";

const PW_TESTS = [
  (p: string) => p.length >= 12,
  (p: string) => /[A-Z]/.test(p),
  (p: string) => /[a-z]/.test(p),
  (p: string) => /[0-9]/.test(p),
  (p: string) => /[^A-Za-z0-9]/.test(p),
];

const passwordSchema = z.object({
  currentPassword: z.string().min(1, "Current password is required"),
  newPassword: z
    .string()
    .min(12, "Password must be at least 12 characters")
    .regex(/[A-Z]/, "Must include an uppercase letter")
    .regex(/[a-z]/, "Must include a lowercase letter")
    .regex(/[0-9]/, "Must include a number")
    .regex(/[^A-Za-z0-9]/, "Must include a special character"),
  confirmPassword: z.string(),
}).refine((d) => d.newPassword === d.confirmPassword, {
  message: "Passwords don't match",
  path: ["confirmPassword"],
});

export default function SettingsPage() {
  const { toast } = useToast();
  const { t } = useI18n();
  const [twoFactor, setTwoFactor] = useState(false);
  const [newPasswordVal, setNewPasswordVal] = useState("");
  const [devices, setDevices] = useState([
    { id: 1, name: "Chrome on Windows",  active: "Last active now" },
    { id: 2, name: "Firefox on macOS",   active: "Last active 2d ago" },
    { id: 3, name: "Chrome on iPhone",   active: "Last active 5d ago" },
  ]);

  const form = useForm<z.infer<typeof passwordSchema>>({
    resolver: zodResolver(passwordSchema),
    defaultValues: { currentPassword: "", newPassword: "", confirmPassword: "" },
  });

  const onPasswordSubmit = () => {
    toast({ title: t.settings.toastPwTitle, description: t.settings.toastPwDesc });
    form.reset();
    setNewPasswordVal("");
  };

  const handle2FAToggle = (checked: boolean) => {
    setTwoFactor(checked);
    toast({
      title: t.settings.toastSecTitle,
      description: checked ? t.settings.toastSecEnabled : t.settings.toastSecDisabled,
    });
  };

  const revokeDevice = (id: number) => {
    setDevices(devices.filter((d) => d.id !== id));
    toast({ title: t.settings.toastRevokeTitle, description: t.settings.toastRevokeDesc });
  };

  const passedRules = PW_TESTS.filter((fn) => fn(newPasswordVal)).length;
  const strengthPct = (passedRules / PW_TESTS.length) * 100;
  const strengthColor =
    passedRules <= 1 ? "bg-red-500" :
    passedRules <= 3 ? "bg-amber-500" :
    passedRules === 4 ? "bg-yellow-400" :
    "bg-green-500";

  return (
    <DashboardLayout title={t.settings.pageTitle}>
      <div className="max-w-3xl space-y-8">

        {/* Account Security / 2FA */}
        <Card className="border-white/5 bg-card/50">
          <CardHeader>
            <div className="flex items-center gap-2">
              <ShieldAlert className="h-5 w-5 text-primary" />
              <CardTitle>{t.settings.securityTitle}</CardTitle>
            </div>
            <CardDescription>{t.settings.securityDesc}</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between p-4 border border-white/5 rounded-lg bg-white/5">
              <div>
                <h4 className="font-medium">{t.settings.twoFaLabel}</h4>
                <p className="text-sm text-muted-foreground">{t.settings.twoFaDesc}</p>
              </div>
              <div className="flex items-center gap-3">
                <span className="text-sm font-medium">{twoFactor ? t.settings.enabled : t.settings.disabled}</span>
                <Switch checked={twoFactor} onCheckedChange={handle2FAToggle} />
              </div>
            </div>

            <div className="flex items-center justify-between p-4 border border-white/5 rounded-lg bg-white/5">
              <div>
                <h4 className="font-medium flex items-center gap-2">
                  <MonitorSmartphone className="h-4 w-4" /> {t.settings.sessionsLabel}
                </h4>
                <p className="text-sm text-muted-foreground">{t.settings.sessionsDesc}</p>
              </div>
              <Dialog>
                <DialogTrigger asChild>
                  <Button variant="outline" size="sm">{t.settings.viewDevicesBtn}</Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-[425px] bg-card border-white/10">
                  <DialogHeader>
                    <DialogTitle>{t.settings.devicesTitle}</DialogTitle>
                    <DialogDescription>{t.settings.devicesDesc}</DialogDescription>
                  </DialogHeader>
                  <div className="space-y-3 mt-4">
                    {devices.length === 0 ? (
                      <p className="text-sm text-muted-foreground text-center py-4">{t.settings.noDevices}</p>
                    ) : devices.map((device) => (
                      <div key={device.id} className="flex items-center justify-between p-3 rounded-lg border border-white/5 bg-white/5">
                        <div>
                          <p className="font-medium text-sm">{device.name}</p>
                          <p className="text-xs text-muted-foreground">{device.active}</p>
                        </div>
                        <Button variant="ghost" size="icon" className="text-destructive hover:bg-destructive/10" onClick={() => revokeDevice(device.id)}>
                          <X className="h-4 w-4" />
                        </Button>
                      </div>
                    ))}
                  </div>
                </DialogContent>
              </Dialog>
            </div>
          </CardContent>
        </Card>

        {/* Change Password */}
        <Card className="border-white/5 bg-card/50">
          <CardHeader>
            <div className="flex items-center gap-2">
              <Key className="h-5 w-5 text-muted-foreground" />
              <CardTitle>{t.settings.passwordTitle}</CardTitle>
            </div>
            <CardDescription>{t.settings.passwordDesc}</CardDescription>
          </CardHeader>
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onPasswordSubmit)} className="space-y-4 max-w-md">
                <FormField control={form.control} name="currentPassword" render={({ field }) => (
                  <FormItem>
                    <FormLabel>{t.settings.currentPw}</FormLabel>
                    <FormControl><Input type="password" className="bg-white/5" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />

                <FormField control={form.control} name="newPassword" render={({ field }) => (
                  <FormItem>
                    <FormLabel>{t.settings.newPw}</FormLabel>
                    <FormControl>
                      <Input
                        type="password"
                        className="bg-white/5"
                        {...field}
                        onChange={(e) => { field.onChange(e); setNewPasswordVal(e.target.value); }}
                      />
                    </FormControl>
                    {newPasswordVal.length > 0 && (
                      <div className="mt-2 space-y-2">
                        <div className="h-1.5 w-full rounded-full bg-white/10 overflow-hidden">
                          <div
                            className={`h-full rounded-full transition-all duration-300 ${strengthColor}`}
                            style={{ width: `${strengthPct}%` }}
                          />
                        </div>
                        <ul className="space-y-1">
                          {t.settings.pwRules.map((label, i) => {
                            const ok = PW_TESTS[i](newPasswordVal);
                            return (
                              <li key={i} className="flex items-center gap-2 text-xs">
                                {ok
                                  ? <CheckCircle2 className="h-3.5 w-3.5 text-green-500 shrink-0" />
                                  : <XCircle className="h-3.5 w-3.5 text-muted-foreground/40 shrink-0" />}
                                <span className={ok ? "text-foreground" : "text-muted-foreground"}>{label}</span>
                              </li>
                            );
                          })}
                        </ul>
                      </div>
                    )}
                    <FormMessage />
                  </FormItem>
                )} />

                <FormField control={form.control} name="confirmPassword" render={({ field }) => (
                  <FormItem>
                    <FormLabel>{t.settings.confirmPw}</FormLabel>
                    <FormControl><Input type="password" className="bg-white/5" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />

                <Button type="submit" className="mt-2">{t.settings.updatePwBtn}</Button>
              </form>
            </Form>
          </CardContent>
        </Card>

      </div>
    </DashboardLayout>
  );
}

import { PublicPage } from "./public-page";
export default function AboutUsPage() {
  return <PublicPage slug="about-us" title="About Us" />;
}

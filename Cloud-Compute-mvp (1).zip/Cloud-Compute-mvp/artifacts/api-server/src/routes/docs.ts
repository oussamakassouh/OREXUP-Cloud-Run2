import { Router, type IRouter, type Request, type Response } from "express";

const router: IRouter = Router();

const openApiSpec = {
  openapi: "3.0.3",
  info: {
    title: "OREXUP REST API",
    version: "1.0.0",
    description: "Production-ready REST API for the OREXUP browser cloud performance platform.",
    contact: { name: "OREXUP Support", email: "support@orexup.com" },
    license: { name: "Proprietary" },
  },
  servers: [{ url: "/api", description: "API Server" }],
  tags: [
    { name: "Auth",       description: "Authentication and session management" },
    { name: "User",       description: "User profile, subscription, and usage" },
    { name: "Payment",    description: "Payments, checkout, and billing" },
    { name: "Extension",  description: "Browser extension connections" },
    { name: "Cloud",      description: "Cloud connections and sessions" },
    { name: "Analytics",  description: "Usage and performance analytics" },
    { name: "Support",    description: "Support tickets and replies" },
    { name: "Notification", description: "Email and security notifications (admin)" },
    { name: "Security",   description: "Session management and 2FA" },
    { name: "Admin",      description: "Admin dashboard endpoints" },
  ],
  components: {
    securitySchemes: {
      cookieAuth:  { type: "apiKey", in: "cookie",  name: "orexup_user_session", description: "HTTP-only session cookie issued after sign-in" },
      bearerToken: { type: "http",   scheme: "bearer", description: "Token issued by POST /api/cloud/connect or POST /api/extension/connect" },
      adminCookie: { type: "apiKey", in: "cookie",  name: "orexup_admin_session", description: "Admin session cookie" },
    },
    schemas: {
      Error: { type: "object", properties: { error: { type: "string" } } },
      Profile: { type: "object", properties: { id: { type: "integer" }, email: { type: "string" }, name: { type: "string" }, emailVerified: { type: "boolean" }, totpEnabled: { type: "boolean" }, createdAt: { type: "string", format: "date-time" }, lastLoginAt: { type: "string", format: "date-time" } } },
      Ticket: { type: "object", properties: { id: { type: "integer" }, subject: { type: "string" }, status: { type: "string", enum: ["Open","In Progress","Closed"] }, priority: { type: "string", enum: ["Low","Normal","High","Critical"] }, createdAt: { type: "string", format: "date-time" } } },
    },
  },
  paths: {
    "/auth/signup":           { post: { summary: "Sign up a new user", tags: ["Auth"], requestBody: { required: true, content: { "application/json": { schema: { type: "object", required: ["email","password"], properties: { email: { type: "string", format: "email" }, password: { type: "string", minLength: 8 }, name: { type: "string" } } } } } }, responses: { "201": { description: "Account created. Verification email sent." }, "409": { description: "Email already exists." }, "400": { description: "Validation error." } } } },
    "/auth/verify-email":     { post: { summary: "Verify email address", tags: ["Auth"], requestBody: { required: true, content: { "application/json": { schema: { type: "object", required: ["token"], properties: { token: { type: "string" } } } } } }, responses: { "200": { description: "Email verified." }, "400": { description: "Invalid or expired token." } } }, get: { summary: "Verify email (GET — token in query)", tags: ["Auth"], parameters: [{ in: "query", name: "token", required: true, schema: { type: "string" } }], responses: { "200": { description: "Email verified." } } } },
    "/auth/signin":           { post: { summary: "Sign in", tags: ["Auth"], requestBody: { required: true, content: { "application/json": { schema: { type: "object", required: ["email","password"], properties: { email: { type: "string", format: "email" }, password: { type: "string" } } } } } }, responses: { "200": { description: "Signed in. Session cookie set." }, "401": { description: "Invalid credentials." }, "403": { description: "Email not verified or 2FA required." } } } },
    "/auth/logout":           { post: { summary: "Log out (clear session cookie)", tags: ["Auth"], security: [{ cookieAuth: [] }], responses: { "200": { description: "Logged out." } } } },
    "/auth/forgot-password":  { post: { summary: "Request password reset email", tags: ["Auth"], requestBody: { required: true, content: { "application/json": { schema: { type: "object", required: ["email"], properties: { email: { type: "string", format: "email" } } } } } }, responses: { "200": { description: "Reset email sent (always 200 to prevent enumeration)." } } } },
    "/auth/reset-password":   { post: { summary: "Reset password with token", tags: ["Auth"], requestBody: { required: true, content: { "application/json": { schema: { type: "object", required: ["token","password"], properties: { token: { type: "string" }, password: { type: "string", minLength: 8 } } } } } }, responses: { "200": { description: "Password reset." }, "400": { description: "Invalid or expired token." } } } },
    "/auth/2fa/verify":       { post: { summary: "Verify 2FA TOTP code post-login", tags: ["Auth"], requestBody: { required: true, content: { "application/json": { schema: { type: "object", required: ["code"], properties: { code: { type: "string", minLength: 6, maxLength: 6 } } } } } }, responses: { "200": { description: "Verified. Full session cookie issued." }, "400": { description: "Invalid code." }, "401": { description: "No pending 2FA session." } } } },
    "/user/profile":          { get: { summary: "Get authenticated user profile", tags: ["User"], security: [{ cookieAuth: [] }], responses: { "200": { description: "Profile object.", content: { "application/json": { schema: { type: "object", properties: { profile: { $ref: "#/components/schemas/Profile" } } } } } }, "401": { description: "Not authenticated." } } }, put: { summary: "Update user profile name", tags: ["User"], security: [{ cookieAuth: [] }], requestBody: { required: true, content: { "application/json": { schema: { type: "object", required: ["name"], properties: { name: { type: "string", maxLength: 100 } } } } } }, responses: { "200": { description: "Profile updated." }, "400": { description: "Validation error." } } } },
    "/user/subscription":     { get: { summary: "Get current subscription", tags: ["User"], security: [{ cookieAuth: [] }], responses: { "200": { description: "Subscription details." } } } },
    "/user/usage":            { get: { summary: "Get session usage statistics", tags: ["User"], security: [{ cookieAuth: [] }], responses: { "200": { description: "Usage data." } } } },
    "/payment/create-checkout": { post: { summary: "Create a Stripe checkout session", tags: ["Payment"], security: [{ cookieAuth: [] }], requestBody: { required: true, content: { "application/json": { schema: { type: "object", required: ["plan"], properties: { plan: { type: "string", enum: ["standard","premium","custom"] }, billing: { type: "string", enum: ["monthly","annual"], default: "monthly" } } } } } }, responses: { "200": { description: "Stripe checkout URL and session ID." }, "502": { description: "Stripe API error." } } } },
    "/payment/webhook":       { post: { summary: "Stripe webhook handler", tags: ["Payment"], responses: { "200": { description: "Event received." } } } },
    "/payment/history":       { get: { summary: "List authenticated user's payment history", tags: ["Payment"], security: [{ cookieAuth: [] }], parameters: [{ in: "query", name: "limit", schema: { type: "integer", default: 20, maximum: 100 } }, { in: "query", name: "offset", schema: { type: "integer", default: 0 } }], responses: { "200": { description: "Payment list with pagination." } } } },
    "/payment/cancel":        { post: { summary: "Cancel a Stripe subscription", tags: ["Payment"], security: [{ cookieAuth: [] }], requestBody: { required: true, content: { "application/json": { schema: { type: "object", required: ["subscriptionId"], properties: { subscriptionId: { type: "string" } } } } } }, responses: { "200": { description: "Subscription cancelled." }, "502": { description: "Stripe error." } } } },
    "/extension/connect":     { post: { summary: "Register a browser extension connection", tags: ["Extension"], requestBody: { required: true, content: { "application/json": { schema: { type: "object", required: ["email"], properties: { email: { type: "string", format: "email" }, browser: { type: "string" }, version: { type: "string" } } } } } }, responses: { "200": { description: "Bearer token for subsequent requests." } } } },
    "/extension/disconnect":  { post: { summary: "Disconnect an extension", tags: ["Extension"], security: [{ bearerToken: [] }], responses: { "200": { description: "Disconnected." } } } },
    "/extension/status":      { get:  { summary: "Get extension connection status", tags: ["Extension"], security: [{ bearerToken: [] }], responses: { "200": { description: "Connection details." } } } },
    "/cloud/connect":         { post: { summary: "Establish a cloud connection", tags: ["Cloud"], requestBody: { required: true, content: { "application/json": { schema: { type: "object", required: ["email"], properties: { email: { type: "string", format: "email" }, profile: { type: "string", enum: ["balanced","cpu","gpu","memory"] }, region: { type: "string", enum: ["us-east-1","eu-west-1","ap-southeast-1"] } } } } } }, responses: { "200": { description: "Bearer token for subsequent cloud requests." } } } },
    "/cloud/disconnect":      { post: { summary: "Disconnect from cloud", tags: ["Cloud"], security: [{ bearerToken: [] }], responses: { "200": { description: "Disconnected." } } } },
    "/cloud/status":          { get:  { summary: "Get cloud connection and session status", tags: ["Cloud"], security: [{ bearerToken: [] }], responses: { "200": { description: "Connection and active session details." } } } },
    "/cloud/resources":       { get:  { summary: "List available resource profiles and regions", tags: ["Cloud"], responses: { "200": { description: "Profiles and regions array." } } } },
    "/analytics/browser":     { get:  { summary: "Browser/extension usage stats", tags: ["Analytics"], security: [{ cookieAuth: [] }], responses: { "200": { description: "Connection counts by profile and region." } } } },
    "/analytics/performance": { get:  { summary: "Performance metrics from sessions", tags: ["Analytics"], security: [{ cookieAuth: [] }], parameters: [{ in: "query", name: "days", schema: { type: "integer", default: 30, maximum: 365 } }], responses: { "200": { description: "Aggregate metrics and daily breakdown." } } } },
    "/analytics/history":     { get:  { summary: "Paginated session history", tags: ["Analytics"], security: [{ cookieAuth: [] }], parameters: [{ in: "query", name: "limit", schema: { type: "integer", default: 20 } }, { in: "query", name: "offset", schema: { type: "integer", default: 0 } }], responses: { "200": { description: "Session list." } } } },
    "/support/ticket":        { post: { summary: "Create a support ticket (public)", tags: ["Support"], requestBody: { required: true, content: { "application/json": { schema: { type: "object", required: ["subject","email"], properties: { subject: { type: "string", maxLength: 200 }, email: { type: "string", format: "email" }, message: { type: "string", maxLength: 5000 }, priority: { type: "string", enum: ["Low","Normal","High","Critical"], default: "Normal" } } } } } }, responses: { "201": { description: "Ticket created." } } } },
    "/support/tickets":       { get:  { summary: "List authenticated user's tickets", tags: ["Support"], security: [{ cookieAuth: [] }], parameters: [{ in: "query", name: "status", schema: { type: "string" } }], responses: { "200": { description: "Ticket list." } } } },
    "/support/reply":         { post: { summary: "Add a reply to a ticket", tags: ["Support"], security: [{ cookieAuth: [] }], requestBody: { required: true, content: { "application/json": { schema: { type: "object", required: ["ticketId","message"], properties: { ticketId: { type: "integer" }, message: { type: "string", maxLength: 5000 } } } } } }, responses: { "201": { description: "Reply added." }, "403": { description: "Not your ticket." }, "409": { description: "Ticket is closed." } } } },
    "/notification/send-email":      { post: { summary: "Send a transactional email (admin)", tags: ["Notification"], security: [{ adminCookie: [] }], requestBody: { required: true, content: { "application/json": { schema: { type: "object", required: ["to","subject"], properties: { to: { type: "string", format: "email" }, subject: { type: "string" }, html: { type: "string" }, text: { type: "string" } } } } } }, responses: { "200": { description: "Email sent." }, "503": { description: "Email service not configured." } } } },
    "/notification/security-alert":  { post: { summary: "Send a security alert email (admin)", tags: ["Notification"], security: [{ adminCookie: [] }], requestBody: { required: true, content: { "application/json": { schema: { type: "object", required: ["to","event"], properties: { to: { type: "string", format: "email" }, event: { type: "string" }, description: { type: "string" }, ip: { type: "string" } } } } } }, responses: { "200": { description: "Alert sent." } } } },
    "/security/sessions":     { get:  { summary: "List user's cloud connections", tags: ["Security"], security: [{ cookieAuth: [] }], responses: { "200": { description: "Session list." } } } },
    "/security/logout-all":   { post: { summary: "Terminate all cloud connections and sessions", tags: ["Security"], security: [{ cookieAuth: [] }], responses: { "200": { description: "All sessions terminated." } } } },
    "/security/activity":     { get:  { summary: "Recent security events for the user", tags: ["Security"], security: [{ cookieAuth: [] }], parameters: [{ in: "query", name: "limit", schema: { type: "integer", default: 20 } }], responses: { "200": { description: "Event list." } } } },
    "/security/2fa":          { post: { summary: "Manage TOTP 2FA (setup / enable / disable)", tags: ["Security"], security: [{ cookieAuth: [] }], requestBody: { required: true, content: { "application/json": { schema: { type: "object", required: ["action"], properties: { action: { type: "string", enum: ["setup","enable","disable"] }, code: { type: "string", description: "6-digit TOTP code (required for enable/disable)" } } } } } }, responses: { "200": { description: "Result of the 2FA action." }, "400": { description: "Invalid code or missing params." } } } },
    "/admin/dashboard":       { get:  { summary: "Admin overview dashboard metrics", tags: ["Admin"], security: [{ adminCookie: [] }], parameters: [{ in: "query", name: "period", schema: { type: "string", enum: ["today","week","month","year","custom"] } }], responses: { "200": { description: "Dashboard data." } } } },
    "/admin/users":           { get:  { summary: "List and search users", tags: ["Admin"], security: [{ adminCookie: [] }], responses: { "200": { description: "User list." } } } },
    "/admin/payments":        { get:  { summary: "List payments", tags: ["Admin"], security: [{ adminCookie: [] }], responses: { "200": { description: "Payment list." } } } },
    "/admin/security":        { get:  { summary: "Security events log", tags: ["Admin"], security: [{ adminCookie: [] }], responses: { "200": { description: "Events." } } } },
    "/admin/tickets":         { get:  { summary: "Support tickets", tags: ["Admin"], security: [{ adminCookie: [] }], responses: { "200": { description: "Ticket list." } } } },
    "/admin/analytics":       { get:  { summary: "Platform analytics", tags: ["Admin"], security: [{ adminCookie: [] }], responses: { "200": { description: "Analytics data." } } } },
    "/admin/partners":        { post: { summary: "Create a partner", tags: ["Admin"], security: [{ adminCookie: [] }], responses: { "201": { description: "Partner created." } } } },
    "/admin/content":         { put:  { summary: "Update CMS content", tags: ["Admin"], security: [{ adminCookie: [] }], requestBody: { required: true, content: { "application/json": { schema: { type: "object", required: ["type","id"], properties: { type: { type: "string", enum: ["page","blog","job"] }, id: { type: "string" }, data: { type: "object" } } } } } }, responses: { "200": { description: "Content updated." } } } },
  },
};

// GET /docs/openapi.json — machine-readable OpenAPI 3 spec
router.get("/docs/openapi.json", (_req: Request, res: Response): void => {
  res.json(openApiSpec);
});

// GET /docs — Swagger UI
router.get("/docs", (_req: Request, res: Response): void => {
  res.setHeader("Content-Type", "text/html; charset=utf-8");
  res.send(`<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>OREXUP API Docs</title>
  <link rel="stylesheet" href="https://unpkg.com/swagger-ui-dist@5/swagger-ui.css">
  <style>body{margin:0} .topbar{display:none}</style>
</head>
<body>
  <div id="swagger-ui"></div>
  <script src="https://unpkg.com/swagger-ui-dist@5/swagger-ui-bundle.js"></script>
  <script>
    SwaggerUIBundle({
      url: '/api/docs/openapi.json',
      dom_id: '#swagger-ui',
      deepLinking: true,
      presets: [SwaggerUIBundle.presets.apis, SwaggerUIBundle.SwaggerUIStandalonePreset],
      layout: 'BaseLayout',
      tryItOutEnabled: true,
      requestInterceptor: (req) => { req.credentials = 'include'; return req; },
    });
  </script>
</body>
</html>`);
});

export default router;

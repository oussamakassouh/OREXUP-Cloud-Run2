import { useState } from "react";
import { CalendarRange } from "lucide-react";

export type Period = "today" | "week" | "month" | "year" | "custom";

export interface PeriodParams {
  period: Period;
  from?: string;
  to?: string;
}

const PERIODS: { value: Period; label: string }[] = [
  { value: "today",  label: "Today" },
  { value: "week",   label: "Week" },
  { value: "month",  label: "Month" },
  { value: "year",   label: "Year" },
  { value: "custom", label: "Custom" },
];

function todayStr() {
  return new Date().toISOString().split("T")[0];
}
function daysAgo(n: number) {
  return new Date(Date.now() - n * 86_400_000).toISOString().split("T")[0];
}

export function usePeriodFilter(defaultPeriod: Period = "month") {
  const [period, setPeriod] = useState<Period>(defaultPeriod);
  const [customFrom, setCustomFrom] = useState(() => daysAgo(30));
  const [customTo, setCustomTo]     = useState(() => todayStr());
  const [appliedFrom, setAppliedFrom] = useState(customFrom);
  const [appliedTo, setAppliedTo]     = useState(customTo);

  const apply = () => {
    setAppliedFrom(customFrom);
    setAppliedTo(customTo);
  };

  const queryParams: PeriodParams =
    period === "custom"
      ? { period, from: appliedFrom, to: appliedTo }
      : { period };

  const label =
    period === "custom"
      ? `${appliedFrom} → ${appliedTo}`
      : period === "today"  ? "today"
      : period === "week"   ? "past 7 days"
      : period === "month"  ? "past 30 days"
      : "past 12 months";

  return {
    period, setPeriod,
    customFrom, setCustomFrom,
    customTo, setCustomTo,
    apply, queryParams, label,
  };
}

interface PeriodFilterProps {
  period: Period;
  onPeriodChange: (p: Period) => void;
  customFrom: string;
  customTo: string;
  onCustomFromChange: (v: string) => void;
  onCustomToChange: (v: string) => void;
  onApply: () => void;
}

export function PeriodFilter({
  period, onPeriodChange,
  customFrom, customTo,
  onCustomFromChange, onCustomToChange,
  onApply,
}: PeriodFilterProps) {
  return (
    <div className="flex flex-wrap items-center gap-3">
      <div className="flex items-center gap-1 p-1 bg-white/5 border border-white/8 rounded-xl">
        {PERIODS.map((p) => (
          <button
            key={p.value}
            onClick={() => onPeriodChange(p.value)}
            className={`flex items-center gap-1.5 px-4 py-1.5 rounded-lg text-sm font-medium transition-all ${
              period === p.value
                ? "bg-primary text-primary-foreground shadow-sm"
                : "text-muted-foreground hover:text-foreground hover:bg-white/5"
            }`}
          >
            {p.value === "custom" && <CalendarRange className="h-3.5 w-3.5" />}
            {p.label}
          </button>
        ))}
      </div>

      {period === "custom" && (
        <div className="flex items-center gap-2 flex-wrap">
          <div className="flex items-center gap-2 bg-white/5 border border-white/10 rounded-lg px-3 py-1.5">
            <span className="text-xs text-muted-foreground whitespace-nowrap">From</span>
            <input
              type="date"
              value={customFrom}
              max={customTo}
              onChange={(e) => onCustomFromChange(e.target.value)}
              className="bg-transparent text-sm text-foreground outline-none [color-scheme:dark] cursor-pointer"
            />
          </div>
          <span className="text-muted-foreground text-xs">→</span>
          <div className="flex items-center gap-2 bg-white/5 border border-white/10 rounded-lg px-3 py-1.5">
            <span className="text-xs text-muted-foreground whitespace-nowrap">To</span>
            <input
              type="date"
              value={customTo}
              min={customFrom}
              max={todayStr()}
              onChange={(e) => onCustomToChange(e.target.value)}
              className="bg-transparent text-sm text-foreground outline-none [color-scheme:dark] cursor-pointer"
            />
          </div>
          <button
            onClick={onApply}
            className="px-4 py-1.5 bg-primary text-primary-foreground text-sm font-medium rounded-lg hover:bg-primary/90 transition-colors"
          >
            Apply
          </button>
        </div>
      )}
    </div>
  );
}

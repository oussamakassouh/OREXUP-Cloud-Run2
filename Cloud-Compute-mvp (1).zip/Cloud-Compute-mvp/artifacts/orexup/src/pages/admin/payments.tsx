import { useState, useEffect } from "react";
import { AdminLayout } from "@/components/admin-layout";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { useToast } from "@/hooks/use-toast";
import {
  DollarSign, Repeat, ArrowDownLeft, Undo2,
  FlaskConical, Zap, CheckCircle2, AlertCircle, ChevronDown, ChevronUp,
} from "lucide-react";
import { useGetAdminPayments, type AdminPayment } from "@workspace/api-client-react";
import { PeriodFilter, usePeriodFilter } from "@/components/period-filter";

const PAGE_SIZE = 8;

function formatCents(cents: number) {
  return `$${(cents / 100).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}
function formatDate(iso: string) {
  return new Date(iso).toISOString().split("T")[0];
}
function cap(s: string) {
  return s.charAt(0).toUpperCase() + s.slice(1);
}

type ProviderMode = "test" | "live";

interface StripeStatus {
  connected: boolean;
  mode: ProviderMode;
  publicKey: string | null;
}

const PROVIDER_FEATURES = [
  { key: "subscriptions", label: "Subscriptions", icon: Repeat },
  { key: "history",       label: "Payment History", icon: DollarSign },
  { key: "invoices",      label: "Invoices", icon: ArrowDownLeft },
  { key: "refunds",       label: "Refunds", icon: Undo2 },
  { key: "revenue",       label: "Revenue", icon: DollarSign },
];

function StripeProviderCard({ status }: { status: StripeStatus | null }) {
  const [expanded, setExpanded] = useState(false);

  return (
    <Card className={`border transition-colors ${status?.connected ? "border-primary/30 bg-card/60" : "border-white/5 bg-card/30"}`}>
      <CardHeader className="pb-4">
        <div className="flex items-start justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-[#635BFF]/15 border border-[#635BFF]/30 flex items-center justify-center">
              <span className="text-[#635BFF] font-bold text-lg font-mono">S</span>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <CardTitle className="text-base">Stripe</CardTitle>
                {status?.connected && (
                  <Badge className="bg-green-500/15 text-green-400 border-green-500/20 text-[10px] px-1.5 py-0">ACTIVE</Badge>
                )}
              </div>
              <CardDescription className="text-xs mt-0.5">Global payments infrastructure</CardDescription>
            </div>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            {status === null ? (
              <span className="text-xs text-muted-foreground">Loading…</span>
            ) : status.connected ? (
              <div className="flex items-center gap-1.5 text-xs">
                <CheckCircle2 className="h-3.5 w-3.5 text-green-400" />
                <span className="text-green-400">Connected</span>
              </div>
            ) : (
              <div className="flex items-center gap-1.5 text-xs">
                <AlertCircle className="h-3.5 w-3.5 text-amber-400" />
                <span className="text-amber-400">Not configured</span>
              </div>
            )}
          </div>
        </div>

        {status?.connected && (
          <div className="flex items-center gap-3 mt-4 pt-4 border-t border-white/5">
            <div className="flex items-center gap-1 p-0.5 bg-white/5 rounded-lg">
              <div className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium ${
                status.mode === "test" ? "bg-amber-500/20 text-amber-400" : "text-muted-foreground"
              }`}>
                <FlaskConical className="h-3 w-3" /> Test
              </div>
              <div className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium ${
                status.mode === "live" ? "bg-green-500/20 text-green-400" : "text-muted-foreground"
              }`}>
                <Zap className="h-3 w-3" /> Live
              </div>
            </div>
            <span className="text-xs text-muted-foreground">
              Currently in <span className={status.mode === "live" ? "text-green-400" : "text-amber-400"}>{status.mode} mode</span>
            </span>
          </div>
        )}
      </CardHeader>

      <CardContent className="pt-0 space-y-4">
        <div className="flex flex-wrap gap-2">
          {PROVIDER_FEATURES.map((f) => (
            <span key={f.key} className="flex items-center gap-1 text-[11px] bg-white/5 border border-white/8 rounded-full px-2.5 py-1 text-muted-foreground">
              <CheckCircle2 className="h-3 w-3 text-primary" />
              {f.label}
            </span>
          ))}
        </div>

        {status?.connected && (
          <div>
            <button
              className="flex items-center gap-2 text-xs text-muted-foreground hover:text-foreground transition-colors w-full"
              onClick={() => setExpanded((v) => !v)}
            >
              <span>Publishable Key</span>
              {expanded ? <ChevronUp className="h-3.5 w-3.5 ml-auto" /> : <ChevronDown className="h-3.5 w-3.5 ml-auto" />}
            </button>
            {expanded && status.publicKey && (
              <div className="mt-3 p-4 bg-black/20 rounded-lg border border-white/5">
                <Label className="text-xs text-muted-foreground">Publishable Key (read-only)</Label>
                <Input
                  readOnly
                  value={status.publicKey}
                  className="bg-black/30 font-mono text-xs h-8 mt-1.5 opacity-70"
                />
                <p className="text-[10px] text-muted-foreground mt-1.5">Secret key is stored securely server-side.</p>
              </div>
            )}
          </div>
        )}

        {!status?.connected && (
          <div className="text-xs text-muted-foreground bg-amber-500/5 border border-amber-500/20 rounded-lg px-3 py-2">
            Add <span className="font-mono">STRIPE_SECRET_KEY</span> and <span className="font-mono">STRIPE_PUBLISHABLE_KEY</span> to your environment secrets to enable payments.
          </div>
        )}
      </CardContent>
    </Card>
  );
}

function YouCanProviderCard() {
  return (
    <Card className="border border-white/5 bg-card/30 opacity-60">
      <CardHeader className="pb-4">
        <div className="flex items-start justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center">
              <span className="text-emerald-400 font-bold text-lg font-mono">Y</span>
            </div>
            <div>
              <CardTitle className="text-base">YouCan Pay</CardTitle>
              <CardDescription className="text-xs mt-0.5">MENA-focused payment gateway</CardDescription>
            </div>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <span className="text-xs text-muted-foreground">Disabled</span>
            <Switch checked={false} disabled data-testid="switch-provider-youcan" />
          </div>
        </div>
      </CardHeader>
    </Card>
  );
}

export default function AdminPaymentsPage() {
  const { period, setPeriod, customFrom, setCustomFrom, customTo, setCustomTo, apply, queryParams, label } =
    usePeriodFilter("month");
  const { data, isLoading, isError } = useGetAdminPayments(queryParams);
  const summary  = data?.summary;
  const payments: AdminPayment[] = data?.payments ?? [];
  const [activeTab, setActiveTab] = useState<"providers" | "transactions" | "plans">("providers");
  const [page, setPage]           = useState(1);
  const [refundTarget, setRefundTarget] = useState<AdminPayment | null>(null);
  const [stripeStatus, setStripeStatus] = useState<StripeStatus | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    fetch("/api/billing/stripe-status")
      .then((r) => r.json() as Promise<StripeStatus>)
      .then(setStripeStatus)
      .catch(() => setStripeStatus({ connected: false, mode: "test", publicKey: null }));
  }, []);

  const totalPages    = Math.max(1, Math.ceil(payments.length / PAGE_SIZE));
  const currentPage   = Math.min(page, totalPages);
  const pagedPayments = payments.slice((currentPage - 1) * PAGE_SIZE, currentPage * PAGE_SIZE);

  const handleRefund = () => {
    if (!refundTarget) return;
    toast({
      title: "Use Stripe Dashboard",
      description: `To refund ${formatCents(refundTarget.amountCents)}, process it directly in the Stripe Dashboard under Payments.`,
    });
    setRefundTarget(null);
  };

  const handleSavePlan = (plan: string) => {
    toast({
      title: "Display Only",
      description: `${plan} pricing shown here is for reference. Update PLAN_CONFIG in the codebase to change live prices.`,
    });
  };

  return (
    <AdminLayout title="Payments & Billing">
      <div className="space-y-6">
        {isError && (
          <Card className="border-red-500/20 bg-red-500/5">
            <CardContent className="py-4 text-sm text-red-400">Failed to load payments data.</CardContent>
          </Card>
        )}

        <PeriodFilter
          period={period} onPeriodChange={setPeriod}
          customFrom={customFrom} customTo={customTo}
          onCustomFromChange={setCustomFrom} onCustomToChange={setCustomTo}
          onApply={apply}
        />

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card className="border-white/5 bg-card/50">
            <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
              <CardTitle className="text-sm font-medium text-muted-foreground">Revenue</CardTitle>
              <DollarSign className="h-4 w-4 text-primary" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold font-heading">{isLoading ? "—" : formatCents(summary?.revenueCents ?? 0)}</div>
              <p className="text-xs text-muted-foreground mt-1 truncate" title={label}>{label}</p>
            </CardContent>
          </Card>
          <Card className="border-white/5 bg-card/50">
            <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
              <CardTitle className="text-sm font-medium text-muted-foreground">Subscriptions</CardTitle>
              <Repeat className="h-4 w-4 text-purple-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold font-heading">{isLoading ? "—" : `${(summary?.activeSubscriptions ?? 0).toLocaleString()} active`}</div>
              <p className="text-xs text-muted-foreground mt-1">
                Starter: {(summary?.standardCount ?? 0).toLocaleString()} · Premium: {(summary?.premiumCount ?? 0).toLocaleString()}
              </p>
            </CardContent>
          </Card>
          <Card className="border-white/5 bg-card/50">
            <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
              <CardTitle className="text-sm font-medium text-muted-foreground">Refunds</CardTitle>
              <ArrowDownLeft className="h-4 w-4 text-red-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold font-heading">{isLoading ? "—" : (summary?.refundCount ?? 0).toLocaleString()}</div>
              <p className="text-xs text-muted-foreground mt-1 truncate">{formatCents(summary?.refundAmountCents ?? 0)} · {label}</p>
            </CardContent>
          </Card>
        </div>

        <div className="flex items-center justify-between gap-4 flex-wrap">
          <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as typeof activeTab)}>
            <TabsList className="bg-white/5 border border-white/10">
              <TabsTrigger value="providers" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground text-xs">
                Payment Providers
              </TabsTrigger>
              <TabsTrigger value="transactions" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground text-xs">
                Transactions
              </TabsTrigger>
              <TabsTrigger value="plans" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground text-xs">
                Manage Plans
              </TabsTrigger>
            </TabsList>
          </Tabs>

          {activeTab === "providers" && stripeStatus && (
            <div className="flex items-center gap-2 text-xs text-muted-foreground bg-white/5 border border-white/8 rounded-lg px-3 py-2">
              <span className={`w-1.5 h-1.5 rounded-full ${stripeStatus.connected ? "bg-green-400" : "bg-amber-400"}`} />
              {stripeStatus.connected
                ? <span>Active provider: <span className="text-foreground font-medium">Stripe</span> · <span className={stripeStatus.mode === "live" ? "text-green-400" : "text-amber-400"}>{stripeStatus.mode} mode</span></span>
                : <span className="text-amber-400">No provider active — payments are paused</span>
              }
            </div>
          )}
        </div>

        {activeTab === "providers" && (
          <div className="space-y-4">
            <p className="text-xs text-muted-foreground">
              Stripe is the active payment processor. Configure keys via environment secrets.
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <StripeProviderCard status={stripeStatus} />
              <YouCanProviderCard />
            </div>
          </div>
        )}

        {activeTab === "transactions" && (
          <Card className="border-white/5 bg-card/50">
            <Table>
              <TableHeader>
                <TableRow className="border-white/5 hover:bg-transparent">
                  <TableHead>Payment ID</TableHead>
                  <TableHead>User</TableHead>
                  <TableHead>Plan</TableHead>
                  <TableHead>Amount</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {pagedPayments.map((p) => (
                  <TableRow key={p.id} className="border-white/5 hover:bg-white/5">
                    <TableCell className="font-medium font-mono text-xs">PAY-{p.id}</TableCell>
                    <TableCell>{p.user}</TableCell>
                    <TableCell>{cap(p.plan)}</TableCell>
                    <TableCell>{formatCents(p.amountCents)}</TableCell>
                    <TableCell className="text-muted-foreground">{formatDate(p.date)}</TableCell>
                    <TableCell>
                      <Badge variant="outline" className={
                        p.status.toLowerCase() === "paid"    ? "text-green-500 border-green-500/20 bg-green-500/10" :
                        p.status.toLowerCase() === "pending" ? "text-amber-500 border-amber-500/20 bg-amber-500/10" :
                        "text-red-500 border-red-500/20 bg-red-500/10"
                      }>
                        {cap(p.status)}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right">
                      <Button
                        variant="ghost" size="sm"
                        className="h-8 text-muted-foreground hover:text-red-500 hover:bg-red-500/10 disabled:opacity-30"
                        disabled={p.status.toLowerCase() !== "paid"}
                        onClick={() => setRefundTarget(p)}
                        data-testid={`button-refund-${p.id}`}
                      >
                        <Undo2 className="h-3.5 w-3.5 mr-1.5" /> Refund
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
                {payments.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center py-8 text-muted-foreground">
                      {isLoading ? "Loading…" : "No data available"}
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
            {payments.length > 0 && (
              <div className="p-4 border-t border-white/5 flex items-center justify-between text-sm text-muted-foreground">
                <div>Showing {(currentPage - 1) * PAGE_SIZE + 1}–{Math.min(currentPage * PAGE_SIZE, payments.length)} of {payments.length}</div>
                <div className="flex items-center gap-2">
                  <span className="text-xs">Page {currentPage} of {totalPages}</span>
                  <Button variant="outline" size="sm" disabled={currentPage <= 1} onClick={() => setPage((p) => Math.max(1, p - 1))} data-testid="button-payments-prev">Previous</Button>
                  <Button variant="outline" size="sm" disabled={currentPage >= totalPages} onClick={() => setPage((p) => Math.min(totalPages, p + 1))} data-testid="button-payments-next">Next</Button>
                </div>
              </div>
            )}
          </Card>
        )}

        {activeTab === "plans" && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              { name: "Starter Plan",  monthly: "9.00",  annual: "99.00",  features: "120 hrs/mo, Email Support, 1 Cloud Session" },
              { name: "Premium Plan",  monthly: "29.00", annual: "299.00", features: "240 hrs/mo, Priority Support, 5 Cloud Sessions" },
              { name: "Ultimate Plan", monthly: "49.00", annual: "499.00", features: "Unlimited hrs, 24/7 Support, Unlimited Sessions" },
            ].map((plan) => (
              <Card key={plan.name} className="border-white/5 bg-card/50">
                <CardHeader>
                  <CardTitle className="text-base">{plan.name}</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-2">
                      <Label className="text-xs">Monthly Price ($)</Label>
                      <Input defaultValue={plan.monthly} className="bg-black/20 font-mono text-sm" />
                    </div>
                    <div className="space-y-2">
                      <Label className="text-xs">Annual Price ($)</Label>
                      <Input defaultValue={plan.annual} className="bg-black/20 font-mono text-sm" />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label className="text-xs">Features</Label>
                    <Input defaultValue={plan.features} className="bg-black/20 text-xs" />
                  </div>
                  <Button size="sm" className="w-full" onClick={() => handleSavePlan(plan.name)}>Save Changes</Button>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>

      <AlertDialog open={!!refundTarget} onOpenChange={(o) => !o && setRefundTarget(null)}>
        <AlertDialogContent className="bg-[#0a0f16] border-white/10">
          <AlertDialogHeader>
            <AlertDialogTitle>Process Refund?</AlertDialogTitle>
            <AlertDialogDescription>
              This will refund <strong>{refundTarget ? formatCents(refundTarget.amountCents) : ""}</strong> to the customer. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="bg-white/5 border-white/10 hover:bg-white/10">Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleRefund} className="bg-red-500 hover:bg-red-600 text-white">Process Refund</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </AdminLayout>
  );
}

import { pgTable, text, serial, integer, timestamp, index } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const cloudConnectionsTable = pgTable("cloud_connections", {
  id: serial("id").primaryKey(),
  token: text("token").notNull().unique(),
  userEmail: text("user_email").notNull(),
  profile: text("profile").notNull().default("balanced"),
  region: text("region").notNull().default("us-east-1"),
  status: text("status").notNull().default("connected"),
  activeSessionId: integer("active_session_id"),
  connectedAt: timestamp("connected_at", { withTimezone: true }).notNull().defaultNow(),
  lastSeenAt: timestamp("last_seen_at", { withTimezone: true }).notNull().defaultNow(),
  disconnectedAt: timestamp("disconnected_at", { withTimezone: true }),
}, (t) => [
  index("cloud_connections_user_email_idx").on(t.userEmail),
  index("cloud_connections_status_idx").on(t.status),
  index("cloud_connections_last_seen_at_idx").on(t.lastSeenAt),
]);

export const insertCloudConnectionSchema = createInsertSchema(cloudConnectionsTable).omit({
  id: true,
  connectedAt: true,
});
export type InsertCloudConnection = z.infer<typeof insertCloudConnectionSchema>;
export type CloudConnection = typeof cloudConnectionsTable.$inferSelect;

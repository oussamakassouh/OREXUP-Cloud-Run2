import DOMPurify from "dompurify";
import { Layout } from "@/components/layout";
import { useGetPublicPage } from "@workspace/api-client-react";
import { Loader2 } from "lucide-react";

export function PublicPage({ slug, title }: { slug: string; title: string }) {
  const { data, isLoading, isError } = useGetPublicPage(slug);

  return (
    <Layout>
      <div className="container mx-auto px-4 py-16 max-w-3xl">
        {isLoading && (
          <div className="flex items-center justify-center py-24">
            <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
          </div>
        )}
        {isError && (
          <div className="py-24 text-center">
            <h1 className="text-2xl font-bold font-heading mb-3">{title}</h1>
            <p className="text-muted-foreground">This page hasn't been published yet. Check back soon.</p>
          </div>
        )}
        {data && (
          <>
            <h1 className="text-3xl md:text-4xl font-bold font-heading tracking-tight mb-2">{data.title}</h1>
            <p className="text-xs text-muted-foreground mb-10">Last updated {new Date(data.updatedAt).toLocaleDateString("en-US", { month: "long", day: "numeric", year: "numeric" })}</p>
            <div
              className="prose prose-invert prose-sm md:prose-base max-w-none"
              dangerouslySetInnerHTML={{ __html: DOMPurify.sanitize(data.content) }}
            />
          </>
        )}
      </div>
    </Layout>
  );
}

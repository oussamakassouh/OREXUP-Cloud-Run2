import { useState } from "react";
import { AdminLayout } from "@/components/admin-layout";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { Twitter, Linkedin, Github, Instagram, Youtube, Facebook, Globe, MessageCircle } from "lucide-react";
import { TwoFactorSetup } from "@/components/two-factor-setup";

const SOCIAL_PLATFORMS = [
  { key: "twitter",   label: "X (Twitter)",  icon: Twitter,       placeholder: "https://x.com/orexup" },
  { key: "linkedin",  label: "LinkedIn",     icon: Linkedin,      placeholder: "https://linkedin.com/company/orexup" },
  { key: "github",    label: "GitHub",       icon: Github,        placeholder: "https://github.com/orexup" },
  { key: "instagram", label: "Instagram",    icon: Instagram,     placeholder: "https://instagram.com/orexup" },
  { key: "youtube",   label: "YouTube",      icon: Youtube,       placeholder: "https://youtube.com/@orexup" },
  { key: "facebook",  label: "Facebook",     icon: Facebook,      placeholder: "https://facebook.com/orexup" },
  { key: "discord",   label: "Discord",      icon: MessageCircle, placeholder: "https://discord.gg/orexup" },
  { key: "website",   label: "Website",      icon: Globe,         placeholder: "https://orexup.com" },
];

export default function AdminSettingsPage() {
  const { toast } = useToast();

  const [socialLinks, setSocialLinks] = useState<Record<string, string>>(
    Object.fromEntries(SOCIAL_PLATFORMS.map((p) => [p.key, ""]))
  );

  const handleSave = (section: string) => {
    toast({
      title: "Settings Saved",
      description: `${section} settings have been updated successfully.`,
    });
  };

  return (
    <AdminLayout title="System Settings">
      <Tabs defaultValue="general" className="w-full">
        <TabsList className="grid w-full grid-cols-5 max-w-[700px] mb-6">
          <TabsTrigger value="general">General</TabsTrigger>
          <TabsTrigger value="email">Email</TabsTrigger>
          <TabsTrigger value="cloud">Cloud</TabsTrigger>
          <TabsTrigger value="security">Security</TabsTrigger>
          <TabsTrigger value="social">Social</TabsTrigger>
        </TabsList>

        <TabsContent value="general">
          <Card className="border-white/5 bg-card/50 max-w-2xl">
            <CardHeader>
              <CardTitle>General Settings</CardTitle>
              <CardDescription>Core platform configuration.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <Label>Platform Name</Label>
                <Input defaultValue="OREXUP" className="bg-black/20" />
              </div>
              <div className="space-y-2">
                <Label>Support Email</Label>
                <Input defaultValue="support@orexup.com" className="bg-black/20" />
              </div>
              <div className="space-y-2">
                <Label>Max Sessions Per User</Label>
                <Input type="number" defaultValue="5" className="bg-black/20" />
              </div>
              <div className="flex items-center justify-between p-4 border border-white/5 rounded-lg bg-black/20">
                <div className="space-y-0.5">
                  <Label className="text-base">Maintenance Mode</Label>
                  <p className="text-xs text-muted-foreground">Blocks all non-admin access.</p>
                </div>
                <Switch />
              </div>
              <Button onClick={() => handleSave("General")}>Save General Settings</Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="email">
          <Card className="border-white/5 bg-card/50 max-w-2xl">
            <CardHeader>
              <CardTitle>Email Configuration</CardTitle>
              <CardDescription>SMTP and automated message settings.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>SMTP Host</Label>
                  <Input defaultValue="smtp.orexup.com" className="bg-black/20" />
                </div>
                <div className="space-y-2">
                  <Label>SMTP Port</Label>
                  <Input defaultValue="587" className="bg-black/20" />
                </div>
              </div>
              <div className="space-y-2">
                <Label>From Email Address</Label>
                <Input defaultValue="noreply@orexup.com" className="bg-black/20" />
              </div>
              <div className="space-y-4">
                <div className="flex items-center justify-between p-4 border border-white/5 rounded-lg bg-black/20">
                  <div className="space-y-0.5">
                    <Label>Require Email Verification</Label>
                    <p className="text-xs text-muted-foreground">New users must verify email to login.</p>
                  </div>
                  <Switch defaultChecked />
                </div>
                <div className="flex items-center justify-between p-4 border border-white/5 rounded-lg bg-black/20">
                  <div className="space-y-0.5">
                    <Label>Send Welcome Email</Label>
                    <p className="text-xs text-muted-foreground">Send automated welcome on signup.</p>
                  </div>
                  <Switch defaultChecked />
                </div>
              </div>
              <Button onClick={() => handleSave("Email")}>Save Email Settings</Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="cloud">
          <Card className="border-white/5 bg-card/50 max-w-2xl">
            <CardHeader>
              <CardTitle>Cloud Infrastructure</CardTitle>
              <CardDescription>Manage session compute resources.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <Label>Default Region</Label>
                <Select defaultValue="eu-west-1">
                  <SelectTrigger className="bg-black/20">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="eu-west-1">Europe (eu-west-1)</SelectItem>
                    <SelectItem value="us-east-1">US East (us-east-1)</SelectItem>
                    <SelectItem value="us-west-2">US West (us-west-2)</SelectItem>
                    <SelectItem value="ap-south-1">Asia (ap-south-1)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Default Session Timeout</Label>
                <Select defaultValue="1h">
                  <SelectTrigger className="bg-black/20">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="30min">30 Minutes</SelectItem>
                    <SelectItem value="1h">1 Hour</SelectItem>
                    <SelectItem value="2h">2 Hours</SelectItem>
                    <SelectItem value="4h">4 Hours</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Max Cloud Nodes</Label>
                <Input type="number" defaultValue="100" className="bg-black/20" />
              </div>
              <div className="flex items-center justify-between p-4 border border-white/5 rounded-lg bg-black/20">
                <div className="space-y-0.5">
                  <Label>Auto-Scale Infrastructure</Label>
                  <p className="text-xs text-muted-foreground">Automatically provision nodes on load.</p>
                </div>
                <Switch defaultChecked />
              </div>
              <Button onClick={() => handleSave("Cloud")}>Save Cloud Settings</Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="security">
          <Card className="border-white/5 bg-card/50 max-w-2xl">
            <CardHeader>
              <CardTitle>Security Policies</CardTitle>
              <CardDescription>Global security controls and restrictions.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <TwoFactorSetup />
              <div className="space-y-2">
                <Label>Max Login Attempts</Label>
                <Input type="number" defaultValue="5" className="bg-black/20" />
                <p className="text-xs text-muted-foreground">Before temporary IP block.</p>
              </div>
              <div className="space-y-2">
                <Label>Admin IP Whitelist</Label>
                <Textarea placeholder="Enter IPs, one per line (leave blank for anywhere)" className="bg-black/20 h-24" />
              </div>
              <div className="flex items-center justify-between p-4 border border-white/5 rounded-lg bg-black/20">
                <div className="space-y-0.5">
                  <Label>Force HTTPS</Label>
                  <p className="text-xs text-muted-foreground">Redirect all HTTP traffic.</p>
                </div>
                <Switch defaultChecked />
              </div>
              <Button onClick={() => handleSave("Security")}>Save Security Settings</Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="social">
          <Card className="border-white/5 bg-card/50 max-w-2xl">
            <CardHeader>
              <CardTitle>Social Media Links</CardTitle>
              <CardDescription>Set the platform's public social media profiles.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-5">
              {SOCIAL_PLATFORMS.map(({ key, label, icon: Icon, placeholder }) => (
                <div key={key} className="space-y-1.5">
                  <Label className="flex items-center gap-2">
                    <Icon className="h-4 w-4 text-muted-foreground" />
                    {label}
                  </Label>
                  <div className="relative">
                    <Globe className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground pointer-events-none" />
                    <Input
                      type="url"
                      placeholder={placeholder}
                      value={socialLinks[key]}
                      onChange={(e) => setSocialLinks((prev) => ({ ...prev, [key]: e.target.value }))}
                      className="pl-9 bg-black/20"
                    />
                  </div>
                </div>
              ))}
              <div className="pt-2 flex items-center gap-3">
                <Button onClick={() => handleSave("Social Media")}>Save Social Links</Button>
                <Button
                  variant="ghost"
                  className="text-muted-foreground"
                  onClick={() => setSocialLinks(Object.fromEntries(SOCIAL_PLATFORMS.map((p) => [p.key, ""])))}
                >
                  Clear All
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

      </Tabs>
    </AdminLayout>
  );
}

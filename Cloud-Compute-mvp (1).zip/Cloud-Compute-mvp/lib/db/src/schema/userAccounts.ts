import { pgTable, text, serial, boolean, timestamp, index } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const userAccountsTable = pgTable("user_accounts", {
  id: serial("id").primaryKey(),
  email: text("email").notNull().unique(),
  name: text("name").notNull().default(""),
  passwordHash: text("password_hash").notNull(),
  emailVerified: boolean("email_verified").notNull().default(false),
  verifyToken: text("verify_token"),
  verifyTokenExpiresAt: timestamp("verify_token_expires_at", { withTimezone: true }),
  resetToken: text("reset_token"),
  resetTokenExpiresAt: timestamp("reset_token_expires_at", { withTimezone: true }),
  totpSecret: text("totp_secret"),
  totpEnabled: boolean("totp_enabled").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  lastLoginAt: timestamp("last_login_at", { withTimezone: true }),
}, (t) => [
  index("user_accounts_email_idx").on(t.email),
  index("user_accounts_verify_token_idx").on(t.verifyToken),
  index("user_accounts_reset_token_idx").on(t.resetToken),
]);

export const insertUserAccountSchema = createInsertSchema(userAccountsTable).omit({
  id: true,
  createdAt: true,
});
export type InsertUserAccount = z.infer<typeof insertUserAccountSchema>;
export type UserAccount = typeof userAccountsTable.$inferSelect;

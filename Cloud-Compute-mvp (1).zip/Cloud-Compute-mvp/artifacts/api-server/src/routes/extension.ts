import { Router, type IRouter, type Request, type Response } from "express";
import { randomUUID } from "crypto";
import { eq } from "drizzle-orm";
import { db, cloudConnectionsTable } from "@workspace/db";
import { logger } from "../lib/logger";

const router: IRouter = Router();

const EXT_PREFIX = "ext:";

function extEmail(email: string): string {
  return `${EXT_PREFIX}${email.toLowerCase().trim()}`;
}

async function resolveToken(req: Request, res: Response): Promise<typeof cloudConnectionsTable.$inferSelect | null> {
  const auth = req.headers.authorization ?? "";
  const token = auth.startsWith("Bearer ") ? auth.slice(7).trim() : String((req.query.token as string) ?? "");
  if (!token) {
    res.status(401).json({ error: "Bearer token required." });
    return null;
  }
  const [conn] = await db
    .select()
    .from(cloudConnectionsTable)
    .where(eq(cloudConnectionsTable.token, token))
    .limit(1);
  if (!conn) {
    res.status(404).json({ error: "Connection not found or token invalid." });
    return null;
  }
  return conn;
}

// POST /extension/connect — register a browser extension connection
router.post("/extension/connect", async (req: Request, res: Response): Promise<void> => {
  const { email, browser, version } = req.body as {
    email?: string;
    browser?: string;
    version?: string;
  };
  if (!email || !email.includes("@")) {
    res.status(400).json({ error: "Valid email required." });
    return;
  }

  const token = randomUUID();
  const key = extEmail(email);

  await db
    .update(cloudConnectionsTable)
    .set({ status: "disconnected", disconnectedAt: new Date() })
    .where(eq(cloudConnectionsTable.userEmail, key));

  const [conn] = await db
    .insert(cloudConnectionsTable)
    .values({
      token,
      userEmail: key,
      profile: browser ?? "extension",
      region: version ?? "1.0.0",
      status: "connected",
    })
    .returning();

  logger.info({ email, browser, version }, "Extension connected");
  res.json({
    token: conn.token,
    connectionId: conn.id,
    connectedAt: conn.connectedAt,
    browser: conn.profile,
    version: conn.region,
  });
});

// POST /extension/disconnect — disconnect a browser extension
router.post("/extension/disconnect", async (req: Request, res: Response): Promise<void> => {
  const conn = await resolveToken(req, res);
  if (!conn) return;

  await db
    .update(cloudConnectionsTable)
    .set({ status: "disconnected", disconnectedAt: new Date() })
    .where(eq(cloudConnectionsTable.id, conn.id));

  logger.info({ connectionId: conn.id }, "Extension disconnected");
  res.json({ disconnected: true, connectionId: conn.id });
});

// GET /extension/status — check extension connection status
router.get("/extension/status", async (req: Request, res: Response): Promise<void> => {
  const conn = await resolveToken(req, res);
  if (!conn) return;

  await db
    .update(cloudConnectionsTable)
    .set({ lastSeenAt: new Date() })
    .where(eq(cloudConnectionsTable.id, conn.id));

  res.json({
    connected: conn.status === "connected",
    connectionId: conn.id,
    browser: conn.profile,
    version: conn.region,
    connectedAt: conn.connectedAt,
    lastSeenAt: conn.lastSeenAt,
  });
});

export default router;

import type { Plan } from "@/lib/app-context";

export const PLAN_CONFIG: Record<Plan, { label: string; monthly: number; annual: number; features: string[] }> = {
  standard: { label: "Starter",  monthly: 9,  annual: 99,  features: ["120 hours / month", "Email support", "1 cloud session"] },
  premium:  { label: "Premium",  monthly: 29, annual: 299, features: ["240 hours / month", "Priority support", "5 cloud sessions"] },
  custom:   { label: "Ultimate", monthly: 49, annual: 499, features: ["Unlimited hours", "24/7 support", "Unlimited sessions"] },
};

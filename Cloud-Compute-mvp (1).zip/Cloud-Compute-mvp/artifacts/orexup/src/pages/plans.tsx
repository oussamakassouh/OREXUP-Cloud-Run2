import { useState } from "react";
import { useLocation } from "wouter";
import { motion } from "framer-motion";
import { Check, Zap, ArrowRight, LayoutDashboard } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Layout } from "@/components/layout";
import { CheckoutSteps } from "@/components/checkout-steps";
import type { Plan } from "@/lib/app-context";

const PLANS: { key: Plan; label: string; desc: string; monthly: number; annual: number; features: string[]; popular?: boolean }[] = [
  {
    key: "standard",
    label: "Starter",
    desc: "Perfect for getting started",
    monthly: 9,
    annual: 99,
    features: [
      "120 hours / month",
      "Email support",
      "1 cloud session",
      "Standard performance nodes",
    ],
  },
  {
    key: "premium",
    label: "Premium",
    desc: "For professional developers",
    monthly: 29,
    annual: 299,
    features: [
      "240 hours / month",
      "Priority support",
      "5 cloud sessions",
      "High-performance nodes",
      "Advanced analytics",
    ],
    popular: true,
  },
  {
    key: "custom",
    label: "Ultimate",
    desc: "For power users & teams",
    monthly: 49,
    annual: 499,
    features: [
      "Unlimited hours",
      "24/7 dedicated support",
      "Unlimited cloud sessions",
      "GPU-accelerated nodes",
      "Advanced analytics",
      "Custom cloud regions",
    ],
  },
];

export default function PlansPage() {
  const [, setLocation] = useLocation();
  const params = new URLSearchParams(window.location.search);
  const defaultPlan = (params.get("plan") ?? null) as Plan | null;
  const [annual, setAnnual] = useState(false);
  const [selected, setSelected] = useState<Plan | null>(defaultPlan);

  const handleSelect = (plan: Plan) => {
    setSelected(plan);
  };

  const handleContinue = () => {
    if (!selected) return;
    const q = new URLSearchParams({ plan: selected, billing: annual ? "annual" : "monthly" });
    setLocation(`/dashboard/checkout?${q.toString()}`);
  };

  return (
    <Layout>
      <div className="min-h-[calc(100vh-16rem)] py-16 px-4 relative">
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#80808012_1px,transparent_1px),linear-gradient(to_bottom,#80808012_1px,transparent_1px)] bg-[size:24px_24px] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_0%,#000_70%,transparent_100%)] pointer-events-none" />

        <div className="relative z-10 max-w-5xl mx-auto">
          <CheckoutSteps current={1} />

          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4 }}
            className="text-center mb-12"
          >
            <div className="inline-flex items-center gap-2 bg-primary/10 text-primary text-xs font-semibold px-3 py-1 rounded-full mb-4 border border-primary/20">
              <Zap className="h-3.5 w-3.5" /> Choose Your Plan
            </div>
            <h1 className="text-4xl font-bold font-heading mb-3">
              Start with the right plan
            </h1>
            <p className="text-muted-foreground text-base max-w-md mx-auto">
              All plans include a 30-day money-back guarantee. Upgrade or cancel anytime.
            </p>

            {/* Billing toggle */}
            <div className="flex items-center justify-center gap-3 mt-8">
              <Label className={`text-sm ${!annual ? "text-foreground font-medium" : "text-muted-foreground"}`}>Monthly</Label>
              <Switch
                checked={annual}
                onCheckedChange={setAnnual}
                data-testid="plans-billing-toggle"
              />
              <Label className={`text-sm ${annual ? "text-foreground font-medium" : "text-muted-foreground"}`}>
                Annual
                <span className="ml-1.5 text-[11px] bg-primary/10 text-primary border border-primary/20 px-1.5 py-0.5 rounded-full font-semibold">
                  Save 20%
                </span>
              </Label>
            </div>
          </motion.div>

          {/* Plan cards */}
          <div className="grid md:grid-cols-3 gap-6">
            {PLANS.map((plan, i) => {
              const isSelected = selected === plan.key;
              const price = annual ? plan.annual : plan.monthly;
              const period = annual ? "yr" : "mo";

              return (
                <motion.div
                  key={plan.key}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.4, delay: i * 0.08 }}
                >
                  <Card
                    className={`flex flex-col h-full cursor-pointer transition-all duration-200 relative ${
                      plan.popular
                        ? "border-primary shadow-[0_0_40px_-12px_rgba(var(--primary),0.35)]"
                        : "border-white/10 bg-card/50"
                    } ${isSelected ? "ring-2 ring-primary ring-offset-2 ring-offset-background" : ""}`}
                    onClick={() => handleSelect(plan.key)}
                    data-testid={`plan-card-${plan.key}`}
                  >
                    {plan.popular && (
                      <div className="absolute -top-3 inset-x-0 flex justify-center">
                        <Badge className="bg-primary text-primary-foreground text-[10px] px-3 shadow-lg">
                          MOST POPULAR
                        </Badge>
                      </div>
                    )}

                    <CardHeader className={`pb-4 ${plan.popular ? "pt-6" : ""}`}>
                      <div className="flex items-start justify-between">
                        <div>
                          <CardTitle className={plan.popular ? "text-primary" : ""}>{plan.label}</CardTitle>
                          <CardDescription className="mt-0.5">{plan.desc}</CardDescription>
                        </div>
                        {isSelected && (
                          <div className="h-5 w-5 rounded-full bg-primary flex items-center justify-center shrink-0 mt-0.5">
                            <Check className="h-3 w-3 text-primary-foreground" />
                          </div>
                        )}
                      </div>
                      <div className="mt-4">
                        <span className="text-4xl font-bold font-mono">${price}</span>
                        <span className="text-muted-foreground text-sm ml-1">/{period}</span>
                        {annual && (
                          <p className="text-xs text-muted-foreground mt-0.5">
                            <span className="text-green-500 font-medium">${plan.monthly * 12 - plan.annual} saved</span> vs monthly
                          </p>
                        )}
                      </div>
                    </CardHeader>

                    <CardContent className="flex-1">
                      <ul className="space-y-2.5">
                        {plan.features.map((f) => (
                          <li key={f} className="flex items-center gap-2.5 text-sm">
                            <Check className="h-4 w-4 text-primary shrink-0" />
                            {f}
                          </li>
                        ))}
                      </ul>
                    </CardContent>

                    <CardFooter className="pt-4">
                      <Button
                        className="w-full"
                        variant={isSelected ? "default" : plan.popular ? "default" : "outline"}
                        onClick={(e) => { e.stopPropagation(); handleSelect(plan.key); }}
                        data-testid={`plans-select-${plan.key}`}
                      >
                        {isSelected ? (
                          <><Check className="h-4 w-4 mr-1.5" /> Selected</>
                        ) : (
                          "Select Plan"
                        )}
                      </Button>
                    </CardFooter>
                  </Card>
                </motion.div>
              );
            })}
          </div>

          {/* Continue button */}
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, delay: 0.35 }}
            className="mt-10 flex flex-col items-center gap-4"
          >
            <Button
              size="lg"
              className="h-12 px-10 text-base gap-2 shadow-lg shadow-primary/20"
              disabled={!selected}
              onClick={handleContinue}
              data-testid="plans-continue"
            >
              Continue to Checkout
              <ArrowRight className="h-4 w-4" />
            </Button>
            {!selected && (
              <p className="text-xs text-muted-foreground">Select a plan above to continue</p>
            )}

            <button
              type="button"
              onClick={() => setLocation("/dashboard")}
              className="flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground transition-colors mt-2"
              data-testid="plans-skip"
            >
              <LayoutDashboard className="h-3.5 w-3.5" />
              I already have a plan — go to Dashboard
            </button>
          </motion.div>
        </div>
      </div>
    </Layout>
  );
}

import { DashboardLayout } from "@/components/dashboard-layout";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Puzzle, AlertTriangle, CheckCircle2, Download, ExternalLink, RefreshCw } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useAppContext } from "@/lib/app-context";

export default function InstallExtensionPage() {
  const { extensionInstalled, setExtensionInstalled } = useAppContext();
  const { toast } = useToast();

  const handleInstall = () => {
    setExtensionInstalled(true);
    toast({
      title: "Extension Installed",
      description: "OREXUP extension is now active in your browser.",
    });
  };

  const handleReconnect = () => {
    toast({
      title: "Reconnecting",
      description: "Establishing link to extension...",
    });
  };

  return (
    <DashboardLayout title="Install Extension">
      <div className="max-w-3xl mx-auto space-y-8">
        
        {extensionInstalled ? (
          <Alert className="bg-green-500/10 text-green-500 border-green-500/20">
            <CheckCircle2 className="h-5 w-5 !text-green-500" />
            <AlertTitle>Extension is active</AlertTitle>
            <AlertDescription className="text-green-500/80">
              Your browser is successfully connected to the OREXUP Cloud platform.
            </AlertDescription>
          </Alert>
        ) : (
          <Alert className="bg-amber-500/10 text-amber-500 border-amber-500/20">
            <AlertTriangle className="h-5 w-5 !text-amber-500" />
            <AlertTitle>Extension not detected</AlertTitle>
            <AlertDescription className="text-amber-500/80">
              You need to install the browser extension to route your tasks to the cloud.
            </AlertDescription>
          </Alert>
        )}

        <Card className="border-white/5 bg-card/50 backdrop-blur-sm overflow-hidden relative">
          <div className="absolute top-0 right-0 w-64 h-64 bg-primary/5 rounded-full blur-3xl -translate-y-1/2 translate-x-1/3 pointer-events-none"></div>
          
          <CardHeader className="text-center pt-12 pb-4">
            <div className="mx-auto w-20 h-20 bg-primary/10 rounded-2xl border border-primary/20 flex items-center justify-center mb-6">
              <Puzzle className="h-10 w-10 text-primary" />
            </div>
            <CardTitle className="text-3xl font-heading">OREXUP Extension</CardTitle>
            <CardDescription className="text-base max-w-md mx-auto mt-4">
              The OREXUP browser extension seamlessly connects your local browser environment to our high-performance cloud sessions.
            </CardDescription>
          </CardHeader>
          
          <CardContent className="flex flex-col items-center justify-center pb-12">
            {!extensionInstalled ? (
              <Button size="lg" className="px-8 h-12 text-md mt-4" onClick={handleInstall} data-testid="button-install-extension">
                <Download className="mr-2 h-5 w-5" />
                Install Extension
              </Button>
            ) : (
              <div className="flex gap-4 mt-4">
                <Button variant="outline" size="lg" data-testid="button-open-extension">
                  <ExternalLink className="mr-2 h-4 w-4" />
                  Open Extension
                </Button>
                <Button variant="ghost" size="lg" onClick={handleReconnect} data-testid="button-reconnect-extension">
                  <RefreshCw className="mr-2 h-4 w-4" />
                  Reconnect
                </Button>
              </div>
            )}
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="p-6 rounded-xl border border-white/5 bg-card/30">
            <h3 className="font-medium mb-2 flex items-center gap-2">
              <span className="flex items-center justify-center w-6 h-6 rounded-full bg-white/10 text-xs">1</span>
              Install
            </h3>
            <p className="text-sm text-muted-foreground">Add the lightweight extension to Chrome, Firefox, or Edge.</p>
          </div>
          <div className="p-6 rounded-xl border border-white/5 bg-card/30">
            <h3 className="font-medium mb-2 flex items-center gap-2">
              <span className="flex items-center justify-center w-6 h-6 rounded-full bg-white/10 text-xs">2</span>
              Authenticate
            </h3>
            <p className="text-sm text-muted-foreground">Log in to link your browser securely to your OREXUP account.</p>
          </div>
          <div className="p-6 rounded-xl border border-white/5 bg-card/30">
            <h3 className="font-medium mb-2 flex items-center gap-2">
              <span className="flex items-center justify-center w-6 h-6 rounded-full bg-white/10 text-xs">3</span>
              Accelerate
            </h3>
            <p className="text-sm text-muted-foreground">Heavy tasks are automatically routed to your cloud session.</p>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}

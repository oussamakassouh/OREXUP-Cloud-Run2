import { useState } from "react";
import { DashboardLayout } from "@/components/dashboard-layout";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { MessageSquare, LifeBuoy, BookOpen, Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useUserAuth } from "@/lib/user-auth";

const BASE = import.meta.env.BASE_URL?.replace(/\/$/, "") ?? "";

export default function SupportPage() {
  const { toast } = useToast();
  const { user } = useUserAuth();
  const [subject, setSubject] = useState("");
  const [category, setCategory] = useState("technical");
  const [description, setDescription] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const handleChat = () => {
    toast({
      title: "Live chat unavailable",
      description: "Live chat is currently unavailable, please create a ticket.",
      variant: "destructive"
    });
  };

  const handleSubmitTicket = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!subject.trim() || !description.trim()) return;
    setSubmitting(true);
    try {
      const res = await fetch(`${BASE}/api/support/ticket`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({
          email: user?.email ?? "",
          subject: subject.trim(),
          category,
          message: description.trim(),
        }),
      });
      const data = await res.json() as { ticket?: { id: number }; error?: string };
      if (!res.ok) {
        toast({ title: "Failed to submit ticket", description: data.error ?? "Please try again.", variant: "destructive" });
        return;
      }
      toast({
        title: "Ticket created",
        description: `Ticket #${data.ticket?.id} submitted. We'll get back to you shortly.`,
      });
      setSubject("");
      setDescription("");
      setCategory("technical");
    } catch {
      toast({ title: "Network error", description: "Could not reach the server.", variant: "destructive" });
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <DashboardLayout title="Support & Help">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Left Col: Tickets & Chat */}
        <div className="lg:col-span-2 space-y-8">
          <Card className="border-white/5 bg-card/50">
            <CardHeader>
              <div className="flex items-center gap-2">
                <LifeBuoy className="h-5 w-5 text-primary" />
                <CardTitle>Create Ticket</CardTitle>
              </div>
              <CardDescription>Submit a detailed request to our support team.</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmitTicket} className="space-y-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Subject</label>
                  <Input
                    placeholder="Brief summary of the issue"
                    required
                    value={subject}
                    onChange={(e) => setSubject(e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Category</label>
                  <Select value={category} onValueChange={setCategory}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="technical">Technical Support</SelectItem>
                      <SelectItem value="billing">Billing & Subscriptions</SelectItem>
                      <SelectItem value="general">General Inquiry</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Description</label>
                  <Textarea
                    placeholder="Please provide as much detail as possible..."
                    className="min-h-[120px]"
                    required
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                  />
                </div>
                <Button type="submit" className="w-full sm:w-auto" disabled={submitting}>
                  {submitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  Submit Ticket
                </Button>
              </form>
            </CardContent>
          </Card>

          <Card className="border-white/5 bg-gradient-to-br from-card/50 to-primary/5">
            <CardHeader>
              <div className="flex items-center gap-2">
                <MessageSquare className="h-5 w-5 text-primary" />
                <CardTitle>Live Chat</CardTitle>
              </div>
              <CardDescription>Talk directly with an engineer for immediate assistance.</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground mb-4">
                Average response time is currently &lt; 5 minutes. Support is available 24/7 for Premium users.
              </p>
              <Button variant="secondary" className="bg-white/10 hover:bg-white/20" onClick={handleChat}>
                Start Live Chat
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Right Col: FAQ */}
        <div className="lg:col-span-1">
          <Card className="border-white/5 bg-card/50 sticky top-24">
            <CardHeader>
              <div className="flex items-center gap-2">
                <BookOpen className="h-5 w-5 text-muted-foreground" />
                <CardTitle>FAQ</CardTitle>
              </div>
              <CardDescription>Quick answers to common questions.</CardDescription>
            </CardHeader>
            <CardContent>
              <Accordion type="single" collapsible className="w-full">
                <AccordionItem value="item-1" className="border-white/10">
                  <AccordionTrigger className="text-sm font-medium text-left">How do I connect OREXUP Cloud?</AccordionTrigger>
                  <AccordionContent className="text-sm text-muted-foreground">
                    Install the browser extension, log into the dashboard, and click the "Connect OREXUP Cloud" button in the Connect Cloud page.
                  </AccordionContent>
                </AccordionItem>
                <AccordionItem value="item-2" className="border-white/10">
                  <AccordionTrigger className="text-sm font-medium text-left">What browsers are supported?</AccordionTrigger>
                  <AccordionContent className="text-sm text-muted-foreground">
                    We currently support Google Chrome, Mozilla Firefox, Microsoft Edge, and Brave browsers via our universal extension.
                  </AccordionContent>
                </AccordionItem>
                <AccordionItem value="item-3" className="border-white/10">
                  <AccordionTrigger className="text-sm font-medium text-left">How do I upgrade my plan?</AccordionTrigger>
                  <AccordionContent className="text-sm text-muted-foreground">
                    Navigate to the Billing section in your dashboard and select "Upgrade to Premium". Changes take effect immediately.
                  </AccordionContent>
                </AccordionItem>
                <AccordionItem value="item-4" className="border-white/10">
                  <AccordionTrigger className="text-sm font-medium text-left">Are my sessions secure?</AccordionTrigger>
                  <AccordionContent className="text-sm text-muted-foreground">
                    Yes. All traffic between your browser and the cloud environment is end-to-end encrypted using AES-256. Instances are wiped after disconnection.
                  </AccordionContent>
                </AccordionItem>
                <AccordionItem value="item-5" className="border-white/10">
                  <AccordionTrigger className="text-sm font-medium text-left">Can I change performance modes while running?</AccordionTrigger>
                  <AccordionContent className="text-sm text-muted-foreground">
                    No. You must stop your current session, select a new performance mode, and start a new session for hardware reallocation to apply.
                  </AccordionContent>
                </AccordionItem>
              </Accordion>
            </CardContent>
          </Card>
        </div>

      </div>
    </DashboardLayout>
  );
}

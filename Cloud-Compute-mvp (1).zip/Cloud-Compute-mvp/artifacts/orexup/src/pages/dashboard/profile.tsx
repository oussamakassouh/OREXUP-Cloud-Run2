import { useState, useRef } from "react";
import { useForm, useWatch } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { DashboardLayout } from "@/components/dashboard-layout";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { Camera, Trash2, CheckCircle2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useI18n } from "@/lib/i18n";

const profileSchema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters"),
  email: z.string().email("Invalid email address"),
});

function getInitials(name: string) {
  return name.trim().split(/\s+/).map(w => w[0]?.toUpperCase() ?? "").join("").slice(0, 2) || "?";
}

export default function ProfilePage() {
  const { toast } = useToast();
  const { t } = useI18n();
  const [isEditing, setIsEditing] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const form = useForm<z.infer<typeof profileSchema>>({
    resolver: zodResolver(profileSchema),
    defaultValues: { name: "", email: "" }
  });

  const watchedName = useWatch({ control: form.control, name: "name" });
  const watchedEmail = useWatch({ control: form.control, name: "email" });

  const onProfileSubmit = () => {
    toast({ title: t.profile.toastUpdated, description: t.profile.toastUpdatedDesc });
    setIsEditing(false);
  };

  const handlePhotoChange = () => {
    fileInputRef.current?.click();
  };

  const handleFileSelected = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files?.[0]) {
      toast({ title: t.profile.toastPhoto, description: t.profile.toastPhotoDesc });
    }
    e.target.value = "";
  };

  const handleDeleteAccount = () => {
    toast({ title: t.profile.toastDeleted, description: t.profile.toastDeletedDesc, variant: "destructive" });
  };

  return (
    <DashboardLayout title={t.profile.pageTitle}>
      <div className="max-w-3xl space-y-8">
        <input ref={fileInputRef} type="file" accept="image/*" className="hidden" onChange={handleFileSelected} />

        {/* Avatar Section */}
        <Card className="border-white/5 bg-card/50">
          <CardContent className="p-8 flex flex-col sm:flex-row items-center gap-8">
            <Avatar className="h-24 w-24 border-2 border-primary/20">
              <AvatarFallback className="bg-primary/20 text-primary text-2xl font-bold">
                {watchedName ? getInitials(watchedName) : "?"}
              </AvatarFallback>
            </Avatar>
            <div className="text-center sm:text-left space-y-2">
              <h3 className="text-2xl font-bold font-heading">{watchedName || <span className="text-muted-foreground italic">No name set</span>}</h3>
              <p className="text-muted-foreground">{watchedEmail || <span className="italic">No email set</span>}</p>
              <Button variant="outline" size="sm" className="mt-2" onClick={handlePhotoChange}>
                <Camera className="mr-2 h-4 w-4" /> {t.profile.changePhoto}
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Profile Details Form */}
        <Card className="border-white/5 bg-card/50">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <div>
              <CardTitle>{t.profile.personalTitle}</CardTitle>
              <CardDescription>{t.profile.personalDesc}</CardDescription>
            </div>
            {!isEditing && (
              <Button variant="outline" onClick={() => setIsEditing(true)}>{t.profile.editBtn}</Button>
            )}
          </CardHeader>
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onProfileSubmit)} className="space-y-6 max-w-md">
                <FormField control={form.control} name="name" render={({ field }) => (
                  <FormItem>
                    <FormLabel>{t.profile.nameLabel}</FormLabel>
                    <FormControl>
                      <Input {...field} disabled={!isEditing} className="bg-white/5" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="email" render={({ field }) => (
                  <FormItem>
                    <FormLabel className="flex justify-between">
                      {t.profile.emailLabel}
                      {!isEditing && (
                        <Badge variant="outline" className="bg-green-500/10 text-green-500 border-green-500/20">
                          <CheckCircle2 className="h-3 w-3 mr-1" /> {t.profile.verifiedBadge}
                        </Badge>
                      )}
                    </FormLabel>
                    <FormControl>
                      <Input {...field} disabled={!isEditing} className="bg-white/5" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                {isEditing && (
                  <div className="flex gap-3 pt-2">
                    <Button type="submit">{t.profile.saveBtn}</Button>
                    <Button type="button" variant="ghost" onClick={() => { form.reset(); setIsEditing(false); }}>{t.profile.cancelBtn}</Button>
                  </div>
                )}
              </form>
            </Form>
          </CardContent>
        </Card>

        {/* Danger Zone */}
        <Card className="border-destructive/20 bg-destructive/5">
          <CardHeader>
            <div className="flex items-center gap-2 text-destructive">
              <Trash2 className="h-5 w-5" />
              <CardTitle>{t.profile.dangerTitle}</CardTitle>
            </div>
            <CardDescription className="text-destructive/80">{t.profile.dangerDesc}</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-sm mb-4">{t.profile.dangerBody}</p>
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button variant="destructive">{t.profile.deleteBtn}</Button>
              </AlertDialogTrigger>
              <AlertDialogContent className="bg-card border-white/10">
                <AlertDialogHeader>
                  <AlertDialogTitle>{t.profile.confirmTitle}</AlertDialogTitle>
                  <AlertDialogDescription>{t.profile.confirmDesc}</AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>{t.profile.confirmCancel}</AlertDialogCancel>
                  <AlertDialogAction className="bg-destructive hover:bg-destructive/90 text-destructive-foreground" onClick={handleDeleteAccount}>
                    {t.profile.confirmDelete}
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </CardContent>
        </Card>

      </div>
    </DashboardLayout>
  );
}

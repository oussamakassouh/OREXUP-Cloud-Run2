import { AdminLayout } from "@/components/admin-layout";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { LineChart, Line, BarChart, Bar, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useGetAdminAnalytics } from "@workspace/api-client-react";
import { PeriodFilter, usePeriodFilter } from "@/components/period-filter";

function getRetentionColor(pct: number) {
  if (pct >= 60) return "bg-green-500/20 text-green-400";
  if (pct >= 40) return "bg-amber-500/20 text-amber-400";
  return "bg-red-500/20 text-red-400";
}

function EmptyChart({ loading }: { loading: boolean }) {
  return (
    <div className="h-full flex items-center justify-center text-muted-foreground text-sm">
      {loading ? "Loading…" : "No data available"}
    </div>
  );
}

export default function AdminAnalyticsPage() {
  const { period, setPeriod, customFrom, setCustomFrom, customTo, setCustomTo, apply, queryParams, label } =
    usePeriodFilter("month");

  const { data, isLoading, isError } = useGetAdminAnalytics(queryParams);

  const growthData = data?.newUsersSeries ?? [];
  const usageData = data?.featureUsage ?? [];
  const volumeData = data?.sessionVolume ?? [];
  const retentionData = data?.retention ?? [];

  return (
    <AdminLayout title="Platform Analytics">
      <div className="space-y-6">
        {isError && (
          <Card className="border-red-500/20 bg-red-500/5">
            <CardContent className="py-4 text-sm text-red-400">Failed to load analytics data.</CardContent>
          </Card>
        )}

        <PeriodFilter
          period={period} onPeriodChange={setPeriod}
          customFrom={customFrom} customTo={customTo}
          onCustomFromChange={setCustomFrom} onCustomToChange={setCustomTo}
          onApply={apply}
        />

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card className="border-white/5 bg-card/50">
            <CardHeader>
              <CardTitle>New Users Over Time</CardTitle>
              <CardDescription>{label}</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[300px]">
                {growthData.length === 0 ? <EmptyChart loading={isLoading} /> : (
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={growthData} margin={{ top: 5, right: 30, left: 0, bottom: 5 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#333" vertical={false} />
                      <XAxis dataKey="name" stroke="#888" fontSize={12} tickLine={false} axisLine={false} />
                      <YAxis stroke="#888" fontSize={12} tickLine={false} axisLine={false} />
                      <Tooltip contentStyle={{ backgroundColor: '#111827', borderColor: '#1f2937', borderRadius: '8px' }} />
                      <Legend />
                      <Line type="monotone" dataKey="signups" stroke="hsl(var(--primary))" strokeWidth={2} dot={{ r: 4 }} activeDot={{ r: 6 }} name="Signups" />
                      <Line type="monotone" dataKey="active" stroke="#a855f7" strokeWidth={2} dot={{ r: 4 }} activeDot={{ r: 6 }} name="Active" />
                    </LineChart>
                  </ResponsiveContainer>
                )}
              </div>
            </CardContent>
          </Card>

          <Card className="border-white/5 bg-card/50">
            <CardHeader>
              <CardTitle>Feature Usage</CardTitle>
              <CardDescription>{label}</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[300px]">
                {usageData.length === 0 ? <EmptyChart loading={isLoading} /> : (
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={usageData} margin={{ top: 5, right: 30, left: 0, bottom: 5 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#333" vertical={false} />
                      <XAxis dataKey="name" stroke="#888" fontSize={12} tickLine={false} axisLine={false} />
                      <YAxis stroke="#888" fontSize={12} tickLine={false} axisLine={false} />
                      <Tooltip contentStyle={{ backgroundColor: '#111827', borderColor: '#1f2937', borderRadius: '8px' }} cursor={{ fill: '#ffffff10' }} />
                      <Bar dataKey="value" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                )}
              </div>
            </CardContent>
          </Card>

          <Card className="border-white/5 bg-card/50">
            <CardHeader>
              <CardTitle>Daily Session Volume</CardTitle>
              <CardDescription>{label}</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[300px]">
                {volumeData.length === 0 ? <EmptyChart loading={isLoading} /> : (
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={volumeData} margin={{ top: 5, right: 30, left: 0, bottom: 5 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#333" vertical={false} />
                      <XAxis dataKey="name" stroke="#888" fontSize={12} tickLine={false} axisLine={false} />
                      <YAxis stroke="#888" fontSize={12} tickLine={false} axisLine={false} />
                      <Tooltip contentStyle={{ backgroundColor: '#111827', borderColor: '#1f2937', borderRadius: '8px' }} />
                      <Legend />
                      <Area type="monotone" dataKey="standard" stackId="1" stroke="hsl(var(--primary))" fill="hsl(var(--primary))" fillOpacity={0.6} name="Standard" />
                      <Area type="monotone" dataKey="premium" stackId="1" stroke="#a855f7" fill="#a855f7" fillOpacity={0.6} name="Premium" />
                    </AreaChart>
                  </ResponsiveContainer>
                )}
              </div>
            </CardContent>
          </Card>

          <Card className="border-white/5 bg-card/50">
            <CardHeader>
              <CardTitle>Cohort Retention</CardTitle>
            </CardHeader>
            <CardContent>
              {retentionData.length === 0 ? (
                <div className="h-[200px] flex items-center justify-center text-muted-foreground text-sm">
                  {isLoading ? "Loading…" : "No data available"}
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow className="border-white/5 hover:bg-transparent">
                        <TableHead>Cohort</TableHead>
                        <TableHead>Week 1</TableHead>
                        <TableHead>Week 2</TableHead>
                        <TableHead>Week 4</TableHead>
                        <TableHead>Week 8</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {retentionData.map((row, i) => (
                        <TableRow key={i} className="border-white/5 hover:bg-white/5">
                          <TableCell className="font-medium text-xs">
                            <div>{row.cohort}</div>
                            <div className="text-muted-foreground">{row.users} users</div>
                          </TableCell>
                          <TableCell><div className={`inline-flex items-center justify-center w-10 h-6 rounded text-xs font-medium ${getRetentionColor(row.w1)}`}>{row.w1}%</div></TableCell>
                          <TableCell><div className={`inline-flex items-center justify-center w-10 h-6 rounded text-xs font-medium ${getRetentionColor(row.w2)}`}>{row.w2}%</div></TableCell>
                          <TableCell><div className={`inline-flex items-center justify-center w-10 h-6 rounded text-xs font-medium ${getRetentionColor(row.w4)}`}>{row.w4}%</div></TableCell>
                          <TableCell><div className={`inline-flex items-center justify-center w-10 h-6 rounded text-xs font-medium ${getRetentionColor(row.w8)}`}>{row.w8}%</div></TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </AdminLayout>
  );
}

import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import {
  LayoutDashboard,
  Cloud,
  Puzzle,
  BarChart2,
  CreditCard,
  LifeBuoy,
  Settings,
  User,
  LogOut,
  Menu,
  PlayCircle,
  Gauge,
  Bell,
  Route,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { ModeToggle } from "@/components/mode-toggle";
import { useUserAuth } from "@/lib/user-auth";

const navItems = [
  { icon: LayoutDashboard, label: "Dashboard", href: "/dashboard" },
  { icon: Cloud, label: "Connect Cloud", href: "/dashboard/connect-cloud" },
  { icon: Puzzle, label: "Install Extension", href: "/dashboard/install-extension" },
  { icon: Puzzle, label: "Extension", href: "/dashboard/extension" },
  { icon: PlayCircle, label: "Cloud Session", href: "/dashboard/cloud-session" },
  { icon: Gauge, label: "Metrics", href: "/dashboard/metrics" },
  { icon: Bell, label: "Notifications", href: "/dashboard/notifications" },
  { icon: Route, label: "Setup Flow", href: "/dashboard/flow" },
  { icon: BarChart2, label: "Analytics", href: "/dashboard/analytics" },
  { icon: CreditCard, label: "Billing", href: "/dashboard/billing" },
  { icon: LifeBuoy, label: "Support", href: "/dashboard/support" },
  { icon: Settings, label: "Settings", href: "/dashboard/settings" },
  { icon: User, label: "Profile", href: "/dashboard/profile" },
];

export function DashboardLayout({ children, title = "Dashboard" }: { children: React.ReactNode; title?: string }) {
  const [location, setLocation] = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [authChecked, setAuthChecked] = useState(false);
  const { isAuthenticated, signout } = useUserAuth();

  useEffect(() => {
    if (!isAuthenticated) {
      setLocation("/signin");
    } else {
      setAuthChecked(true);
    }
  }, [isAuthenticated, setLocation]);

  const handleLogout = () => {
    signout();
    setLocation("/signin");
  };

  if (!authChecked) return null;

  const SidebarContent = () => (
    <div className="flex flex-col h-full bg-card border-r border-white/5">
      <div className="p-6">
        <Link href="/" className="font-heading font-bold text-2xl tracking-tighter text-foreground" data-testid="dashboard-logo">
          OREXUP
        </Link>
      </div>
      <nav className="flex-1 px-4 space-y-1 overflow-y-auto">
        {navItems.map((item) => {
          const isActive = location === item.href;
          return (
            <Link key={item.href} href={item.href}>
              <div
                className={`flex items-center gap-3 px-3 py-2.5 rounded-md transition-all duration-200 cursor-pointer ${
                  isActive
                    ? "bg-primary/10 text-primary font-medium"
                    : "text-muted-foreground hover:bg-white/5 hover:text-foreground"
                }`}
                onClick={() => setMobileMenuOpen(false)}
                data-testid={`nav-item-${item.label.toLowerCase().replace(/\s+/g, "-")}`}
              >
                <item.icon className={`h-5 w-5 ${isActive ? "text-primary" : "text-muted-foreground"}`} />
                <span>{item.label}</span>
              </div>
            </Link>
          );
        })}
      </nav>
      <div className="p-4 border-t border-white/5">
        <Button
          variant="ghost"
          className="w-full justify-start text-muted-foreground hover:text-destructive hover:bg-destructive/10"
          onClick={handleLogout}
          data-testid="button-logout"
        >
          <LogOut className="mr-3 h-5 w-5" />
          Logout
        </Button>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-background flex flex-col md:flex-row">
      <aside className="hidden md:flex w-64 flex-col fixed inset-y-0 left-0 z-50">
        <SidebarContent />
      </aside>

      <div className="md:hidden flex items-center justify-between p-4 border-b border-white/5 bg-card sticky top-0 z-40">
        <Link href="/" className="font-heading font-bold text-xl tracking-tighter text-foreground">
          OREXUP
        </Link>
        <div className="flex items-center gap-4">
          <ModeToggle />
          <Sheet open={mobileMenuOpen} onOpenChange={setMobileMenuOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="md:hidden" data-testid="button-mobile-menu">
                <Menu className="h-6 w-6" />
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="p-0 w-64 bg-card border-r-white/10">
              <SidebarContent />
            </SheetContent>
          </Sheet>
        </div>
      </div>

      <main className="flex-1 md:pl-64 flex flex-col min-h-screen">
        <header className="hidden md:flex h-16 items-center justify-between px-8 border-b border-white/5 bg-background/50 backdrop-blur-md sticky top-0 z-30">
          <h1 className="text-lg font-medium font-heading">{title}</h1>
          <ModeToggle />
        </header>
        <div className="flex-1 p-4 md:p-8 max-w-6xl w-full mx-auto">{children}</div>
      </main>
    </div>
  );
}

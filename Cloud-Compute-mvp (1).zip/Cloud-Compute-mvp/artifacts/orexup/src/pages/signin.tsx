import { useState } from "react";
import { Link, useLocation } from "wouter";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import * as z from "zod";
import { Eye, EyeOff, Lock, Mail, ArrowRight, X, MailWarning, Loader2 } from "lucide-react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { Layout } from "@/components/layout";
import { AuthSteps } from "@/components/auth-steps";
import { useUserAuth } from "@/lib/user-auth";
import { useI18n } from "@/lib/i18n";

const BASE = import.meta.env.BASE_URL?.replace(/\/$/, "") ?? "";

const signInSchema = z.object({
  email: z.string().email({ message: "Invalid email address." }),
  password: z.string().min(1, { message: "Password is required." }),
});

export default function SignIn() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const { signin } = useUserAuth();
  const { t } = useI18n();
  const [showPassword, setShowPassword] = useState(false);
  const [forgotOpen, setForgotOpen] = useState(false);
  const [forgotEmail, setForgotEmail] = useState("");
  const [forgotSent, setForgotSent] = useState(false);
  const [forgotLoading, setForgotLoading] = useState(false);
  const [unverifiedEmail, setUnverifiedEmail] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const form = useForm<z.infer<typeof signInSchema>>({
    resolver: zodResolver(signInSchema),
    defaultValues: { email: "", password: "" },
  });

  async function onSubmit(values: z.infer<typeof signInSchema>) {
    setIsSubmitting(true);
    const result = await signin(values.email, values.password);
    setIsSubmitting(false);

    if (!result.ok) {
      if (result.code === "EMAIL_NOT_VERIFIED") {
        setUnverifiedEmail(values.email);
      } else {
        toast({ title: t.signIn.toastFailTitle, description: result.error, variant: "destructive" });
      }
      return;
    }

    toast({ title: t.signIn.toastSuccessTitle, description: t.signIn.toastSuccessDesc });
    setLocation("/plans");
  }

  async function handleForgotPassword() {
    if (!forgotEmail) return;
    setForgotLoading(true);
    try {
      await fetch(`${BASE}/api/auth/forgot-password`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: forgotEmail }),
      });
      setForgotSent(true);
    } finally {
      setForgotLoading(false);
    }
  }

  return (
    <Layout>
      <div className="min-h-[calc(100vh-16rem)] flex items-center justify-center p-4 relative">
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#80808012_1px,transparent_1px),linear-gradient(to_bottom,#80808012_1px,transparent_1px)] bg-[size:24px_24px] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_0%,#000_70%,transparent_100%)] pointer-events-none" />
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
          className="w-full max-w-md relative z-10"
        >
          <AuthSteps current={3} />

          <Card className="border-white/10 bg-card/80 backdrop-blur-xl shadow-2xl">
            <CardHeader className="space-y-1">
              <CardTitle className="text-2xl font-bold font-heading">{t.signIn.title}</CardTitle>
              <CardDescription>{t.signIn.desc}</CardDescription>
            </CardHeader>
            <CardContent>
              {unverifiedEmail && (
                <motion.div
                  initial={{ opacity: 0, y: -8 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="mb-5 flex items-center gap-3 rounded-lg border border-amber-500/30 bg-amber-500/10 px-4 py-3 text-sm"
                >
                  <MailWarning className="h-4 w-4 text-amber-400 shrink-0" />
                  <p className="flex-1 text-amber-400 font-medium">
                    {t.signIn.unverifiedMsg}{" "}
                    <Link href="/verify-email" className="underline">{t.signIn.resendLink}</Link>
                  </p>
                  <button
                    onClick={() => setUnverifiedEmail(null)}
                    className="text-muted-foreground hover:text-foreground shrink-0"
                  >
                    <X className="h-3.5 w-3.5" />
                  </button>
                </motion.div>
              )}

              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                  <FormField control={form.control} name="email" render={({ field }) => (
                    <FormItem>
                      <FormLabel>{t.signIn.emailLabel}</FormLabel>
                      <FormControl>
                        <div className="relative">
                          <Mail className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                          <Input placeholder="Email" className="pl-9" {...field} data-testid="input-signin-email" />
                        </div>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )} />

                  <FormField control={form.control} name="password" render={({ field }) => (
                    <FormItem>
                      <div className="flex items-center justify-between">
                        <FormLabel>{t.signIn.passwordLabel}</FormLabel>
                        <button
                          type="button"
                          className="text-xs text-primary hover:underline"
                          onClick={() => { setForgotOpen(true); setForgotSent(false); setForgotEmail(""); }}
                          data-testid="link-forgot-password"
                        >
                          {t.signIn.forgotBtn}
                        </button>
                      </div>
                      <FormControl>
                        <div className="relative">
                          <Lock className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                          <Input
                            type={showPassword ? "text" : "password"}
                            placeholder="••••••••"
                            className="pl-9 pr-10"
                            {...field}
                            data-testid="input-signin-password"
                          />
                          <button
                            type="button"
                            aria-label={showPassword ? "Hide password" : "Show password"}
                            onClick={() => setShowPassword(!showPassword)}
                            className="absolute right-3 top-3 text-muted-foreground hover:text-foreground transition-colors"
                            data-testid="button-toggle-password"
                          >
                            {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                          </button>
                        </div>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )} />

                  <Button type="submit" className="w-full h-11" disabled={isSubmitting} data-testid="button-submit-signin">
                    {isSubmitting ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null}
                    {isSubmitting ? t.signIn.submittingBtn : t.signIn.submitBtn}
                    {!isSubmitting && <ArrowRight className="ml-2 h-4 w-4" />}
                  </Button>
                </form>
              </Form>
            </CardContent>
            <CardFooter className="flex justify-center border-t border-white/5 pt-6">
              <p className="text-sm text-muted-foreground">
                {t.signIn.noAccount}{" "}
                <Link href="/signup" className="text-primary hover:underline font-medium" data-testid="link-to-signup">
                  {t.signIn.signUpLink}
                </Link>
              </p>
            </CardFooter>
          </Card>
        </motion.div>
      </div>

      <Dialog open={forgotOpen} onOpenChange={setForgotOpen}>
        <DialogContent className="bg-card border-white/10 sm:max-w-sm">
          <DialogHeader>
            <DialogTitle>{t.signIn.forgotTitle}</DialogTitle>
            <DialogDescription>{t.signIn.forgotDesc}</DialogDescription>
          </DialogHeader>
          {forgotSent ? (
            <div className="py-4 text-center space-y-2">
              <p className="text-sm font-medium text-green-400">{t.signIn.forgotSentTitle}</p>
              <p className="text-xs text-muted-foreground">
                {t.signIn.forgotSentDesc} <strong>{forgotEmail}</strong>, check your inbox.
              </p>
              <Button className="mt-4 w-full" onClick={() => setForgotOpen(false)}>{t.signIn.forgotDoneBtn}</Button>
            </div>
          ) : (
            <div className="space-y-4 py-2">
              <div className="relative">
                <Mail className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Email"
                  className="pl-9 bg-black/20"
                  value={forgotEmail}
                  onChange={(e) => setForgotEmail(e.target.value)}
                />
              </div>
              <Button className="w-full" disabled={!forgotEmail || forgotLoading} onClick={handleForgotPassword}>
                {forgotLoading ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null}
                {forgotLoading ? t.signIn.forgotSendingBtn : t.signIn.forgotSendBtn}
              </Button>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </Layout>
  );
}

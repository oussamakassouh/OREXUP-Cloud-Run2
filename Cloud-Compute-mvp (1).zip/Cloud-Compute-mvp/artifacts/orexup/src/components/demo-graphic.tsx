import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Monitor, Puzzle, Cloud, Activity, Cpu, Wifi } from "lucide-react";

const STAGES = [
  { id: 0, label: "Browser detects heavy workload", active: "browser" },
  { id: 1, label: "Extension intercepts & routes task", active: "ext" },
  { id: 2, label: "Cloud session spins up instantly", active: "cloud" },
  { id: 3, label: "Real-time metrics stream back", active: "metrics" },
];

function Packet({ delay, reverse }: { delay: number; reverse?: boolean }) {
  return (
    <motion.div
      className="absolute top-1/2 -translate-y-1/2 w-2 h-2 rounded-full bg-primary shadow-[0_0_6px_2px_hsl(var(--primary)/0.6)]"
      initial={{ left: reverse ? "100%" : "0%", opacity: 0 }}
      animate={{ left: reverse ? "0%" : "100%", opacity: [0, 1, 1, 0] }}
      transition={{
        duration: 1.4,
        delay,
        repeat: Infinity,
        repeatDelay: 1.2,
        ease: "easeInOut",
      }}
    />
  );
}

function MetricRow({ label, value, unit, color = "text-primary" }: { label: string; value: number; unit: string; color?: string }) {
  return (
    <div className="flex items-center justify-between text-[11px]">
      <span className="text-muted-foreground">{label}</span>
      <span className={`font-mono font-semibold ${color}`}>
        {value}
        <span className="text-muted-foreground font-normal ml-0.5">{unit}</span>
      </span>
    </div>
  );
}

export function DemoGraphic() {
  const [stage, setStage] = useState(0);
  const [metrics, setMetrics] = useState({ cpu: 12, latency: 8, fps: 60, ram: 340 });

  useEffect(() => {
    const stageTimer = setInterval(() => {
      setStage((s) => (s + 1) % STAGES.length);
    }, 2200);
    return () => clearInterval(stageTimer);
  }, []);

  useEffect(() => {
    const metricTimer = setInterval(() => {
      setMetrics({
        cpu: Math.floor(Math.random() * 18) + 6,
        latency: Math.floor(Math.random() * 10) + 4,
        fps: Math.floor(Math.random() * 4) + 58,
        ram: Math.floor(Math.random() * 80) + 300,
      });
    }, 900);
    return () => clearInterval(metricTimer);
  }, []);

  const active = STAGES[stage].active;

  return (
    <div className="relative w-full rounded-2xl border border-white/8 bg-[#0a0a0f] overflow-hidden select-none">
      {/* top bar */}
      <div className="flex items-center gap-1.5 px-4 py-3 border-b border-white/5 bg-white/[0.02]">
        <span className="w-3 h-3 rounded-full bg-red-500/70" />
        <span className="w-3 h-3 rounded-full bg-yellow-500/70" />
        <span className="w-3 h-3 rounded-full bg-green-500/70" />
        <span className="ml-3 text-[11px] text-muted-foreground font-mono">orexup — live session</span>
        <span className="ml-auto flex items-center gap-1.5 text-[10px] text-primary font-mono">
          <motion.span
            className="w-1.5 h-1.5 rounded-full bg-primary"
            animate={{ opacity: [1, 0.2, 1] }}
            transition={{ duration: 1.2, repeat: Infinity }}
          />
          CONNECTED
        </span>
      </div>

      <div className="p-6 md:p-10">
        {/* Stage label */}
        <div className="text-center mb-10 h-6">
          <AnimatePresence mode="wait">
            <motion.p
              key={stage}
              initial={{ opacity: 0, y: 6 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -6 }}
              transition={{ duration: 0.3 }}
              className="text-sm text-primary font-medium"
            >
              {STAGES[stage].label}
            </motion.p>
          </AnimatePresence>
        </div>

        {/* Main flow diagram */}
        <div className="flex items-center justify-between gap-0 mb-10">

          {/* Browser node */}
          <motion.div
            animate={{ scale: active === "browser" ? 1.06 : 1, borderColor: active === "browser" ? "hsl(var(--primary))" : "hsl(var(--border) / 0.2)" }}
            transition={{ duration: 0.4 }}
            className="flex flex-col items-center gap-3 rounded-xl border-2 p-4 md:p-5 bg-white/[0.03] w-24 md:w-32 shrink-0"
          >
            <motion.div
              animate={{ boxShadow: active === "browser" ? "0 0 24px 4px hsl(var(--primary)/0.35)" : "0 0 0px 0px transparent" }}
              className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center"
            >
              <Monitor className="h-5 w-5 text-primary" />
            </motion.div>
            <span className="text-[11px] font-medium text-center leading-tight">Your Browser</span>
            {active === "browser" && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="w-full space-y-1">
                <div className="h-1.5 rounded bg-primary/30 w-full overflow-hidden">
                  <motion.div className="h-full bg-primary rounded" animate={{ width: ["20%", "90%", "60%"] }} transition={{ duration: 2, repeat: Infinity }} />
                </div>
                <div className="h-1.5 rounded bg-white/10 w-3/4 overflow-hidden">
                  <motion.div className="h-full bg-white/30 rounded" animate={{ width: ["40%", "70%", "45%"] }} transition={{ duration: 1.6, repeat: Infinity }} />
                </div>
              </motion.div>
            )}
          </motion.div>

          {/* Connector 1 */}
          <div className="flex-1 relative h-px bg-white/10 mx-2">
            <Packet delay={0} />
            <Packet delay={0.7} />
          </div>

          {/* Extension node */}
          <motion.div
            animate={{ scale: active === "ext" ? 1.06 : 1, borderColor: active === "ext" ? "hsl(var(--primary))" : "hsl(var(--border) / 0.2)" }}
            transition={{ duration: 0.4 }}
            className="flex flex-col items-center gap-3 rounded-xl border-2 p-4 md:p-5 bg-white/[0.03] w-24 md:w-32 shrink-0"
          >
            <motion.div
              animate={{ boxShadow: active === "ext" ? "0 0 24px 4px hsl(var(--primary)/0.35)" : "0 0 0px 0px transparent" }}
              className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center"
            >
              <Puzzle className="h-5 w-5 text-primary" />
            </motion.div>
            <span className="text-[11px] font-medium text-center leading-tight">Extension</span>
            {active === "ext" && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex gap-1 justify-center">
                {[0, 0.15, 0.3].map((d) => (
                  <motion.span
                    key={d}
                    className="w-1.5 h-1.5 rounded-full bg-primary"
                    animate={{ opacity: [0.3, 1, 0.3] }}
                    transition={{ duration: 0.8, delay: d, repeat: Infinity }}
                  />
                ))}
              </motion.div>
            )}
          </motion.div>

          {/* Connector 2 */}
          <div className="flex-1 relative h-px bg-white/10 mx-2">
            <Packet delay={0.3} />
            <Packet delay={1.0} />
          </div>

          {/* Cloud node */}
          <motion.div
            animate={{ scale: active === "cloud" || active === "metrics" ? 1.06 : 1, borderColor: active === "cloud" || active === "metrics" ? "hsl(var(--primary))" : "hsl(var(--border) / 0.2)" }}
            transition={{ duration: 0.4 }}
            className="flex flex-col items-center gap-3 rounded-xl border-2 p-4 md:p-5 bg-white/[0.03] w-24 md:w-32 shrink-0"
          >
            <motion.div
              animate={{ boxShadow: active === "cloud" || active === "metrics" ? "0 0 24px 4px hsl(var(--primary)/0.35)" : "0 0 0px 0px transparent" }}
              className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center"
            >
              <Cloud className="h-5 w-5 text-primary" />
            </motion.div>
            <span className="text-[11px] font-medium text-center leading-tight">OREXUP Cloud</span>
            {(active === "cloud" || active === "metrics") && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="w-full">
                <div className="h-1.5 rounded bg-primary/20 w-full overflow-hidden">
                  <motion.div
                    className="h-full bg-primary/60 rounded"
                    animate={{ width: ["0%", "100%"] }}
                    transition={{ duration: 1.4, repeat: Infinity }}
                  />
                </div>
              </motion.div>
            )}
          </motion.div>

          {/* Return packets */}
          {active === "metrics" && (
            <>
              <div className="absolute left-[40%] right-[28%] top-1/2 hidden" />
            </>
          )}
        </div>

        {/* Metrics panel */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {[
            { Icon: Cpu, label: "Cloud CPU", value: metrics.cpu, unit: "%", color: "text-primary" },
            { Icon: Wifi, label: "Latency", value: metrics.latency, unit: "ms", color: "text-cyan-400" },
            { Icon: Activity, label: "Frame Rate", value: metrics.fps, unit: "fps", color: "text-green-400" },
            { Icon: Activity, label: "RAM Used", value: metrics.ram, unit: "MB", color: "text-violet-400" },
          ].map(({ Icon, label, value, unit, color }) => (
            <motion.div
              key={label}
              className="rounded-lg border border-white/5 bg-white/[0.02] p-3 flex flex-col gap-2"
            >
              <div className="flex items-center gap-1.5 text-[10px] text-muted-foreground">
                <Icon className="h-3 w-3" />
                {label}
              </div>
              <motion.p
                key={value}
                initial={{ opacity: 0.5, y: 2 }}
                animate={{ opacity: 1, y: 0 }}
                className={`font-mono text-lg font-bold ${color}`}
              >
                {value}
                <span className="text-xs text-muted-foreground font-normal ml-0.5">{unit}</span>
              </motion.p>
            </motion.div>
          ))}
        </div>

        {/* Stage progress dots */}
        <div className="flex justify-center gap-2 mt-8">
          {STAGES.map((s) => (
            <motion.div
              key={s.id}
              animate={{ width: stage === s.id ? 20 : 6, backgroundColor: stage === s.id ? "hsl(var(--primary))" : "hsl(var(--muted-foreground) / 0.3)" }}
              className="h-1.5 rounded-full"
              transition={{ duration: 0.3 }}
            />
          ))}
        </div>
      </div>
    </div>
  );
}

import { Layout } from "@/components/layout";
import { useGetPublicBlogPosts } from "@workspace/api-client-react";
import { Link } from "wouter";
import { Loader2, ArrowRight, AlertCircle } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

function fmtDate(iso: string | null) {
  if (!iso) return "";
  return new Date(iso).toLocaleDateString("en-US", { month: "long", day: "numeric", year: "numeric" });
}

export default function BlogPage() {
  const { data: posts = [], isLoading, isError } = useGetPublicBlogPosts();

  return (
    <Layout>
      <div className="container mx-auto px-4 py-16 max-w-4xl">
        <div className="mb-12">
          <h1 className="text-3xl md:text-4xl font-bold font-heading tracking-tight mb-3">Blog</h1>
          <p className="text-muted-foreground">Updates, insights, and news from the OREXUP team.</p>
        </div>

        {isLoading && (
          <div className="flex items-center justify-center py-24">
            <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
          </div>
        )}

        {isError && (
          <div className="flex flex-col items-center justify-center py-24 gap-3 text-muted-foreground">
            <AlertCircle className="h-6 w-6 text-destructive" />
            <p className="text-sm">Failed to load posts. Please try again later.</p>
          </div>
        )}

        {!isLoading && !isError && posts.length === 0 && (
          <div className="text-center py-24 text-muted-foreground">
            No posts published yet. Check back soon.
          </div>
        )}

        <div className="space-y-6">
          {posts.map((post) => (
            <Link key={post.id} href={`/blog/${post.id}`}>
              <Card className="border-white/5 bg-card/50 hover:bg-card/80 transition cursor-pointer group">
                <CardContent className="p-6">
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex-1 min-w-0">
                      <h2 className="text-lg font-semibold font-heading mb-2 group-hover:text-primary transition-colors">{post.title}</h2>
                      {post.excerpt && <p className="text-sm text-muted-foreground mb-3 line-clamp-2">{post.excerpt}</p>}
                      <div className="flex items-center gap-3 text-xs text-muted-foreground">
                        <span>{post.authorName}</span>
                        {post.publishedAt && <><span>·</span><span>{fmtDate(post.publishedAt)}</span></>}
                      </div>
                    </div>
                    <ArrowRight className="h-5 w-5 text-muted-foreground group-hover:text-primary transition-colors shrink-0 mt-1" />
                  </div>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      </div>
    </Layout>
  );
}

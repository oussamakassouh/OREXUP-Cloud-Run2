import { DashboardLayout } from "@/components/dashboard-layout";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Clock, Activity, Zap, TrendingUp, CloudOff } from "lucide-react";
import { useAppContext } from "@/lib/app-context";

export default function AnalyticsPage() {
  const { cloudConnected } = useAppContext();

  return (
    <DashboardLayout title="Analytics">
      <div className="space-y-8">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <h2 className="text-2xl font-bold font-heading">Performance Overview</h2>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <Card className="border-white/5 bg-card/50">
            <CardContent className="p-6">
              <div className="flex items-center justify-between space-y-0 pb-2">
                <p className="text-sm font-medium text-muted-foreground">Session Usage</p>
                <Clock className="h-4 w-4 text-muted-foreground" />
              </div>
              <div className="text-2xl font-bold font-heading">—</div>
              <p className="text-xs text-muted-foreground mt-1">Total cloud session time</p>
            </CardContent>
          </Card>

          <Card className="border-white/5 bg-card/50">
            <CardContent className="p-6">
              <div className="flex items-center justify-between space-y-0 pb-2">
                <p className="text-sm font-medium text-muted-foreground">Performance Score</p>
                <Zap className="h-4 w-4 text-muted-foreground" />
              </div>
              <div className="text-2xl font-bold font-heading">—</div>
              <p className="text-xs text-muted-foreground mt-1">Avg performance score</p>
            </CardContent>
          </Card>

          <Card className="border-white/5 bg-card/50">
            <CardContent className="p-6">
              <div className="flex items-center justify-between space-y-0 pb-2">
                <p className="text-sm font-medium text-muted-foreground">Cloud Activity</p>
                <Activity className="h-4 w-4 text-muted-foreground" />
              </div>
              <div className="text-2xl font-bold font-heading">—</div>
              <p className="text-xs text-muted-foreground mt-1">Cloud interactions logged</p>
            </CardContent>
          </Card>

          <Card className="border-white/5 bg-card/50">
            <CardContent className="p-6">
              <div className="flex items-center justify-between space-y-0 pb-2">
                <p className="text-sm font-medium text-muted-foreground">Usage Trends</p>
                <TrendingUp className="h-4 w-4 text-muted-foreground" />
              </div>
              <div className="text-2xl font-bold font-heading">—</div>
              <p className="text-xs text-muted-foreground mt-1">vs previous period</p>
            </CardContent>
          </Card>
        </div>

        <Card className="border-white/5 bg-card/50 pt-6">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Session Activity</CardTitle>
            <CardDescription>Frequency of cloud offloading over time</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-[300px] w-full flex flex-col items-center justify-center gap-3 text-center">
              <div className="p-4 rounded-full bg-white/5">
                <CloudOff className="h-8 w-8 text-muted-foreground" />
              </div>
              <p className="text-sm font-medium text-muted-foreground">
                {cloudConnected ? "No session data yet" : "Cloud not connected"}
              </p>
              <p className="text-xs text-muted-foreground/60 max-w-xs">
                {cloudConnected
                  ? "Start a cloud session to begin recording analytics."
                  : "Connect your cloud in Cloud Config to start tracking performance data."}
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}

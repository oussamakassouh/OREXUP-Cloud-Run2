import { Router, type IRouter, type Request, type Response } from "express";
import { eq, desc } from "drizzle-orm";
import { db, sessionsTable, cloudConnectionsTable } from "@workspace/db";
import { userAuth, type AuthRequest } from "../middlewares/userJwtAuth";
import { logger } from "../lib/logger";

const router: IRouter = Router();
router.use(userAuth);

function fmtDuration(seconds: number): string {
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = seconds % 60;
  if (h > 0) return `${h}h ${m}m ${s}s`;
  if (m > 0) return `${m}m ${s}s`;
  return `${s}s`;
}

// GET /analytics/browser — browser/extension connection usage stats
router.get("/analytics/browser", async (req: Request, res: Response): Promise<void> => {
  const { userEmail } = req as AuthRequest;
  try {
    const connections = await db
      .select()
      .from(cloudConnectionsTable)
      .where(eq(cloudConnectionsTable.userEmail, userEmail))
      .orderBy(desc(cloudConnectionsTable.connectedAt))
      .limit(50);

    const active = connections.filter((c) => c.status === "connected");
    const profileCounts: Record<string, number> = {};
    const regionCounts: Record<string, number> = {};
    for (const c of connections) {
      profileCounts[c.profile] = (profileCounts[c.profile] ?? 0) + 1;
      regionCounts[c.region] = (regionCounts[c.region] ?? 0) + 1;
    }

    res.json({
      browser: {
        totalConnections: connections.length,
        activeConnections: active.length,
        connectionsByProfile: Object.entries(profileCounts).map(([profile, count]) => ({ profile, count })),
        connectionsByRegion: Object.entries(regionCounts).map(([region, count]) => ({ region, count })),
        recent: connections.slice(0, 5).map((c) => ({
          id: c.id,
          profile: c.profile,
          region: c.region,
          status: c.status,
          connectedAt: c.connectedAt,
          lastSeenAt: c.lastSeenAt,
        })),
      },
    });
  } catch (err) {
    logger.error({ err }, "Analytics browser error");
    res.status(500).json({ error: "Failed to fetch browser analytics." });
  }
});

// GET /analytics/performance — performance metrics from sessions
router.get("/analytics/performance", async (req: Request, res: Response): Promise<void> => {
  const { userEmail } = req as AuthRequest;
  const days = Math.min(Number(req.query.days ?? 30), 365);
  const since = new Date(Date.now() - days * 86_400_000);

  try {
    const allSessions = await db
      .select()
      .from(sessionsTable)
      .where(eq(sessionsTable.userEmail, userEmail))
      .orderBy(desc(sessionsTable.startedAt));

    const sessions = allSessions.filter((s) => new Date(s.startedAt) >= since);
    const totalDur = sessions.reduce((acc, s) => acc + s.durationSeconds, 0);
    const avgDur = sessions.length > 0 ? Math.floor(totalDur / sessions.length) : 0;
    const peak = sessions.length > 0 ? Math.max(...sessions.map((s) => s.durationSeconds)) : 0;

    const byDay: Record<string, { count: number; totalSeconds: number }> = {};
    for (const s of sessions) {
      const day = new Date(s.startedAt).toISOString().slice(0, 10);
      if (!byDay[day]) byDay[day] = { count: 0, totalSeconds: 0 };
      byDay[day].count++;
      byDay[day].totalSeconds += s.durationSeconds;
    }

    res.json({
      performance: {
        periodDays: days,
        totalSessions: sessions.length,
        totalDurationSeconds: totalDur,
        totalDurationFormatted: fmtDuration(totalDur),
        avgDurationSeconds: avgDur,
        avgDurationFormatted: fmtDuration(avgDur),
        peakDurationSeconds: peak,
        peakDurationFormatted: fmtDuration(peak),
        byDay: Object.entries(byDay)
          .map(([date, v]) => ({ date, ...v }))
          .sort((a, b) => a.date.localeCompare(b.date)),
      },
    });
  } catch (err) {
    logger.error({ err }, "Analytics performance error");
    res.status(500).json({ error: "Failed to fetch performance analytics." });
  }
});

// GET /analytics/history — paginated session history
router.get("/analytics/history", async (req: Request, res: Response): Promise<void> => {
  const { userEmail } = req as AuthRequest;
  const limit = Math.min(Number(req.query.limit ?? 20), 100);
  const offset = Number(req.query.offset ?? 0);

  try {
    const sessions = await db
      .select()
      .from(sessionsTable)
      .where(eq(sessionsTable.userEmail, userEmail))
      .orderBy(desc(sessionsTable.startedAt))
      .limit(limit)
      .offset(offset);

    res.json({
      history: sessions.map((s) => ({
        id: s.id,
        profile: s.profile,
        status: s.status,
        location: s.location ?? null,
        durationSeconds: s.durationSeconds,
        durationFormatted: fmtDuration(s.durationSeconds),
        startedAt: s.startedAt,
        endedAt: s.endedAt ?? null,
      })),
      pagination: { limit, offset },
    });
  } catch (err) {
    logger.error({ err }, "Analytics history error");
    res.status(500).json({ error: "Failed to fetch history." });
  }
});

export default router;

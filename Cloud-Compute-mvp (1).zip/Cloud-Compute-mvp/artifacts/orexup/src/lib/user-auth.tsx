import { createContext, useContext, useState, useEffect, useCallback } from "react";

const BASE = import.meta.env.BASE_URL?.replace(/\/$/, "") ?? "";

interface UserInfo {
  id: number;
  email: string;
  name: string;
}

interface UserAuthState {
  isAuthenticated: boolean;
  isLoading: boolean;
  user: UserInfo | null;
  signup: (email: string, password: string, name?: string) => Promise<{ ok: boolean; error?: string }>;
  signin: (email: string, password: string) => Promise<{ ok: boolean; error?: string; code?: string }>;
  signout: () => Promise<void>;
  refreshUser: () => Promise<void>;
}

const UserAuthContext = createContext<UserAuthState | null>(null);

export function UserAuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<UserInfo | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  const refreshUser = useCallback(async () => {
    try {
      const res = await fetch(`${BASE}/api/auth/me`, { credentials: "include" });
      if (res.ok) {
        const data = await res.json() as { user: UserInfo };
        setUser(data.user);
      } else {
        setUser(null);
      }
    } catch {
      setUser(null);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    refreshUser();
  }, [refreshUser]);

  const signup = useCallback(async (email: string, password: string, name?: string) => {
    const res = await fetch(`${BASE}/api/auth/signup`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      credentials: "include",
      body: JSON.stringify({ email, password, name }),
    });
    const data = await res.json() as { message?: string; error?: string };
    if (!res.ok) return { ok: false, error: data.error ?? "Signup failed." };
    return { ok: true };
  }, []);

  const signin = useCallback(async (email: string, password: string) => {
    const res = await fetch(`${BASE}/api/auth/signin`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      credentials: "include",
      body: JSON.stringify({ email, password }),
    });
    const data = await res.json() as { user?: UserInfo; error?: string; code?: string };
    if (!res.ok) return { ok: false, error: data.error ?? "Sign in failed.", code: data.code };
    setUser(data.user ?? null);
    return { ok: true };
  }, []);

  const signout = useCallback(async () => {
    await fetch(`${BASE}/api/auth/signout`, { method: "POST", credentials: "include" });
    setUser(null);
  }, []);

  return (
    <UserAuthContext.Provider value={{
      isAuthenticated: !!user,
      isLoading,
      user,
      signup,
      signin,
      signout,
      refreshUser,
    }}>
      {children}
    </UserAuthContext.Provider>
  );
}

export function useUserAuth(): UserAuthState {
  const ctx = useContext(UserAuthContext);
  if (!ctx) throw new Error("useUserAuth must be used within UserAuthProvider");
  return ctx;
}

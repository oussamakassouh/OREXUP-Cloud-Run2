-- Migration 0001: API Modules
-- Adds TOTP 2FA support to user_accounts and ticket_messages table for support replies

ALTER TABLE user_accounts ADD COLUMN IF NOT EXISTS totp_secret TEXT;
ALTER TABLE user_accounts ADD COLUMN IF NOT EXISTS totp_enabled BOOLEAN NOT NULL DEFAULT FALSE;

CREATE TABLE IF NOT EXISTS ticket_messages (
  id SERIAL PRIMARY KEY,
  ticket_id INTEGER NOT NULL,
  user_email TEXT NOT NULL,
  message TEXT NOT NULL,
  is_staff BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS ticket_messages_ticket_id_idx ON ticket_messages(ticket_id);
CREATE INDEX IF NOT EXISTS ticket_messages_user_email_idx ON ticket_messages(user_email);

import { useState } from "react";
import { AdminLayout } from "@/components/admin-layout";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Users, UserCheck, PlayCircle, DollarSign,
  ShieldOff, CreditCard, Ticket, Handshake,
  UserPlus, BarChart2, TrendingUp, CalendarRange,
} from "lucide-react";
import { Link } from "wouter";
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { useGetAdminOverview } from "@workspace/api-client-react";

type Period = "today" | "week" | "month" | "year" | "custom";

const PERIODS: { value: Period; label: string }[] = [
  { value: "today",    label: "Today" },
  { value: "week",     label: "Week" },
  { value: "month",    label: "Month" },
  { value: "year",     label: "Year" },
  { value: "custom",   label: "Custom" },
];

const PERIOD_LABELS: Record<Exclude<Period, "custom">, string> = {
  today: "today",
  week:  "past 7 days",
  month: "past 30 days",
  year:  "past 12 months",
};

function today() {
  return new Date().toISOString().split("T")[0];
}
function daysAgo(n: number) {
  return new Date(Date.now() - n * 86_400_000).toISOString().split("T")[0];
}

function formatCents(cents: number) {
  return `$${(cents / 100).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

function relativeTime(iso: string) {
  const diff = Date.now() - new Date(iso).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return "just now";
  if (mins < 60) return `${mins}min ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  return `${Math.floor(hrs / 24)}d ago`;
}

const quickActions = [
  { label: "Manage Users",  icon: UserPlus,  href: "/administrator/users",     color: "text-cyan-500",   bg: "bg-cyan-500/10" },
  { label: "Block User",    icon: ShieldOff, href: "/administrator/security",  color: "text-red-500",    bg: "bg-red-500/10" },
  { label: "View Payments", icon: CreditCard,href: "/administrator/payments",  color: "text-green-500",  bg: "bg-green-500/10" },
  { label: "Open Tickets",  icon: Ticket,    href: "/administrator/support",   color: "text-blue-500",   bg: "bg-blue-500/10" },
  { label: "Our Team",      icon: Handshake, href: "/administrator/partners",  color: "text-purple-500", bg: "bg-purple-500/10" },
  { label: "Analytics",     icon: BarChart2, href: "/administrator/analytics", color: "text-amber-500",  bg: "bg-amber-500/10" },
];

export default function AdminOverviewPage() {
  const [period, setPeriod] = useState<Period>("month");
  const [customFrom, setCustomFrom] = useState(() => daysAgo(30));
  const [customTo,   setCustomTo]   = useState(() => today());
  const [appliedFrom, setAppliedFrom] = useState(customFrom);
  const [appliedTo,   setAppliedTo]   = useState(customTo);

  const queryParams =
    period === "custom"
      ? { period, from: appliedFrom, to: appliedTo }
      : { period };

  const { data, isLoading, isError } = useGetAdminOverview(queryParams);

  const metrics = [
    { title: "Total Users",     value: data ? data.totalUsers.toLocaleString()       : "0",     icon: Users },
    { title: "Active Sessions", value: data ? data.activeSessions.toLocaleString()   : "0",     icon: PlayCircle },
    { title: "New Signups",     value: data ? data.newSignups.toLocaleString()        : "0",     icon: UserCheck },
    { title: "Revenue",         value: data ? formatCents(data.monthlyRevenueCents)  : "$0.00", icon: DollarSign },
  ];

  const revenueTrend = (data?.revenueTrend ?? []).map((r) => ({
    month: r.month,
    revenue: r.revenueCents / 100,
    users: r.users,
  }));
  const recentActivity = data?.recentActivity ?? [];

  const periodLabel =
    period === "custom"
      ? `${appliedFrom} → ${appliedTo}`
      : PERIOD_LABELS[period as Exclude<Period, "custom">];

  const chartDescription =
    period === "today"    ? "Hourly revenue and signups for today" :
    period === "year"     ? "Monthly revenue and user growth over the past year" :
    period === "custom"   ? `Daily data from ${appliedFrom} to ${appliedTo}` :
    `Daily revenue and user growth — ${PERIOD_LABELS[period as Exclude<Period, "custom">]}`;

  return (
    <AdminLayout title="System Overview">
      <div className="space-y-6">
        {isError && (
          <Card className="border-red-500/20 bg-red-500/5">
            <CardContent className="py-4 text-sm text-red-400">Failed to load overview data.</CardContent>
          </Card>
        )}

        {/* Period filter bar */}
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-1 p-1 bg-white/5 border border-white/8 rounded-xl">
            {PERIODS.map((p) => (
              <button
                key={p.value}
                onClick={() => setPeriod(p.value)}
                className={`flex items-center gap-1.5 px-4 py-1.5 rounded-lg text-sm font-medium transition-all ${
                  period === p.value
                    ? "bg-primary text-primary-foreground shadow-sm"
                    : "text-muted-foreground hover:text-foreground hover:bg-white/5"
                }`}
                data-testid={`filter-period-${p.value}`}
              >
                {p.value === "custom" && <CalendarRange className="h-3.5 w-3.5" />}
                {p.label}
              </button>
            ))}
          </div>

          {/* Custom date pickers — shown only when Custom is active */}
          {period === "custom" && (
            <div className="flex items-center gap-2 flex-wrap">
              <div className="flex items-center gap-2 bg-white/5 border border-white/10 rounded-lg px-3 py-1.5">
                <span className="text-xs text-muted-foreground whitespace-nowrap">From</span>
                <input
                  type="date"
                  value={customFrom}
                  max={customTo}
                  onChange={(e) => setCustomFrom(e.target.value)}
                  className="bg-transparent text-sm text-foreground outline-none [color-scheme:dark] cursor-pointer"
                  data-testid="input-custom-from"
                />
              </div>
              <span className="text-muted-foreground text-xs">→</span>
              <div className="flex items-center gap-2 bg-white/5 border border-white/10 rounded-lg px-3 py-1.5">
                <span className="text-xs text-muted-foreground whitespace-nowrap">To</span>
                <input
                  type="date"
                  value={customTo}
                  min={customFrom}
                  max={today()}
                  onChange={(e) => setCustomTo(e.target.value)}
                  className="bg-transparent text-sm text-foreground outline-none [color-scheme:dark] cursor-pointer"
                  data-testid="input-custom-to"
                />
              </div>
              <button
                onClick={() => { setAppliedFrom(customFrom); setAppliedTo(customTo); }}
                className="px-4 py-1.5 bg-primary text-primary-foreground text-sm font-medium rounded-lg hover:bg-primary/90 transition-colors"
                data-testid="button-apply-custom"
              >
                Apply
              </button>
            </div>
          )}
        </div>

        {/* Metric cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {metrics.map((metric, i) => (
            <Card key={i} className="border-white/5 bg-card/50 shadow-sm">
              <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
                <CardTitle className="text-sm font-medium text-muted-foreground">{metric.title}</CardTitle>
                <metric.icon className="h-4 w-4 text-muted-foreground opacity-50" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold font-heading">{isLoading ? "—" : metric.value}</div>
                <p className="text-xs text-muted-foreground mt-1 truncate" title={periodLabel}>{periodLabel}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Revenue trend chart */}
        <Card className="border-white/5 bg-card/50">
          <CardHeader>
            <div className="flex items-center justify-between gap-4 flex-wrap">
              <div>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="h-4 w-4 text-primary" />
                  Revenue &amp; Growth Trend
                </CardTitle>
                <CardDescription className="mt-1">{chartDescription}</CardDescription>
              </div>
              <Badge variant="outline" className="text-xs text-primary border-primary/30 bg-primary/10">
                {PERIODS.find((p) => p.value === period)?.label}
              </Badge>
            </div>
          </CardHeader>
          <CardContent>
            {revenueTrend.length === 0 ? (
              <div className="h-[280px] flex items-center justify-center text-muted-foreground text-sm">
                {isLoading ? "Loading…" : "No data for this period"}
              </div>
            ) : (
              <ResponsiveContainer width="100%" height={280}>
                <AreaChart data={revenueTrend} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                  <defs>
                    <linearGradient id="revGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%"  stopColor="hsl(var(--primary))" stopOpacity={0.4} />
                      <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0} />
                    </linearGradient>
                    <linearGradient id="userGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%"  stopColor="#a855f7" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="#a855f7" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                  <XAxis dataKey="month" stroke="rgba(255,255,255,0.4)" fontSize={11} tickLine={false} axisLine={false} />
                  <YAxis stroke="rgba(255,255,255,0.4)" fontSize={11} tickLine={false} axisLine={false}
                    tickFormatter={(v) => `$${v >= 1000 ? `${(v / 1000).toFixed(0)}k` : v}`} />
                  <Tooltip
                    contentStyle={{ background: "#0a0f16", border: "1px solid rgba(255,255,255,0.1)", borderRadius: "8px", fontSize: "12px" }}
                    formatter={(value: number, name: string) =>
                      name === "revenue" ? [`$${value.toLocaleString()}`, "Revenue"] : [value.toLocaleString(), "Users"]
                    }
                  />
                  <Area type="monotone" dataKey="revenue" stroke="hsl(var(--primary))" strokeWidth={2} fill="url(#revGradient)" />
                  <Area type="monotone" dataKey="users"   stroke="#a855f7"             strokeWidth={2} fill="url(#userGradient)" />
                </AreaChart>
              </ResponsiveContainer>
            )}
          </CardContent>
        </Card>

        {/* Activity feed + quick actions */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <Card className="lg:col-span-2 border-white/5 bg-card/50">
            <CardHeader>
              <CardTitle>Recent Activity Feed</CardTitle>
              <CardDescription>Latest events — {periodLabel}</CardDescription>
            </CardHeader>
            <CardContent>
              {recentActivity.length === 0 ? (
                <div className="py-10 text-center text-muted-foreground text-sm">
                  {isLoading ? "Loading…" : `No events for this period`}
                </div>
              ) : (
                <div className="space-y-4">
                  {recentActivity.map((event) => (
                    <div key={`${event.type}-${event.id}`} className="flex items-start gap-4 pb-4 border-b border-white/5 last:border-0 last:pb-0">
                      <div className={`mt-1 h-2 w-2 rounded-full flex-shrink-0 ${
                        event.type === "payment" ? "bg-green-500 shadow-[0_0_8px_rgba(34,197,94,0.6)]" :
                        event.type === "ticket"  ? "bg-amber-500 shadow-[0_0_8px_rgba(245,158,11,0.6)]" :
                                                   "bg-blue-500  shadow-[0_0_8px_rgba(59,130,246,0.6)]"
                      }`} />
                      <div className="flex-1 space-y-1">
                        <p className="text-sm font-medium leading-none">{event.description}</p>
                        <p className="text-xs text-muted-foreground">{relativeTime(event.timestamp)}</p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          <Card className="border-white/5 bg-card/50">
            <CardHeader>
              <CardTitle>Quick Actions</CardTitle>
              <CardDescription>Frequently used tools</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-3">
                {quickActions.map((action, i) => (
                  <Link key={i} href={action.href}>
                    <div className="flex flex-col items-center justify-center p-4 rounded-xl border border-white/5 bg-black/20 hover:bg-white/5 transition-colors cursor-pointer gap-3 text-center h-full">
                      <div className={`p-3 rounded-full ${action.bg} ${action.color}`}>
                        <action.icon className="h-5 w-5" />
                      </div>
                      <span className="text-xs font-medium">{action.label}</span>
                    </div>
                  </Link>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </AdminLayout>
  );
}

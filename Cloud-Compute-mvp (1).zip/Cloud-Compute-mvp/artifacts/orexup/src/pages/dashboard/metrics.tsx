import { useEffect, useState, useCallback } from "react";
import { DashboardLayout } from "@/components/dashboard-layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Cpu, MemoryStick, MonitorCog, Monitor, Wifi, HardDrive,
  BatteryCharging, Globe, Gauge, RefreshCw, Activity, Clock,
  Layers, GitBranch,
} from "lucide-react";
import { cloudApi } from "@/lib/cloud-api";
import { useAppContext } from "@/lib/app-context";
import type { MetricsResponse, SessionInfo } from "@/lib/cloud-api";

const UNAVAILABLE = "Unavailable";

interface NavigatorConnection { effectiveType?: string; downlink?: number; rtt?: number; saveData?: boolean; }
interface PerformanceMemory { usedJSHeapSize: number; totalJSHeapSize: number; jsHeapSizeLimit: number; }
interface BatteryManager { level: number; charging: boolean; }

interface BrowserMetrics {
  // CPU
  cpuCores: string;
  cpuThreads: string;
  cpuArch: string;

  // GPU
  gpuVendor: string;
  gpuRenderer: string;
  gpuVram: string;
  gpuMaxTexture: string;

  // RAM
  deviceMemory: string;
  heapUsed: string;
  heapTotal: string;
  heapLimit: string;
  heapPercent: number | null;

  // Process & Thread
  processCount: string;
  threadCount: string;
  workerThreads: string;
  serviceWorkers: string;

  // Display
  screen: string; viewport: string; colorDepth: string; pixelRatio: string;

  // Network
  connType: string; downlink: string; rtt: string; saveData: string; online: string;

  // Storage
  storageUsage: string; storageQuota: string; storagePercent: number | null;

  // Battery
  batteryLevel: string; batteryCharging: string; batteryPercent: number | null;

  // Misc
  platform: string; userAgent: string; language: string; cookies: string; timezone: string;
  loadTime: string; domContentLoaded: string;
}

function fmtBytes(bytes: number): string {
  if (!Number.isFinite(bytes) || bytes <= 0) return "0 MB";
  const gb = bytes / 1024 ** 3;
  return gb >= 1 ? `${gb.toFixed(2)} GB` : `${(bytes / 1024 ** 2).toFixed(0)} MB`;
}

function parseArch(ua: string): string {
  if (/arm64|aarch64/i.test(ua)) return "ARM64";
  if (/arm/i.test(ua)) return "ARM";
  if (/x86_64|x64|wow64|win64/i.test(ua)) return "x86-64";
  if (/x86|i[3-6]86/i.test(ua)) return "x86";
  return UNAVAILABLE;
}

function getWebGLInfo(): { vendor: string; renderer: string; vram: string; maxTexture: string } {
  try {
    const canvas = document.createElement("canvas");
    const gl = (canvas.getContext("webgl") || canvas.getContext("experimental-webgl")) as WebGLRenderingContext | null;
    if (!gl) return { vendor: UNAVAILABLE, renderer: UNAVAILABLE, vram: UNAVAILABLE, maxTexture: UNAVAILABLE };

    const dbg = gl.getExtension("WEBGL_debug_renderer_info");
    const vendor   = dbg ? (gl.getParameter(dbg.UNMASKED_VENDOR_WEBGL)   as string) || UNAVAILABLE : UNAVAILABLE;
    const renderer = dbg ? (gl.getParameter(dbg.UNMASKED_RENDERER_WEBGL) as string) || UNAVAILABLE : UNAVAILABLE;

    // VRAM estimation — try the WEBGL_multi_draw or deduce from maxTextureSize
    const maxTexSize = gl.getParameter(gl.MAX_TEXTURE_SIZE) as number;
    const maxTexLabel = maxTexSize ? `${maxTexSize} px` : UNAVAILABLE;

    // Rough VRAM mapping from max texture size (industry heuristic)
    let vram = UNAVAILABLE;
    if (maxTexSize >= 32768)      vram = "≥ 8 GB (est.)";
    else if (maxTexSize >= 16384) vram = "≥ 2 GB (est.)";
    else if (maxTexSize >= 8192)  vram = "≥ 512 MB (est.)";
    else if (maxTexSize >= 4096)  vram = "≥ 256 MB (est.)";
    else if (maxTexSize > 0)      vram = "< 256 MB (est.)";

    // Try to extract VRAM from renderer string (e.g. "GeForce RTX 3080 10GB")
    const vramMatch = renderer.match(/(\d+)\s*GB/i);
    if (vramMatch) vram = `${vramMatch[1]} GB`;

    // Try WEBGL_debug_shaders or NV_* for more precise info (rarely available)
    canvas.remove?.();
    return { vendor, renderer, vram, maxTexture: maxTexLabel };
  } catch {
    return { vendor: UNAVAILABLE, renderer: UNAVAILABLE, vram: UNAVAILABLE, maxTexture: UNAVAILABLE };
  }
}

function collectSync(): BrowserMetrics {
  const nav = navigator as Navigator & {
    deviceMemory?: number;
    connection?: NavigatorConnection;
  };
  const perf = performance as Performance & { memory?: PerformanceMemory };
  const gpu = getWebGLInfo();

  const cores = typeof nav.hardwareConcurrency === "number" ? nav.hardwareConcurrency : null;
  const cpuCores   = cores !== null ? `${cores} logical cores` : UNAVAILABLE;
  const cpuThreads = cores !== null ? `${cores} threads` : UNAVAILABLE;
  const cpuArch    = parseArch(nav.userAgent || "");

  const deviceMemory = typeof nav.deviceMemory === "number" ? `${nav.deviceMemory} GB` : UNAVAILABLE;

  let heapUsed = UNAVAILABLE, heapTotal = UNAVAILABLE, heapLimit = UNAVAILABLE, heapPercent: number | null = null;
  if (perf.memory && typeof perf.memory.usedJSHeapSize === "number") {
    heapUsed  = fmtBytes(perf.memory.usedJSHeapSize);
    heapTotal = fmtBytes(perf.memory.totalJSHeapSize);
    heapLimit = fmtBytes(perf.memory.jsHeapSizeLimit);
    heapPercent = perf.memory.jsHeapSizeLimit > 0
      ? Math.round((perf.memory.usedJSHeapSize / perf.memory.jsHeapSizeLimit) * 100) : null;
  }

  const conn = nav.connection;
  const connType = conn?.effectiveType ? conn.effectiveType.toUpperCase() : UNAVAILABLE;
  const downlink  = typeof conn?.downlink === "number" ? `${conn.downlink} Mbps` : UNAVAILABLE;
  const rtt       = typeof conn?.rtt      === "number" ? `${conn.rtt} ms`       : UNAVAILABLE;
  const saveData  = typeof conn?.saveData === "boolean" ? (conn.saveData ? "On" : "Off") : UNAVAILABLE;
  const online    = typeof nav.onLine === "boolean" ? (nav.onLine ? "Online" : "Offline") : UNAVAILABLE;

  const screenRes  = typeof screen?.width === "number" ? `${screen.width} × ${screen.height}` : UNAVAILABLE;
  const viewport   = typeof window.innerWidth === "number" ? `${window.innerWidth} × ${window.innerHeight}` : UNAVAILABLE;
  const colorDepth = typeof screen?.colorDepth === "number" ? `${screen.colorDepth}-bit` : UNAVAILABLE;
  const pixelRatio = typeof window.devicePixelRatio === "number" ? `${window.devicePixelRatio}×` : UNAVAILABLE;

  const platform   = nav.platform || UNAVAILABLE;
  const userAgent  = nav.userAgent || UNAVAILABLE;
  const language   = nav.language || UNAVAILABLE;
  const cookies    = typeof nav.cookieEnabled === "boolean" ? (nav.cookieEnabled ? "Enabled" : "Disabled") : UNAVAILABLE;
  let timezone = UNAVAILABLE;
  try { timezone = Intl.DateTimeFormat().resolvedOptions().timeZone || UNAVAILABLE; } catch {}

  let loadTime = UNAVAILABLE, domContentLoaded = UNAVAILABLE;
  try {
    const entry = performance.getEntriesByType("navigation")[0] as PerformanceNavigationTiming | undefined;
    if (entry) {
      if (entry.loadEventEnd > 0) loadTime = `${(entry.loadEventEnd - entry.startTime).toFixed(0)} ms`;
      if (entry.domContentLoadedEventEnd > 0) domContentLoaded = `${(entry.domContentLoadedEventEnd - entry.startTime).toFixed(0)} ms`;
    }
  } catch {}

  // Process & Thread info from browser context
  const threadCount    = cores !== null ? `${cores}` : UNAVAILABLE;
  const workerThreads  = typeof window.Worker !== "undefined" ? "Supported" : "Unavailable";
  const processCount   = "1 (renderer process)";

  return {
    cpuCores, cpuThreads, cpuArch,
    gpuVendor: gpu.vendor, gpuRenderer: gpu.renderer, gpuVram: gpu.vram, gpuMaxTexture: gpu.maxTexture,
    deviceMemory, heapUsed, heapTotal, heapLimit, heapPercent,
    processCount, threadCount, workerThreads, serviceWorkers: UNAVAILABLE,
    screen: screenRes, viewport, colorDepth, pixelRatio,
    connType, downlink, rtt, saveData, online,
    storageUsage: UNAVAILABLE, storageQuota: UNAVAILABLE, storagePercent: null,
    batteryLevel: UNAVAILABLE, batteryCharging: UNAVAILABLE, batteryPercent: null,
    platform, userAgent, language, cookies, timezone, loadTime, domContentLoaded,
  };
}

function Row({ label, value }: { label: string; value: string }) {
  const unavailable = value === UNAVAILABLE;
  return (
    <div className="flex items-start justify-between gap-4 py-1.5">
      <span className="text-sm text-muted-foreground shrink-0">{label}</span>
      <span className={`text-sm text-right font-medium break-all ${unavailable ? "text-muted-foreground/60 italic" : ""}`}>{value}</span>
    </div>
  );
}

function MetricCard({ icon: Icon, title, children, accent }: {
  icon: React.ComponentType<{ className?: string }>;
  title: string;
  children: React.ReactNode;
  accent?: string;
}) {
  return (
    <Card className="border-white/5 bg-card/50">
      <CardContent className="p-6">
        <div className="flex items-center gap-2 mb-3">
          <Icon className={`h-4 w-4 ${accent ?? "text-primary"}`} />
          <div className="text-sm font-semibold">{title}</div>
        </div>
        <div className="divide-y divide-white/5">{children}</div>
      </CardContent>
    </Card>
  );
}

function fmtDur(s: number) {
  const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), sec = s % 60;
  if (h > 0) return `${h}h ${m}m`;
  if (m > 0) return `${m}m ${sec}s`;
  return `${sec}s`;
}

function SessionRow({ s }: { s: SessionInfo }) {
  return (
    <div className="flex items-center justify-between py-2.5 gap-4">
      <div className="flex items-center gap-3 min-w-0">
        <Badge variant="outline" className={`text-xs shrink-0 ${s.status === "active"
          ? "bg-green-500/10 text-green-400 border-green-500/20" : "bg-white/5 text-muted-foreground border-white/10"}`}>
          {s.status}
        </Badge>
        <span className="text-sm capitalize truncate">{s.profile}</span>
      </div>
      <div className="text-xs text-muted-foreground shrink-0 flex items-center gap-1.5">
        <Clock className="h-3 w-3" />{fmtDur(s.durationSeconds)}
      </div>
    </div>
  );
}

export default function MetricsPage() {
  const { cloudConnected } = useAppContext();
  const [m, setM] = useState<BrowserMetrics>(() => collectSync());
  const [serverMetrics, setServerMetrics] = useState<MetricsResponse | null>(null);
  const [metricsError, setMetricsError] = useState<string | null>(null);
  const [updatedAt, setUpdatedAt] = useState<Date>(() => new Date());

  const fetchServerMetrics = useCallback(async () => {
    if (!cloudConnected || !cloudApi.getToken()) return;
    try {
      const data = await cloudApi.metrics();
      setServerMetrics(data);
      setMetricsError(null);
    } catch (e) {
      setMetricsError((e as Error).message);
    }
  }, [cloudConnected]);

  const refresh = useCallback(() => {
    const base = collectSync();
    setM(base);
    setUpdatedAt(new Date());
    fetchServerMetrics();

    const nav = navigator as Navigator & {
      storage?: { estimate?: () => Promise<{ usage?: number; quota?: number }> };
      getBattery?: () => Promise<BatteryManager>;
      serviceWorker?: { getRegistrations?: () => Promise<ServiceWorkerRegistration[]> };
    };

    // Storage estimate
    if (nav.storage?.estimate) {
      nav.storage.estimate().then((est) => {
        setM((prev) => ({
          ...prev,
          storageUsage: typeof est.usage === "number" ? fmtBytes(est.usage) : UNAVAILABLE,
          storageQuota: typeof est.quota === "number" ? fmtBytes(est.quota) : UNAVAILABLE,
          storagePercent: typeof est.usage === "number" && typeof est.quota === "number" && est.quota > 0
            ? Math.round((est.usage / est.quota) * 100) : null,
        }));
      }).catch(() => undefined);
    }

    // Battery
    if (nav.getBattery) {
      nav.getBattery().then((bat) => {
        setM((prev) => ({
          ...prev,
          batteryLevel: typeof bat.level === "number" ? `${Math.round(bat.level * 100)}%` : UNAVAILABLE,
          batteryCharging: typeof bat.charging === "boolean" ? (bat.charging ? "Charging" : "Not charging") : UNAVAILABLE,
          batteryPercent: typeof bat.level === "number" ? Math.round(bat.level * 100) : null,
        }));
      }).catch(() => undefined);
    }

    // Service workers count
    if (nav.serviceWorker?.getRegistrations) {
      nav.serviceWorker.getRegistrations().then((regs) => {
        setM((prev) => ({
          ...prev,
          serviceWorkers: `${regs.length} registered`,
        }));
      }).catch(() => undefined);
    }

    // WebGPU VRAM detection (async, Chrome 113+)
    type GPUAdapterLike = { limits?: Record<string, number> };
    const gpu = (navigator as Navigator & { gpu?: { requestAdapter?: () => Promise<GPUAdapterLike | null> } }).gpu;
    if (gpu?.requestAdapter) {
      gpu.requestAdapter().then(async (adapter) => {
        if (!adapter) return;
        const maxBufSize = adapter.limits?.maxBufferSize;
        if (typeof maxBufSize === "number" && maxBufSize > 0) {
          setM((prev) => ({
            ...prev,
            gpuVram: fmtBytes(maxBufSize) + " (est.)",
          }));
        }
      }).catch(() => undefined);
    }
  }, [fetchServerMetrics]);

  useEffect(() => {
    refresh();
    const id = window.setInterval(refresh, 5000);
    return () => window.clearInterval(id);
  }, [refresh]);

  return (
    <DashboardLayout title="Metrics">
      <div className="space-y-6">
        <div className="flex items-center justify-between flex-wrap gap-3">
          <div>
            <h3 className="text-xl font-bold font-heading">Metrics</h3>
            <p className="text-sm text-muted-foreground">Live browser readings + cloud session data from the API.</p>
          </div>
          <div className="flex items-center gap-3">
            <span className="text-xs text-muted-foreground">Updated {updatedAt.toLocaleTimeString()}</span>
            <Button variant="outline" size="sm" onClick={refresh}><RefreshCw className="mr-2 h-4 w-4" />Refresh</Button>
          </div>
        </div>

        {/* ── Cloud session metrics ─────────────────────────────────────── */}
        {cloudConnected && (
          <div>
            <h4 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-3 flex items-center gap-2">
              <Activity className="h-4 w-4 text-primary" />Cloud Session Metrics
            </h4>
            {metricsError ? (
              <Card className="border-red-500/20 bg-red-500/5">
                <CardContent className="p-4 text-sm text-red-400">{metricsError}</CardContent>
              </Card>
            ) : serverMetrics ? (
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                {[
                  { label: "Total Sessions",  value: serverMetrics.totalSessions },
                  { label: "Active Sessions", value: serverMetrics.activeSessions, green: serverMetrics.activeSessions > 0 },
                  { label: "Total Duration",  value: fmtDur(serverMetrics.totalDurationSeconds) },
                  { label: "Avg Duration",    value: fmtDur(serverMetrics.avgDurationSeconds) },
                ].map(({ label, value, green }) => (
                  <Card key={label} className="border-white/5 bg-card/50">
                    <CardContent className="p-5">
                      <div className="text-xs text-muted-foreground mb-1">{label}</div>
                      <div className={`text-2xl font-bold ${green ? "text-green-400" : ""}`}>{value}</div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <Card className="border-white/5 bg-card/50 mb-4">
                <CardContent className="p-4 text-sm text-muted-foreground">Loading cloud metrics…</CardContent>
              </Card>
            )}

            {serverMetrics && serverMetrics.sessionsByProfile.length > 0 && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                <Card className="border-white/5 bg-card/50">
                  <CardHeader className="pb-2"><CardTitle className="text-sm">Sessions by Profile</CardTitle></CardHeader>
                  <CardContent className="pt-0">
                    {serverMetrics.sessionsByProfile.map((p) => (
                      <div key={p.profile} className="mb-3">
                        <div className="flex justify-between text-sm mb-1">
                          <span className="capitalize">{p.profile}</span>
                          <span className="text-muted-foreground">{p.count}</span>
                        </div>
                        <div className="h-2 bg-white/5 rounded-full overflow-hidden">
                          <div className="h-full bg-primary rounded-full transition-all"
                            style={{ width: `${Math.min(100, (p.count / serverMetrics.totalSessions) * 100)}%` }} />
                        </div>
                      </div>
                    ))}
                  </CardContent>
                </Card>
                <Card className="border-white/5 bg-card/50">
                  <CardHeader className="pb-2"><CardTitle className="text-sm">Recent Sessions</CardTitle></CardHeader>
                  <CardContent className="pt-0 divide-y divide-white/5">
                    {serverMetrics.recentSessions.length === 0
                      ? <p className="text-sm text-muted-foreground py-2">No sessions yet.</p>
                      : serverMetrics.recentSessions.map((s) => <SessionRow key={s.sessionId} s={s} />)}
                  </CardContent>
                </Card>
              </div>
            )}
          </div>
        )}

        {/* ── Hardware overview row ─────────────────────────────────────── */}
        <div>
          <h4 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-3">Hardware</h4>
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4 mb-4">

            {/* CPU */}
            <Card className="border-white/5 bg-card/50">
              <CardContent className="p-6">
                <div className="flex items-center gap-2 mb-4">
                  <Cpu className="h-4 w-4 text-primary" />
                  <div className="text-sm font-semibold">CPU</div>
                </div>
                <div className="space-y-3">
                  <div>
                    <div className="text-xs text-muted-foreground mb-1">Logical Cores</div>
                    <div className="text-2xl font-bold">
                      {m.cpuCores === UNAVAILABLE ? "—" : m.cpuCores.replace(" logical cores", "")}
                    </div>
                  </div>
                  <div className="divide-y divide-white/5">
                    <Row label="Threads" value={m.cpuThreads} />
                    <Row label="Architecture" value={m.cpuArch} />
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* GPU */}
            <Card className="border-white/5 bg-card/50">
              <CardContent className="p-6">
                <div className="flex items-center gap-2 mb-4">
                  <MonitorCog className="h-4 w-4 text-primary" />
                  <div className="text-sm font-semibold">GPU</div>
                </div>
                <div className="space-y-3">
                  <div>
                    <div className="text-xs text-muted-foreground mb-1">VRAM</div>
                    <div className={`text-2xl font-bold ${m.gpuVram === UNAVAILABLE ? "text-muted-foreground/40 text-lg" : ""}`}>
                      {m.gpuVram === UNAVAILABLE ? "—" : m.gpuVram}
                    </div>
                  </div>
                  <div className="divide-y divide-white/5">
                    <Row label="Vendor"       value={m.gpuVendor} />
                    <Row label="Renderer"     value={m.gpuRenderer} />
                    <Row label="Max texture"  value={m.gpuMaxTexture} />
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* RAM */}
            <Card className="border-white/5 bg-card/50">
              <CardContent className="p-6">
                <div className="flex items-center gap-2 mb-4">
                  <MemoryStick className="h-4 w-4 text-primary" />
                  <div className="text-sm font-semibold">RAM</div>
                </div>
                <div className="space-y-3">
                  <div>
                    <div className="text-xs text-muted-foreground mb-1">Device Memory</div>
                    <div className={`text-2xl font-bold ${m.deviceMemory === UNAVAILABLE ? "text-muted-foreground/40 text-lg" : ""}`}>
                      {m.deviceMemory === UNAVAILABLE ? "—" : m.deviceMemory}
                    </div>
                  </div>
                  <div className="divide-y divide-white/5">
                    <Row label="JS heap used"  value={m.heapUsed} />
                    <Row label="JS heap total" value={m.heapTotal} />
                    <Row label="JS heap limit" value={m.heapLimit} />
                  </div>
                  {m.heapPercent !== null && (
                    <div className="pt-1">
                      <Progress value={m.heapPercent} className="h-1.5" />
                      <div className="text-xs text-muted-foreground mt-1">{m.heapPercent}% of heap limit in use</div>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Process & Thread */}
            <Card className="border-white/5 bg-card/50">
              <CardContent className="p-6">
                <div className="flex items-center gap-2 mb-4">
                  <GitBranch className="h-4 w-4 text-primary" />
                  <div className="text-sm font-semibold">Process & Thread</div>
                </div>
                <div className="space-y-3">
                  <div>
                    <div className="text-xs text-muted-foreground mb-1">CPU Threads</div>
                    <div className={`text-2xl font-bold ${m.threadCount === UNAVAILABLE ? "text-muted-foreground/40 text-lg" : ""}`}>
                      {m.threadCount === UNAVAILABLE ? "—" : m.threadCount}
                    </div>
                  </div>
                  <div className="divide-y divide-white/5">
                    <Row label="Process"         value={m.processCount} />
                    <Row label="Worker threads"  value={m.workerThreads} />
                    <Row label="Service workers" value={m.serviceWorkers} />
                  </div>
                </div>
              </CardContent>
            </Card>

          </div>
        </div>

        {/* ── Browser metrics ───────────────────────────────────────────── */}
        <div>
          <h4 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-3">Browser Metrics</h4>
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
            <MetricCard icon={Monitor} title="Display">
              <Row label="Screen resolution" value={m.screen} />
              <Row label="Viewport" value={m.viewport} />
              <Row label="Color depth" value={m.colorDepth} />
              <Row label="Pixel ratio" value={m.pixelRatio} />
            </MetricCard>
            <MetricCard icon={Wifi} title="Network">
              <Row label="Status" value={m.online} />
              <Row label="Effective type" value={m.connType} />
              <Row label="Downlink" value={m.downlink} />
              <Row label="Round-trip time" value={m.rtt} />
              <Row label="Data saver" value={m.saveData} />
            </MetricCard>
            <MetricCard icon={HardDrive} title="Storage">
              <Row label="Used" value={m.storageUsage} />
              <Row label="Quota" value={m.storageQuota} />
              {m.storagePercent !== null && (
                <div className="pt-2">
                  <Progress value={m.storagePercent} className="h-2" />
                  <div className="text-xs text-muted-foreground mt-1">{m.storagePercent}% of quota used</div>
                </div>
              )}
            </MetricCard>
            <MetricCard icon={BatteryCharging} title="Battery">
              <Row label="Level" value={m.batteryLevel} />
              <Row label="State" value={m.batteryCharging} />
              {m.batteryPercent !== null && <div className="pt-2"><Progress value={m.batteryPercent} className="h-2" /></div>}
            </MetricCard>
            <MetricCard icon={Gauge} title="Performance">
              <Row label="Page load time" value={m.loadTime} />
              <Row label="DOM content loaded" value={m.domContentLoaded} />
            </MetricCard>
            <MetricCard icon={Globe} title="Browser & System">
              <Row label="Platform" value={m.platform} />
              <Row label="Language" value={m.language} />
              <Row label="Cookies" value={m.cookies} />
              <Row label="Time zone" value={m.timezone} />
            </MetricCard>
          </div>
          <Card className="border-white/5 bg-card/50 mt-4">
            <CardContent className="p-6">
              <div className="flex items-center gap-2 mb-3">
                <Layers className="h-4 w-4 text-primary" />
                <div className="text-sm font-semibold">User Agent</div>
              </div>
              <p className={`text-sm font-mono break-all ${m.userAgent === UNAVAILABLE ? "text-muted-foreground/60 italic" : "text-muted-foreground"}`}>{m.userAgent}</p>
            </CardContent>
          </Card>
        </div>

      </div>
    </DashboardLayout>
  );
}

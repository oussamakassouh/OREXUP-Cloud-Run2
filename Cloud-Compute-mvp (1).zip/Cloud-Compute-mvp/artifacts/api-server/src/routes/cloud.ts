import { Router, type IRouter, type Request, type Response } from "express";
import { randomUUID } from "crypto";
import { eq, desc, count, sum, sql } from "drizzle-orm";
import { db, cloudConnectionsTable, sessionsTable } from "@workspace/db";

const router: IRouter = Router();

// ── Auth middleware ───────────────────────────────────────────────────────────

async function requireToken(req: Request, res: Response): Promise<typeof cloudConnectionsTable.$inferSelect | null> {
  const auth = req.headers.authorization ?? "";
  const token = auth.startsWith("Bearer ") ? auth.slice(7).trim() : "";
  if (!token) {
    res.status(401).json({ error: "Missing Bearer token. Call POST /api/connect first." });
    return null;
  }
  const [conn] = await db
    .select()
    .from(cloudConnectionsTable)
    .where(eq(cloudConnectionsTable.token, token))
    .limit(1);
  if (!conn) {
    res.status(401).json({ error: "Invalid or expired token." });
    return null;
  }
  // Heartbeat
  await db
    .update(cloudConnectionsTable)
    .set({ lastSeenAt: new Date() })
    .where(eq(cloudConnectionsTable.id, conn.id));
  return conn;
}

// ── POST /api/connect ─────────────────────────────────────────────────────────

router.post("/connect", async (req, res): Promise<void> => {
  const { email, profile } = req.body as { email?: string; profile?: string };
  if (!email || typeof email !== "string" || !email.includes("@")) {
    res.status(400).json({ error: "Valid email required." });
    return;
  }
  const validProfiles = ["balanced", "cpu", "gpu", "memory"];
  const safeProfile = validProfiles.includes(profile ?? "") ? profile! : "balanced";

  const region = "us-east-1";
  const token = randomUUID();

  // If this email already has an active connection, mark it disconnected
  await db
    .update(cloudConnectionsTable)
    .set({ status: "disconnected", disconnectedAt: new Date() })
    .where(eq(cloudConnectionsTable.userEmail, email));

  const [conn] = await db
    .insert(cloudConnectionsTable)
    .values({ token, userEmail: email, profile: safeProfile, region, status: "connected" })
    .returning();

  res.json({
    token: conn.token,
    connectionId: conn.id,
    region: conn.region,
    profile: conn.profile,
    connectedAt: conn.connectedAt,
  });
});

// ── POST /api/session/start ───────────────────────────────────────────────────

router.post("/session/start", async (req, res): Promise<void> => {
  const conn = await requireToken(req, res);
  if (!conn) return;

  if (conn.status !== "connected") {
    res.status(409).json({ error: "Connection is not active. Reconnect first." });
    return;
  }

  // Stop any existing active session for this connection
  if (conn.activeSessionId) {
    const now = new Date();
    const [existing] = await db
      .select()
      .from(sessionsTable)
      .where(eq(sessionsTable.id, conn.activeSessionId))
      .limit(1);
    if (existing && existing.status === "active") {
      const dur = Math.floor((now.getTime() - new Date(existing.startedAt).getTime()) / 1000);
      await db
        .update(sessionsTable)
        .set({ status: "stopped", endedAt: now, durationSeconds: dur })
        .where(eq(sessionsTable.id, existing.id));
    }
  }

  const { profile } = req.body as { profile?: string };
  const validProfiles = ["balanced", "cpu", "gpu", "memory"];
  const safeProfile = validProfiles.includes(profile ?? "") ? profile! : conn.profile;

  const [session] = await db
    .insert(sessionsTable)
    .values({
      userEmail: conn.userEmail,
      location: conn.region,
      profile: safeProfile,
      status: "active",
      durationSeconds: 0,
    })
    .returning();

  await db
    .update(cloudConnectionsTable)
    .set({ activeSessionId: session.id, profile: safeProfile })
    .where(eq(cloudConnectionsTable.id, conn.id));

  res.json({
    sessionId: session.id,
    profile: session.profile,
    status: session.status,
    startedAt: session.startedAt,
    endedAt: session.endedAt ?? null,
    durationSeconds: session.durationSeconds,
  });
});

// ── POST /api/session/stop ────────────────────────────────────────────────────

router.post("/session/stop", async (req, res): Promise<void> => {
  const conn = await requireToken(req, res);
  if (!conn) return;

  if (!conn.activeSessionId) {
    res.status(409).json({ error: "No active session to stop." });
    return;
  }

  const [session] = await db
    .select()
    .from(sessionsTable)
    .where(eq(sessionsTable.id, conn.activeSessionId))
    .limit(1);

  if (!session || session.status !== "active") {
    res.status(409).json({ error: "Session is not currently active." });
    return;
  }

  const now = new Date();
  const dur = Math.floor((now.getTime() - new Date(session.startedAt).getTime()) / 1000);

  const [stopped] = await db
    .update(sessionsTable)
    .set({ status: "stopped", endedAt: now, durationSeconds: dur })
    .where(eq(sessionsTable.id, session.id))
    .returning();

  await db
    .update(cloudConnectionsTable)
    .set({ activeSessionId: null })
    .where(eq(cloudConnectionsTable.id, conn.id));

  res.json({
    sessionId: stopped.id,
    profile: stopped.profile,
    status: stopped.status,
    startedAt: stopped.startedAt,
    endedAt: stopped.endedAt ?? null,
    durationSeconds: stopped.durationSeconds,
  });
});

// ── GET /api/session/status ───────────────────────────────────────────────────

router.get("/session/status", async (req, res): Promise<void> => {
  const conn = await requireToken(req, res);
  if (!conn) return;

  let session = null;
  if (conn.activeSessionId) {
    const [s] = await db
      .select()
      .from(sessionsTable)
      .where(eq(sessionsTable.id, conn.activeSessionId))
      .limit(1);
    if (s) {
      const dur = s.status === "active"
        ? Math.floor((Date.now() - new Date(s.startedAt).getTime()) / 1000)
        : s.durationSeconds;
      session = {
        sessionId: s.id,
        profile: s.profile,
        status: s.status,
        startedAt: s.startedAt,
        endedAt: s.endedAt ?? null,
        durationSeconds: dur,
      };
    }
  }

  const status = !conn.activeSessionId
    ? "idle"
    : session?.status === "active"
    ? "active"
    : "stopped";

  res.json({
    connected: conn.status === "connected",
    status,
    connectionId: conn.id,
    region: conn.region,
    profile: conn.profile,
    session,
  });
});

// ── GET /api/metrics ──────────────────────────────────────────────────────────

router.get("/metrics", async (req, res): Promise<void> => {
  const conn = await requireToken(req, res);
  if (!conn) return;

  const [totals] = await db
    .select({
      total: count(),
      totalDur: sum(sessionsTable.durationSeconds),
    })
    .from(sessionsTable)
    .where(eq(sessionsTable.userEmail, conn.userEmail));

  const [{ active }] = await db
    .select({ active: count() })
    .from(sessionsTable)
    .where(
      sql`${sessionsTable.userEmail} = ${conn.userEmail} AND ${sessionsTable.status} = 'active'`
    );

  const profileRows = (await db.execute(
    sql`SELECT profile, COUNT(*)::integer AS count FROM sessions WHERE user_email = ${conn.userEmail} GROUP BY profile ORDER BY count DESC`
  )) as unknown as { rows?: Array<{ profile: string; count: number }> };
  const sessionsByProfile = (profileRows.rows ?? []).map((r) => ({
    profile: r.profile,
    count: Number(r.count),
  }));

  const recent = await db
    .select()
    .from(sessionsTable)
    .where(eq(sessionsTable.userEmail, conn.userEmail))
    .orderBy(desc(sessionsTable.startedAt))
    .limit(5);

  const totalSessions = Number(totals.total ?? 0);
  const totalDur = Number(totals.totalDur ?? 0);

  res.json({
    totalSessions,
    activeSessions: Number(active ?? 0),
    totalDurationSeconds: totalDur,
    avgDurationSeconds: totalSessions > 0 ? Math.floor(totalDur / totalSessions) : 0,
    sessionsByProfile,
    recentSessions: recent.map((s) => ({
      sessionId: s.id,
      profile: s.profile,
      status: s.status,
      startedAt: s.startedAt,
      endedAt: s.endedAt ?? null,
      durationSeconds: s.durationSeconds,
    })),
  });
});

export default router;

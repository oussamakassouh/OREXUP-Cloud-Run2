import { Router, type IRouter, type Request, type Response } from "express";
import { eq, desc } from "drizzle-orm";
import Stripe from "stripe";
import { db, paymentsTable } from "@workspace/db";
import { userAuth, type AuthRequest } from "../middlewares/userJwtAuth";
import { logger } from "../lib/logger";

const router: IRouter = Router();

function getStripe(): Stripe {
  const key = process.env.STRIPE_SECRET_KEY;
  if (!key) throw new Error("STRIPE_SECRET_KEY is not configured");
  return new Stripe(key, { apiVersion: "2026-06-24.dahlia" });
}

function getAppUrl(): string {
  if (process.env.APP_URL) return process.env.APP_URL.replace(/\/$/, "");
  if (process.env.REPLIT_DEV_DOMAIN) return `https://${process.env.REPLIT_DEV_DOMAIN}`;
  return "http://localhost:5173";
}

const PLAN_PRICES: Record<string, Record<string, number>> = {
  standard: { monthly: 900,  annual: 9900  },
  premium:  { monthly: 2900, annual: 29900 },
  custom:   { monthly: 4900, annual: 49900 },
};

const PLAN_NAMES: Record<string, string> = {
  standard: "Starter",
  premium:  "Premium",
  custom:   "Ultimate",
};

// POST /payment/create-checkout — authenticated user creates a checkout session
router.post("/payment/create-checkout", userAuth, async (req: Request, res: Response): Promise<void> => {
  const { userEmail } = req as AuthRequest;
  const { plan, billing } = req.body as { plan?: string; billing?: string };
  if (!plan || !PLAN_PRICES[plan]) {
    res.status(400).json({ error: "Invalid plan. Must be standard, premium, or custom." });
    return;
  }
  const cycle = billing === "annual" ? "annual" : "monthly";
  const amount = PLAN_PRICES[plan][cycle];
  const interval: Stripe.PriceCreateParams.Recurring.Interval = cycle === "annual" ? "year" : "month";
  const appUrl = getAppUrl();

  try {
    const stripe = getStripe();
    const session = await stripe.checkout.sessions.create({
      mode: "subscription",
      payment_method_types: ["card"],
      customer_email: userEmail,
      line_items: [{
        price_data: {
          currency: "usd",
          unit_amount: amount,
          recurring: { interval },
          product_data: {
            name: `OREXUP ${PLAN_NAMES[plan]} Plan`,
            description: `${cycle === "annual" ? "Annual" : "Monthly"} subscription`,
          },
        },
        quantity: 1,
      }],
      success_url: `${appUrl}/dashboard/checkout/success?session_id={CHECKOUT_SESSION_ID}&plan=${plan}&billing=${cycle}`,
      cancel_url:  `${appUrl}/dashboard/billing`,
      metadata:    { plan, billing: cycle, userEmail },
    });
    res.json({ url: session.url, sessionId: session.id });
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : "Stripe error";
    logger.error({ err }, "Create checkout error");
    res.status(502).json({ error: msg });
  }
});

// POST /payment/webhook — Stripe webhook (processes events and records payments)
router.post("/payment/webhook", async (req: Request, res: Response): Promise<void> => {
  const sig = req.headers["stripe-signature"] as string | undefined;
  const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;
  let event: Stripe.Event;

  try {
    const stripe = getStripe();
    if (webhookSecret && sig) {
      event = stripe.webhooks.constructEvent(req.body as Buffer, sig, webhookSecret);
    } else {
      event = req.body as unknown as Stripe.Event;
    }
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : "Webhook error";
    res.status(400).json({ error: msg });
    return;
  }

  try {
    switch (event.type) {
      case "checkout.session.completed": {
        const session = event.data.object as Stripe.Checkout.Session;
        const plan = session.metadata?.plan;
        const userEmail = session.metadata?.userEmail ?? session.customer_details?.email;
        const billing = session.metadata?.billing ?? "monthly";
        if (plan && userEmail && PLAN_PRICES[plan]) {
          const cycle = billing === "annual" ? "annual" : "monthly";
          await db.insert(paymentsTable).values({
            userEmail,
            plan,
            amountCents: PLAN_PRICES[plan][cycle],
            status: "paid",
            method: "stripe",
          });
          logger.info({ plan, userEmail }, "Checkout completed, payment recorded");
        }
        break;
      }
      case "customer.subscription.deleted": {
        const sub = event.data.object as Stripe.Subscription;
        logger.info({ customerId: sub.customer }, "Subscription cancelled via webhook");
        break;
      }
      default:
        break;
    }
  } catch (err) {
    logger.error({ err, eventType: event.type }, "Webhook handler error");
  }

  res.json({ received: true });
});

// GET /payment/history — authenticated user's payment history
router.get("/payment/history", userAuth, async (req: Request, res: Response): Promise<void> => {
  const { userEmail } = req as AuthRequest;
  const limit = Math.min(Number(req.query.limit ?? 20), 100);
  const offset = Number(req.query.offset ?? 0);

  try {
    const history = await db
      .select()
      .from(paymentsTable)
      .where(eq(paymentsTable.userEmail, userEmail))
      .orderBy(desc(paymentsTable.createdAt))
      .limit(limit)
      .offset(offset);

    res.json({
      payments: history.map((p) => ({
        id: p.id,
        plan: p.plan,
        amountCents: p.amountCents,
        amountFormatted: `$${(p.amountCents / 100).toFixed(2)}`,
        status: p.status,
        method: p.method ?? null,
        createdAt: p.createdAt,
      })),
      pagination: { limit, offset },
    });
  } catch (err) {
    logger.error({ err }, "Payment history error");
    res.status(500).json({ error: "Failed to fetch payment history." });
  }
});

// POST /payment/cancel — cancel a Stripe subscription
router.post("/payment/cancel", userAuth, async (req: Request, res: Response): Promise<void> => {
  const { subscriptionId } = req.body as { subscriptionId?: string };
  if (!subscriptionId) {
    res.status(400).json({ error: "subscriptionId is required." });
    return;
  }
  try {
    const stripe = getStripe();
    const cancelled = await stripe.subscriptions.cancel(subscriptionId);
    logger.info({ subscriptionId, status: cancelled.status }, "Subscription cancelled");
    res.json({ status: cancelled.status, cancelledAt: new Date().toISOString() });
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : "Stripe error";
    logger.error({ err }, "Cancel subscription error");
    res.status(502).json({ error: msg });
  }
});

export default router;

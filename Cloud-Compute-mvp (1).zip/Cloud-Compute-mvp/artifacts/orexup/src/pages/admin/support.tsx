import { useState } from "react";
import { AdminLayout } from "@/components/admin-layout";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription } from "@/components/ui/sheet";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { Textarea } from "@/components/ui/textarea";
import { MessageSquare, UserPlus, X, Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useGetAdminSupport, type AdminSupportTicket } from "@workspace/api-client-react";
import { PeriodFilter, usePeriodFilter } from "@/components/period-filter";

const BASE = import.meta.env.BASE_URL?.replace(/\/$/, "") ?? "";

function relativeTime(iso: string) {
  const diff = Date.now() - new Date(iso).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return "just now";
  if (mins < 60) return `${mins} minutes ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs} hours ago`;
  const days = Math.floor(hrs / 24);
  if (days < 7) return `${days} day${days > 1 ? "s" : ""} ago`;
  const weeks = Math.floor(days / 7);
  if (weeks < 5) return `${weeks} week${weeks > 1 ? "s" : ""} ago`;
  return `${Math.floor(days / 30)} month(s) ago`;
}

export default function AdminSupportPage() {
  const { period, setPeriod, customFrom, setCustomFrom, customTo, setCustomTo, apply, queryParams, label } =
    usePeriodFilter("month");
  const { data, isLoading, isError, refetch } = useGetAdminSupport(queryParams);
  const tickets: AdminSupportTicket[] = data ?? [];
  const [activeTab, setActiveTab] = useState("Open");
  const [replyTicket, setReplyTicket] = useState<AdminSupportTicket | null>(null);
  const [closeTicket, setCloseTicket] = useState<AdminSupportTicket | null>(null);
  const [replyText, setReplyText] = useState("");
  const [replying, setReplying] = useState(false);
  const [closing, setClosing] = useState(false);
  const { toast } = useToast();

  const getPriorityColor = (p: string) => {
    switch (p) {
      case "Urgent": return "bg-red-500/20 text-red-500 border-red-500/30";
      case "High": return "bg-amber-500/20 text-amber-500 border-amber-500/30";
      case "Normal": return "bg-blue-500/20 text-blue-400 border-blue-500/30";
      case "Low": return "bg-white/10 text-muted-foreground border-white/20";
      default: return "";
    }
  };

  const countByStatus = (status: string) => tickets.filter((t) => t.status === status).length;
  const currentList = tickets.filter((t) => t.status === activeTab);

  const handleAssign = (agent: string, id: number) => {
    toast({ title: "Ticket Assigned", description: `#${id} assigned to ${agent}.` });
  };

  const handleClose = async () => {
    if (!closeTicket) return;
    setClosing(true);
    try {
      const res = await fetch(`${BASE}/api/admin/support/${closeTicket.id}/status`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ status: "Closed" }),
      });
      const data = await res.json() as { ok?: boolean; error?: string };
      if (!res.ok) {
        toast({ title: "Error", description: data.error ?? "Failed to close ticket.", variant: "destructive" });
        return;
      }
      toast({ title: "Ticket Closed", description: `#${closeTicket.id} moved to closed.` });
      setCloseTicket(null);
      void refetch();
    } catch {
      toast({ title: "Network error", description: "Could not reach the server.", variant: "destructive" });
    } finally {
      setClosing(false);
    }
  };

  const handleReply = async () => {
    if (!replyText.trim() || !replyTicket) return;
    setReplying(true);
    try {
      const res = await fetch(`${BASE}/api/admin/support/${replyTicket.id}/reply`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ message: replyText.trim() }),
      });
      const data = await res.json() as { ok?: boolean; error?: string };
      if (!res.ok) {
        toast({ title: "Error", description: data.error ?? "Failed to send reply.", variant: "destructive" });
        return;
      }
      toast({ title: "Reply Sent", description: `Message added to #${replyTicket.id}.` });
      setReplyText("");
      setReplyTicket(null);
      void refetch();
    } catch {
      toast({ title: "Network error", description: "Could not reach the server.", variant: "destructive" });
    } finally {
      setReplying(false);
    }
  };

  return (
    <AdminLayout title="Support Center">
      {isError && (
        <Card className="border-red-500/20 bg-red-500/5 mb-6">
          <CardContent className="py-4 text-sm text-red-400">Failed to load support tickets.</CardContent>
        </Card>
      )}

      <div className="mb-6">
        <PeriodFilter
          period={period} onPeriodChange={setPeriod}
          customFrom={customFrom} customTo={customTo}
          onCustomFromChange={setCustomFrom} onCustomToChange={setCustomTo}
          onApply={apply}
        />
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-3 max-w-[400px] mb-6">
          <TabsTrigger value="Open">Open ({countByStatus("Open")})</TabsTrigger>
          <TabsTrigger value="Pending">Pending ({countByStatus("Pending")})</TabsTrigger>
          <TabsTrigger value="Closed">Closed ({countByStatus("Closed")})</TabsTrigger>
        </TabsList>

        <div className="space-y-4">
          {currentList.map((ticket) => (
            <Card key={ticket.id} className="border-white/5 bg-card/50 hover:bg-card/70 transition-colors">
              <CardContent className="p-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-sm font-medium text-primary">#{ticket.id}</span>
                    <h4 className="font-semibold">{ticket.subject}</h4>
                    <Badge variant="outline" className={getPriorityColor(ticket.priority)}>
                      {ticket.priority}
                    </Badge>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <span>{ticket.user}</span>
                    <span>·</span>
                    <span>Created {relativeTime(ticket.createdAt)}</span>
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <Button variant="outline" size="sm" className="bg-black/20 hover:bg-white/10" onClick={() => setReplyTicket(ticket)}>
                    <MessageSquare className="mr-2 h-4 w-4" /> Reply
                  </Button>

                  {activeTab !== "Closed" && (
                    <>
                      <Popover>
                        <PopoverTrigger asChild>
                          <Button variant="outline" size="sm" className="bg-black/20 hover:bg-white/10">
                            <UserPlus className="mr-2 h-4 w-4" /> Assign
                          </Button>
                        </PopoverTrigger>
                        <PopoverContent className="w-[200px] p-2 bg-[#0a0f16] border-white/10">
                          <p className="text-xs font-medium text-muted-foreground mb-2 px-2">Assign to agent</p>
                          <div className="space-y-1">
                            {["Sarah", "Mike", "Emma", "Unassigned"].map((agent) => (
                              <Button key={agent} variant="ghost" size="sm" className="w-full justify-start text-sm" onClick={() => handleAssign(agent, ticket.id)}>
                                {agent}
                              </Button>
                            ))}
                          </div>
                        </PopoverContent>
                      </Popover>

                      <Button
                        variant="ghost"
                        size="icon"
                        aria-label="Close ticket"
                        className="text-muted-foreground hover:text-white"
                        onClick={() => setCloseTicket(ticket)}
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    </>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
          {currentList.length === 0 && (
            <div className="text-center py-12 text-muted-foreground border border-white/5 rounded-xl border-dashed">
              {isLoading ? "Loading…" : "No data available"}
            </div>
          )}
        </div>
      </Tabs>

      <Sheet open={!!replyTicket} onOpenChange={(o) => !o && setReplyTicket(null)}>
        <SheetContent className="bg-[#0a0f16] border-white/10 sm:max-w-lg flex flex-col h-full">
          <SheetHeader className="pb-4 border-b border-white/5 shrink-0">
            <div className="flex items-center gap-2">
              <SheetTitle>#{replyTicket?.id}</SheetTitle>
              <Badge variant="outline" className={replyTicket ? getPriorityColor(replyTicket.priority) : ""}>
                {replyTicket?.priority}
              </Badge>
            </div>
            <SheetDescription className="text-base text-foreground font-medium mt-2">
              {replyTicket?.subject}
            </SheetDescription>
            <p className="text-xs text-muted-foreground">{replyTicket?.user}</p>
          </SheetHeader>

          <div className="flex-1 overflow-y-auto py-4">
            <p className="text-sm text-muted-foreground">No messages available for this ticket.</p>
          </div>

          <div className="pt-4 border-t border-white/5 shrink-0 space-y-3 mt-auto">
            <Textarea
              placeholder="Type your reply here..."
              className="bg-black/20 min-h-[100px]"
              value={replyText}
              onChange={(e) => setReplyText(e.target.value)}
            />
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setReplyTicket(null)} disabled={replying}>Cancel</Button>
              <Button
                onClick={handleReply}
                className="bg-primary text-primary-foreground hover:bg-primary/90"
                disabled={replying || !replyText.trim()}
              >
                {replying && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                Send Reply
              </Button>
            </div>
          </div>
        </SheetContent>
      </Sheet>

      <AlertDialog open={!!closeTicket} onOpenChange={(o) => !o && setCloseTicket(null)}>
        <AlertDialogContent className="bg-[#0a0f16] border-white/10">
          <AlertDialogHeader>
            <AlertDialogTitle>Close ticket #{closeTicket?.id}?</AlertDialogTitle>
            <AlertDialogDescription>
              This will move the ticket to the closed list. The user will be notified that their issue has been resolved.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="bg-white/5 border-white/10 hover:bg-white/10" disabled={closing}>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleClose} disabled={closing}>
              {closing && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Confirm Close
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </AdminLayout>
  );
}

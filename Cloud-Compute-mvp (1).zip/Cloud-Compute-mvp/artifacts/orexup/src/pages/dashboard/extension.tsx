import { useState, useEffect } from "react";
import { DashboardLayout } from "@/components/dashboard-layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { useTheme } from "@/components/theme-provider";
import { useAppContext } from "@/lib/app-context";

export default function ExtensionPage() {
  const [masterOn, setMasterOn] = useState(true);
  const [elapsed, setElapsed] = useState(0);
  const { toast } = useToast();
  const { theme, setTheme } = useTheme();
  const { cloudConnected, setCloudConnected, sessionRunning, setSessionRunning } = useAppContext();

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (sessionRunning) {
      interval = setInterval(() => setElapsed((prev) => prev + 1), 1000);
    } else {
      setElapsed(0);
    }
    return () => clearInterval(interval);
  }, [sessionRunning]);

  const formatTime = (s: number) => {
    const h = Math.floor(s / 3600);
    const m = Math.floor((s % 3600) / 60);
    const sec = s % 60;
    return `${h.toString().padStart(2, "0")}:${m.toString().padStart(2, "0")}:${sec.toString().padStart(2, "0")}`;
  };

  const handleConnect = () => {
    setCloudConnected(true);
    toast({ title: "Cloud Connected", description: "Connection established." });
  };

  const handleDisconnect = () => {
    setCloudConnected(false);
    toast({ title: "Cloud Disconnected", description: "Connection terminated." });
  };

  const handleStartSession = () => {
    setSessionRunning(true);
    toast({ title: "Session Started", description: "Cloud session is now active." });
  };

  const handleStopSession = () => {
    setSessionRunning(false);
    toast({ title: "Session Stopped", description: "Cloud session has ended." });
  };

  const handleSettingChange = (name: string) => {
    toast({ title: "Setting saved", description: `${name} updated successfully.` });
  };

  return (
    <DashboardLayout title="Extension Settings">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-5xl mx-auto">
        <div className="flex justify-center md:justify-end">
          <div
            className={`w-[360px] rounded-xl border shadow-2xl bg-card transition-opacity duration-300 ${
              !masterOn ? "opacity-50 pointer-events-none" : ""
            }`}
          >
            <div className="flex items-center justify-between p-4 border-b border-white/5 pointer-events-auto opacity-100">
              <div className="font-heading font-bold text-lg">OREXUP</div>
              <Switch checked={masterOn} onCheckedChange={setMasterOn} data-testid="master-switch" />
            </div>

            <div className="p-6 flex flex-col items-center border-b border-white/5">
              <div
                className={`h-16 w-16 rounded-full flex items-center justify-center mb-4 transition-colors ${
                  cloudConnected ? "bg-primary/20 text-primary" : "bg-muted text-muted-foreground"
                }`}
              >
                <div
                  className={`h-4 w-4 rounded-full ${
                    cloudConnected
                      ? "bg-primary animate-pulse shadow-[0_0_15px_rgba(var(--primary),0.8)]"
                      : "bg-muted-foreground"
                  }`}
                />
              </div>
              <h3 className="text-xl font-bold font-heading">{cloudConnected ? "Connected" : "Disconnected"}</h3>
              <p className="text-sm text-muted-foreground">{cloudConnected ? "Cloud active" : "No cloud connection"}</p>
            </div>

            <div className="p-4 grid grid-cols-2 gap-3 border-b border-white/5">
              <Button
                onClick={handleConnect}
                disabled={cloudConnected}
                className="w-full bg-primary text-primary-foreground hover:bg-primary/90"
                data-testid="ext-connect"
              >
                Connect Cloud
              </Button>
              <Button
                onClick={handleDisconnect}
                disabled={!cloudConnected}
                variant="outline"
                className="w-full text-destructive border-destructive/20 hover:bg-destructive/10"
                data-testid="ext-disconnect"
              >
                Disconnect
              </Button>
              <Button
                onClick={handleStartSession}
                disabled={!cloudConnected || sessionRunning}
                className="w-full bg-green-600 text-white hover:bg-green-700"
                data-testid="ext-start"
              >
                Start Session
              </Button>
              <Button
                onClick={handleStopSession}
                disabled={!sessionRunning}
                variant="outline"
                className="w-full"
                data-testid="ext-stop"
              >
                Stop Session
              </Button>
            </div>

            {sessionRunning && (
              <div className="p-4 bg-primary/5">
                <div className="flex justify-between items-center mb-2">
                  <span className="text-sm font-medium text-primary">Session Active</span>
                  <span className="text-sm font-mono text-primary">{formatTime(elapsed)}</span>
                </div>
                <div className="h-1 bg-primary/20 rounded-full overflow-hidden">
                  <div className="h-full bg-primary animate-pulse w-full" />
                </div>
              </div>
            )}
          </div>
        </div>

        <div className="space-y-6">
          <Card className="border-white/5 bg-card/50">
            <CardHeader>
              <CardTitle className="text-lg">General</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {[
                { label: "Auto Connect", testId: "ext-auto-connect" },
                { label: "Auto Start Session", testId: "ext-auto-start" },
              ].map(({ label, testId }) => (
                <div key={label} className="flex items-center justify-between py-2 border-b border-white/5">
                  <span className="text-sm">{label}</span>
                  <Switch onCheckedChange={() => handleSettingChange(label)} data-testid={testId} />
                </div>
              ))}
              <div className="flex items-center justify-between py-2 border-b border-white/5">
                <span className="text-sm">Notifications</span>
                <Switch defaultChecked onCheckedChange={() => handleSettingChange("Notifications")} data-testid="ext-notifications" />
              </div>
              <div className="flex items-center justify-between py-2">
                <span className="text-sm">Dark Mode</span>
                <Switch
                  checked={theme === "dark"}
                  onCheckedChange={(checked) => {
                    setTheme(checked ? "dark" : "light");
                    handleSettingChange("Theme");
                  }}
                  data-testid="ext-dark-mode"
                />
              </div>
            </CardContent>
          </Card>

          <Card className="border-white/5 bg-card/50">
            <CardHeader>
              <CardTitle className="text-lg">Security</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between py-2 border-b border-white/5">
                <span className="text-sm">Session Timeout</span>
                <Select defaultValue="30m" onValueChange={() => handleSettingChange("Session Timeout")}>
                  <SelectTrigger className="w-[120px]" data-testid="ext-session-timeout">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="15m">15 min</SelectItem>
                    <SelectItem value="30m">30 min</SelectItem>
                    <SelectItem value="1h">1 hour</SelectItem>
                    <SelectItem value="never">Never</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex items-center justify-between py-2 border-b border-white/5">
                <span className="text-sm">Device Verification</span>
                <Switch defaultChecked onCheckedChange={() => handleSettingChange("Device Verification")} data-testid="ext-device-verification" />
              </div>
              <div className="flex items-center justify-between py-2">
                <span className="text-sm">Extension Validation</span>
                <Switch defaultChecked onCheckedChange={() => handleSettingChange("Extension Validation")} data-testid="ext-validation" />
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </DashboardLayout>
  );
}

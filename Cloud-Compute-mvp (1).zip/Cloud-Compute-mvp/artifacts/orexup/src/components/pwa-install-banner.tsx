import { useState } from "react";
import { usePWAInstall } from "@/hooks/use-pwa-install";
import { X, Download, Smartphone } from "lucide-react";
import { Button } from "@/components/ui/button";

export function PWAInstallBanner() {
  const { canInstall, isIOS, install, dismiss } = usePWAInstall();
  const [installing, setInstalling] = useState(false);
  const [showIOSGuide, setShowIOSGuide] = useState(false);

  if (!canInstall) return null;

  const handleInstall = async () => {
    if (isIOS) {
      setShowIOSGuide(true);
      return;
    }
    setInstalling(true);
    await install();
    setInstalling(false);
  };

  return (
    <>
      <div
        className="fixed bottom-4 left-1/2 -translate-x-1/2 z-50 w-[calc(100%-32px)] max-w-md"
        role="banner"
        aria-label="Install OREXUP app"
      >
        <div className="flex items-center gap-3 rounded-2xl border border-white/10 bg-[#0d1520]/95 backdrop-blur-md shadow-2xl shadow-black/40 p-3 pr-2">
          <div className="shrink-0 w-10 h-10 rounded-xl bg-[#FF3C00] flex items-center justify-center">
            <Download className="h-5 w-5 text-white" />
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-semibold text-white leading-tight">Install OREXUP</p>
            <p className="text-xs text-slate-400 leading-tight mt-0.5">
              {isIOS ? "Add to Home Screen for the best experience" : "Install as an app — fast, offline-ready"}
            </p>
          </div>
          <div className="flex items-center gap-1 shrink-0">
            <Button
              size="sm"
              className="h-8 px-3 text-xs bg-[#FF3C00] hover:bg-[#e63600] text-white border-0"
              onClick={handleInstall}
              disabled={installing}
            >
              {installing ? "Installing…" : "Install"}
            </Button>
            <button
              onClick={dismiss}
              className="p-1.5 rounded-lg text-slate-500 hover:text-white hover:bg-white/10 transition-colors"
              aria-label="Dismiss install prompt"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>
      </div>

      {showIOSGuide && (
        <div
          className="fixed inset-0 z-50 flex items-end justify-center p-4 bg-black/60 backdrop-blur-sm"
          onClick={() => setShowIOSGuide(false)}
        >
          <div
            className="w-full max-w-md rounded-2xl border border-white/10 bg-[#0d1520] p-6 space-y-4"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between">
              <h3 className="font-semibold text-white">Add to Home Screen</h3>
              <button
                onClick={() => setShowIOSGuide(false)}
                className="p-1 text-slate-400 hover:text-white"
                aria-label="Close guide"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
            <ol className="space-y-3 text-sm text-slate-300">
              <li className="flex items-start gap-3">
                <span className="shrink-0 w-6 h-6 rounded-full bg-[#FF3C00]/20 text-[#FF3C00] text-xs font-bold flex items-center justify-center">1</span>
                <span>Tap the <strong className="text-white">Share</strong> button at the bottom of Safari (the box with an arrow pointing up)</span>
              </li>
              <li className="flex items-start gap-3">
                <span className="shrink-0 w-6 h-6 rounded-full bg-[#FF3C00]/20 text-[#FF3C00] text-xs font-bold flex items-center justify-center">2</span>
                <span>Scroll down and tap <strong className="text-white">Add to Home Screen</strong></span>
              </li>
              <li className="flex items-start gap-3">
                <span className="shrink-0 w-6 h-6 rounded-full bg-[#FF3C00]/20 text-[#FF3C00] text-xs font-bold flex items-center justify-center">3</span>
                <span>Tap <strong className="text-white">Add</strong> to confirm</span>
              </li>
            </ol>
            <div className="flex items-center gap-2 text-xs text-slate-500 pt-1 border-t border-white/5">
              <Smartphone className="h-3.5 w-3.5 shrink-0" />
              <span>OREXUP will open in standalone app mode</span>
            </div>
            <Button className="w-full bg-[#FF3C00] hover:bg-[#e63600] text-white" onClick={() => { setShowIOSGuide(false); dismiss(); }}>
              Got it
            </Button>
          </div>
        </div>
      )}
    </>
  );
}

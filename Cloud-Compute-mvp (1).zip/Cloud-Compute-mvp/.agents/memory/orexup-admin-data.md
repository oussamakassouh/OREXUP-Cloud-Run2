---
name: OREXUP admin panel data wiring
description: How the admin panel maps DB values, money, severity, and which fields have no backing table.
---

# OREXUP admin panel: real-DB wiring

The 7 admin pages (overview, traffic, analytics, users, payments, security, support)
read only real DB aggregations via generated react-query hooks. Empty DB -> "0" / "No data available".

## Money
- All money is stored in CENTS. Display = divide by 100, formatted with 2 decimal places
  (minimumFractionDigits: 2). Do NOT round to whole dollars — that misstates per-unit values.

## Security severity casing
- DB stores `severity` lowercase (critical/high/low). The frontend compares/styles using
  Title case (Critical/High/Medium/Low).
- **Rule:** the API capitalizes severity in the events payload (single source) so filters and
  badge styling match. If you change either side, keep them in sync.

## Fields with NO backing table (honest empty, not fake)
- security `roleUserCounts` (owner/admin/support) — no `role` column on app_users and no admin
  accounts table, so returns 0s.
- security `adminSessions` — the `sessions` table is for end-user cloud sessions, not admin
  logins, so returns [].
- **Why:** these zeros/empties are the honest "no data" state given current schema. Only add
  real values if an admin-accounts/roles schema is introduced.

## Dashboard "Metrics" page (user-facing) — browser metrics only
- `artifacts/orexup/src/pages/dashboard/metrics.tsx` must display ONLY real,
  browser-accessible values (navigator.hardwareConcurrency, deviceMemory,
  performance.memory, WebGL renderer/vendor, navigator.connection, storage.estimate,
  getBattery, screen/viewport, navigation timing, etc.).
- **Rule:** never fabricate CPU/GPU/RAM/load/session/review numbers here. Any field a
  browser does not expose must render the literal "Unavailable". No Math.random, no
  hardcoded percentages.
- **Why:** explicit user requirement — real browser data only, "Unavailable" otherwise.

## Partner management (admin/partners)
- DB stores partner `status` lowercase (pending/active/disabled); `role` Title case
  (Support/Marketing/Developer/Business). Frontend capitalizes status for display,
  compares case-insensitively.
- **Rule:** both `role` and `status` are enum-constrained in the OpenAPI spec (so generated
  zod bodies reject invalid values with 400). If you add a role/status value, change it in
  openapi.yaml and re-run codegen — do NOT loosen to free-text.
- Approve/Disable are NOT separate endpoints: they are PATCH /admin/partners/{id} with
  status=active/disabled. Invite = POST (forces status=pending regardless of input).
- **Why:** spec enumerates the only valid roles/statuses; enforcing at spec+zod keeps DB
  integrity since all writes go through the API.

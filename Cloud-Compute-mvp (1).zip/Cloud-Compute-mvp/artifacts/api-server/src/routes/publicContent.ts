import { Router, type IRouter } from "express";
import { eq, desc } from "drizzle-orm";
import { db, contentPagesTable, blogPostsTable, jobListingsTable } from "@workspace/db";

const router: IRouter = Router();

router.get("/public/pages/:slug", async (req, res): Promise<void> => {
  const rows = await db.select().from(contentPagesTable)
    .where(eq(contentPagesTable.slug, req.params.slug)).limit(1);
  if (!rows[0] || rows[0].status !== "published") { res.status(404).json({ error: "Not found" }); return; }
  const p = rows[0];
  res.json({ ...p, createdAt: p.createdAt.toISOString(), updatedAt: p.updatedAt.toISOString() });
});

router.get("/public/blog", async (_req, res): Promise<void> => {
  const rows = await db.select().from(blogPostsTable)
    .where(eq(blogPostsTable.status, "published"))
    .orderBy(desc(blogPostsTable.publishedAt));
  res.json(rows.map((p) => ({ ...p, publishedAt: p.publishedAt?.toISOString() ?? null, createdAt: p.createdAt.toISOString(), updatedAt: p.updatedAt.toISOString() })));
});

router.get("/public/blog/:id", async (req, res): Promise<void> => {
  const id = parseInt(req.params.id, 10);
  const rows = await db.select().from(blogPostsTable)
    .where(eq(blogPostsTable.id, id)).limit(1);
  if (!rows[0] || rows[0].status !== "published") { res.status(404).json({ error: "Not found" }); return; }
  const p = rows[0];
  res.json({ ...p, publishedAt: p.publishedAt?.toISOString() ?? null, createdAt: p.createdAt.toISOString(), updatedAt: p.updatedAt.toISOString() });
});

router.get("/public/jobs", async (_req, res): Promise<void> => {
  const rows = await db.select().from(jobListingsTable)
    .where(eq(jobListingsTable.status, "open"))
    .orderBy(desc(jobListingsTable.createdAt));
  res.json(rows.map((j) => ({ ...j, createdAt: j.createdAt.toISOString(), updatedAt: j.updatedAt.toISOString() })));
});

export default router;

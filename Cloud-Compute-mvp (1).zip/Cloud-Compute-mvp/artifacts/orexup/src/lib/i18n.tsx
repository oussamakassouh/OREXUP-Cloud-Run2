import { createContext, useContext, useState, useEffect } from "react";

export type Locale = "en" | "fr" | "es" | "ar" | "nl" | "zh" | "de";

export const LOCALES: { code: Locale; label: string; native: string; rtl?: boolean }[] = [
  { code: "en", label: "English",  native: "English"  },
  { code: "fr", label: "French",   native: "Français" },
  { code: "es", label: "Spanish",  native: "Español"  },
  { code: "ar", label: "Arabic",   native: "العربية", rtl: true },
  { code: "nl", label: "Dutch",    native: "Nederlands" },
  { code: "zh", label: "Chinese",  native: "中文" },
  { code: "de", label: "German",   native: "Deutsch" },
];

export interface Translations {
  nav: { signIn: string; signUp: string };
  footer: {
    tagline: string;
    company: string; aboutUs: string; blog: string; careers: string; support: string;
    legal: string; privacy: string; terms: string; cookies: string; security: string;
    copyright: string;
  };
  faq: { title: string; items: { q: string; a: string }[] };
  home: {
    heroTitle: string; heroTitleHighlight: string;
    heroCta: string;
    demoTitle: string; demoSubtitle: string;
    featuresTitle: string; featuresSubtitle: string;
    features: { title: string; desc: string }[];
    pricingTitle: string; monthly: string; annual: string; save: string;
    includes: string;
    starterName: string; starterDesc: string;
    premiumName: string; premiumDesc: string;
    ultimateName: string; ultimateDesc: string;
    starterFeature: string; premiumFeature: string; ultimateFeature: string;
    connectCta: string;
    year: string; month: string;
  };
  signIn: {
    title: string; desc: string;
    emailLabel: string; passwordLabel: string;
    forgotBtn: string;
    submitBtn: string; submittingBtn: string;
    noAccount: string; signUpLink: string;
    unverifiedMsg: string; resendLink: string;
    toastFailTitle: string; toastSuccessTitle: string; toastSuccessDesc: string;
    forgotTitle: string; forgotDesc: string;
    forgotSentTitle: string; forgotSentDesc: string; forgotDoneBtn: string;
    forgotSendBtn: string; forgotSendingBtn: string;
  };
  signUp: {
    title: string; desc: string;
    nameLabel: string; emailLabel: string; passwordLabel: string;
    submitBtn: string; submittingBtn: string;
    hasAccount: string; signInLink: string;
    toastFailTitle: string; toastSuccessTitle: string; toastSuccessDesc: string;
    pwRules: string[];
  };
  verifyEmail: {
    titlePending: string; titleDone: string;
    descDone: string; descVerifying: string;
    descPendingPrefix: string; descPendingSuffix: string;
    descGeneric: string;
    inactiveWarning: string;
    resendBtn: string; resentBtn: string;
    backToSignIn: string;
    toastVerifiedTitle: string; toastVerifiedDesc: string;
    toastFailTitle: string; toastFailDefault: string;
    toastNetworkTitle: string; toastNetworkDesc: string;
    toastResendTitle: string; toastNoPendingTitle: string; toastNoPendingDesc: string;
  };
  profile: {
    pageTitle: string;
    changePhoto: string;
    personalTitle: string; personalDesc: string;
    editBtn: string; saveBtn: string; cancelBtn: string;
    nameLabel: string; emailLabel: string;
    verifiedBadge: string;
    dangerTitle: string; dangerDesc: string; dangerBody: string;
    deleteBtn: string;
    confirmTitle: string; confirmDesc: string;
    confirmCancel: string; confirmDelete: string;
    toastUpdated: string; toastUpdatedDesc: string;
    toastPhoto: string; toastPhotoDesc: string;
    toastDeleted: string; toastDeletedDesc: string;
  };
  settings: {
    pageTitle: string;
    securityTitle: string; securityDesc: string;
    twoFaLabel: string; twoFaDesc: string;
    enabled: string; disabled: string;
    sessionsLabel: string; sessionsDesc: string;
    viewDevicesBtn: string;
    devicesTitle: string; devicesDesc: string;
    noDevices: string;
    passwordTitle: string; passwordDesc: string;
    currentPw: string; newPw: string; confirmPw: string;
    updatePwBtn: string;
    pwRules: string[];
    toastPwTitle: string; toastPwDesc: string;
    toastSecTitle: string; toastSecEnabled: string; toastSecDisabled: string;
    toastRevokeTitle: string; toastRevokeDesc: string;
  };
}

/* ─── ENGLISH ─── */
const en: Translations = {
  nav: { signIn: "Sign In", signUp: "Sign Up" },
  footer: {
    tagline: "Connect your browser and access optimized cloud performance environments for demanding tasks.",
    company: "Company", aboutUs: "About Us", blog: "Blog", careers: "Careers", support: "Support",
    legal: "Legal", privacy: "Privacy Policy", terms: "Terms of Service", cookies: "Cookie Policy", security: "Security",
    copyright: "OREXUP Cloud Platform. All rights reserved.",
  },
  home: {

    heroTitle: "Run Heavy Browser Workloads with", heroTitleHighlight: "OREXUP Cloud",
    heroCta: "Connect OREXUP Cloud",
    demoTitle: "See It in Action",
    demoSubtitle: "Watch how OREXUP routes your browser workloads to the cloud in real time.",
    featuresTitle: "Features", featuresSubtitle: "Engineered for absolute performance.",
    features: [
      { title: "Cloud Sessions",          desc: "Instantly spin up isolated environments with dedicated RAM and CPU allocations." },
      { title: "Performance Metrics",     desc: "Real-time telemetry tracking network overhead, frame times, and heap usage." },
      { title: "Browser Optimization",    desc: "Automatic flag injection and engine tweaks for heavy WebGL and Wasm payloads." },
      { title: "AI Performance Profiles", desc: "Dynamic resource shifting based on predictive workload analysis." },
    ],
    pricingTitle: "Pricing", monthly: "Monthly", annual: "Annual", save: "Save 20%",
    includes: "Includes:",
    starterName: "Starter",   starterDesc: "For getting started",        starterFeature: "120 hours / month",
    premiumName: "Premium",   premiumDesc: "For professional developers", premiumFeature: "240 hours / month",
    ultimateName: "Ultimate", ultimateDesc: "For power users",            ultimateFeature: "Unlimited usage time",
    connectCta: "Connect OREXUP Cloud",
    year: "year", month: "month",
  },
  signIn: {
    title: "Sign In", desc: "Access your cloud environments.",
    emailLabel: "Email", passwordLabel: "Password",
    forgotBtn: "Forgot Password?",
    submitBtn: "Sign In", submittingBtn: "Signing in…",
    noAccount: "Don't have an account?", signUpLink: "Sign Up",
    unverifiedMsg: "Please verify your email first.", resendLink: "Resend verification",
    toastFailTitle: "Sign in failed", toastSuccessTitle: "Signed in successfully", toastSuccessDesc: "Welcome to OREXUP.",
    forgotTitle: "Reset Password", forgotDesc: "Enter your account email and we'll send you a reset link.",
    forgotSentTitle: "Reset link sent!", forgotSentDesc: "If an account exists for", forgotDoneBtn: "Done",
    forgotSendBtn: "Send Reset Link", forgotSendingBtn: "Sending…",
  },
  signUp: {
    title: "Create Account", desc: "Enter your details to get started with OREXUP.",
    nameLabel: "Full Name", emailLabel: "Email", passwordLabel: "Password",
    submitBtn: "Create Account", submittingBtn: "Creating account…",
    hasAccount: "Already have an account?", signInLink: "Sign In",
    toastFailTitle: "Signup failed", toastSuccessTitle: "Account created!", toastSuccessDesc: "Check your inbox to verify your email before signing in.",
    pwRules: [
      "At least 8 characters",
      "One uppercase letter (A–Z)",
      "One lowercase letter (a–z)",
      "One number (0–9)",
    ],
  },
  verifyEmail: {
    titlePending: "Verify Your Email", titleDone: "Email Verified!",
    descDone: "Redirecting you to sign in…", descVerifying: "Verifying your email…",
    descPendingPrefix: "We sent a verification link to", descPendingSuffix: ". Click the link in your inbox to activate your account.",
    descGeneric: "We sent a verification link to your email address. Click it to activate your account.",
    inactiveWarning: "Your account remains inactive until email verification is complete.",
    resendBtn: "Resend Verification Email", resentBtn: "Email sent!",
    backToSignIn: "Back to Sign In",
    toastVerifiedTitle: "Email verified!", toastVerifiedDesc: "You can now sign in.",
    toastFailTitle: "Verification failed", toastFailDefault: "Invalid or expired link.",
    toastNetworkTitle: "Network error", toastNetworkDesc: "Could not verify email.",
    toastResendTitle: "Verification email sent",
    toastNoPendingTitle: "No pending email", toastNoPendingDesc: "Please sign up again.",
  },
  profile: {
    pageTitle: "Profile",
    changePhoto: "Change Photo",
    personalTitle: "Personal Information", personalDesc: "Update your personal details here.",
    editBtn: "Edit Profile", saveBtn: "Save Changes", cancelBtn: "Cancel",
    nameLabel: "Full Name", emailLabel: "Email Address",
    verifiedBadge: "Verified",
    dangerTitle: "Danger Zone", dangerDesc: "Permanently remove your account and all data.",
    dangerBody: "Once you delete your account, there is no going back. Please be certain.",
    deleteBtn: "Delete Account",
    confirmTitle: "Are you absolutely sure?",
    confirmDesc: "This action cannot be undone. All your data, session logs, and cloud configurations will be permanently deleted.",
    confirmCancel: "Cancel", confirmDelete: "Yes, delete account",
    toastUpdated: "Profile updated", toastUpdatedDesc: "Your details have been saved successfully.",
    toastPhoto: "Profile photo updated", toastPhotoDesc: "New avatar set successfully.",
    toastDeleted: "Account deleted", toastDeletedDesc: "You have been logged out.",
  },
  settings: {
    pageTitle: "Settings",
    securityTitle: "Account Security", securityDesc: "Manage how you secure your account.",
    twoFaLabel: "Two-factor Authentication", twoFaDesc: "Add an extra layer of security using an authenticator app.",
    enabled: "Enabled", disabled: "Disabled",
    sessionsLabel: "Active Sessions", sessionsDesc: "Manage devices currently logged into your account.",
    viewDevicesBtn: "View Devices",
    devicesTitle: "Active Devices", devicesDesc: "Review and revoke access to signed-in devices.",
    noDevices: "No active devices.",
    passwordTitle: "Change Password", passwordDesc: "Update your password. Must meet all complexity requirements.",
    currentPw: "Current Password", newPw: "New Password", confirmPw: "Confirm New Password",
    updatePwBtn: "Update Password",
    pwRules: [
      "At least 12 characters",
      "One uppercase letter (A–Z)",
      "One lowercase letter (a–z)",
      "One number (0–9)",
      "One special character (!@#$…)",
    ],
    toastPwTitle: "Password updated", toastPwDesc: "Your password has been changed successfully.",
    toastSecTitle: "Security updated", toastSecEnabled: "Two-factor authentication enabled.", toastSecDisabled: "Two-factor authentication disabled.",
    toastRevokeTitle: "Device revoked", toastRevokeDesc: "The session has been terminated.",
  },
  faq: {
    title: "Frequently Asked Questions",
    items: [
      { q: "What is OREXUP Cloud?", a: "OREXUP Cloud is a browser performance platform that offloads heavy browser workloads — WebGL rendering, Wasm execution, and data-intensive tasks — to optimized cloud environments, so your local machine stays fast." },
      { q: "How does the browser connection work?", a: "You install the OREXUP browser extension, sign in, and your browser sessions are automatically routed through our cloud nodes. No complex configuration required." },
      { q: "Can I cancel my subscription at any time?", a: "Yes. You can cancel anytime from your billing settings. Your plan stays active until the end of the current billing period with no extra charges." },
      { q: "Which browsers and platforms are supported?", a: "We currently support Chrome, Firefox, and Edge on Windows, macOS, and Linux. Mobile browser support is on our roadmap." },
      { q: "Is there a free trial?", a: "We don't offer a traditional trial, but every plan comes with a 30-day money-back guarantee — no questions asked." },
    ],
  },
};

/* ─── FRENCH ─── */
const fr: Translations = {
  nav: { signIn: "Connexion", signUp: "S'inscrire" },
  footer: {
    tagline: "Connectez votre navigateur et accédez à des environnements cloud optimisés pour les tâches exigeantes.",
    company: "Entreprise", aboutUs: "À propos", blog: "Blog", careers: "Carrières", support: "Assistance",
    legal: "Légal", privacy: "Politique de confidentialité", terms: "Conditions d'utilisation", cookies: "Politique cookies", security: "Sécurité",
    copyright: "OREXUP Cloud Platform. Tous droits réservés.",
  },
  home: {
    heroTitle: "Exécutez des charges lourdes dans le navigateur avec", heroTitleHighlight: "OREXUP Cloud",
    heroCta: "Connecter OREXUP Cloud",
    demoTitle: "Voyez-le en action",
    demoSubtitle: "Regardez comment OREXUP achemine vos workloads navigateur vers le cloud en temps réel.",
    featuresTitle: "Fonctionnalités", featuresSubtitle: "Conçu pour des performances absolues.",
    features: [
      { title: "Sessions Cloud",              desc: "Lancez instantanément des environnements isolés avec des allocations dédiées de RAM et CPU." },
      { title: "Métriques de performance",    desc: "Télémétrie en temps réel : surcharge réseau, temps de trame et utilisation du tas." },
      { title: "Optimisation du navigateur",  desc: "Injection automatique de flags et optimisations moteur pour les charges WebGL et Wasm." },
      { title: "Profils IA de performance",   desc: "Redistribution dynamique des ressources basée sur l'analyse prédictive des workloads." },
    ],
    pricingTitle: "Tarifs", monthly: "Mensuel", annual: "Annuel", save: "Économisez 20 %",
    includes: "Comprend :",
    starterName: "Débutant",  starterDesc: "Pour commencer",                 starterFeature: "120 heures / mois",
    premiumName: "Premium",   premiumDesc: "Pour les développeurs pro",       premiumFeature: "240 heures / mois",
    ultimateName: "Ultime",   ultimateDesc: "Pour les utilisateurs avancés", ultimateFeature: "Utilisation illimitée",
    connectCta: "Connecter OREXUP Cloud",
    year: "an", month: "mois",
  },
  signIn: {
    title: "Connexion", desc: "Accédez à vos environnements cloud.",
    emailLabel: "E-mail", passwordLabel: "Mot de passe",
    forgotBtn: "Mot de passe oublié ?",
    submitBtn: "Se connecter", submittingBtn: "Connexion en cours…",
    noAccount: "Pas encore de compte ?", signUpLink: "S'inscrire",
    unverifiedMsg: "Veuillez d'abord vérifier votre e-mail.", resendLink: "Renvoyer la vérification",
    toastFailTitle: "Échec de la connexion", toastSuccessTitle: "Connexion réussie", toastSuccessDesc: "Bienvenue sur OREXUP.",
    forgotTitle: "Réinitialiser le mot de passe", forgotDesc: "Entrez votre e-mail et nous vous enverrons un lien de réinitialisation.",
    forgotSentTitle: "Lien envoyé !", forgotSentDesc: "Si un compte existe pour", forgotDoneBtn: "Fermer",
    forgotSendBtn: "Envoyer le lien", forgotSendingBtn: "Envoi…",
  },
  signUp: {
    title: "Créer un compte", desc: "Renseignez vos informations pour démarrer avec OREXUP.",
    nameLabel: "Nom complet", emailLabel: "E-mail", passwordLabel: "Mot de passe",
    submitBtn: "Créer un compte", submittingBtn: "Création du compte…",
    hasAccount: "Vous avez déjà un compte ?", signInLink: "Se connecter",
    toastFailTitle: "Échec de l'inscription", toastSuccessTitle: "Compte créé !", toastSuccessDesc: "Vérifiez votre boîte mail avant de vous connecter.",
    pwRules: [
      "Au moins 8 caractères",
      "Une lettre majuscule (A–Z)",
      "Une lettre minuscule (a–z)",
      "Un chiffre (0–9)",
    ],
  },
  verifyEmail: {
    titlePending: "Vérifiez votre e-mail", titleDone: "E-mail vérifié !",
    descDone: "Redirection vers la connexion…", descVerifying: "Vérification en cours…",
    descPendingPrefix: "Nous avons envoyé un lien de vérification à", descPendingSuffix: ". Cliquez sur le lien pour activer votre compte.",
    descGeneric: "Nous avons envoyé un lien de vérification à votre adresse e-mail. Cliquez dessus pour activer votre compte.",
    inactiveWarning: "Votre compte reste inactif jusqu'à la vérification de votre e-mail.",
    resendBtn: "Renvoyer l'e-mail de vérification", resentBtn: "E-mail envoyé !",
    backToSignIn: "Retour à la connexion",
    toastVerifiedTitle: "E-mail vérifié !", toastVerifiedDesc: "Vous pouvez maintenant vous connecter.",
    toastFailTitle: "Échec de la vérification", toastFailDefault: "Lien invalide ou expiré.",
    toastNetworkTitle: "Erreur réseau", toastNetworkDesc: "Impossible de vérifier l'e-mail.",
    toastResendTitle: "E-mail de vérification envoyé",
    toastNoPendingTitle: "Aucun e-mail en attente", toastNoPendingDesc: "Veuillez vous inscrire à nouveau.",
  },
  profile: {
    pageTitle: "Profil",
    changePhoto: "Changer la photo",
    personalTitle: "Informations personnelles", personalDesc: "Mettez à jour vos informations personnelles.",
    editBtn: "Modifier le profil", saveBtn: "Enregistrer", cancelBtn: "Annuler",
    nameLabel: "Nom complet", emailLabel: "Adresse e-mail",
    verifiedBadge: "Vérifié",
    dangerTitle: "Zone dangereuse", dangerDesc: "Supprimez définitivement votre compte et toutes vos données.",
    dangerBody: "Une fois votre compte supprimé, il n'est pas possible de revenir en arrière. Veuillez être certain.",
    deleteBtn: "Supprimer le compte",
    confirmTitle: "Êtes-vous absolument sûr ?",
    confirmDesc: "Cette action est irréversible. Toutes vos données, journaux de sessions et configurations cloud seront définitivement supprimés.",
    confirmCancel: "Annuler", confirmDelete: "Oui, supprimer le compte",
    toastUpdated: "Profil mis à jour", toastUpdatedDesc: "Vos informations ont été enregistrées.",
    toastPhoto: "Photo de profil mise à jour", toastPhotoDesc: "Nouvel avatar défini.",
    toastDeleted: "Compte supprimé", toastDeletedDesc: "Vous avez été déconnecté.",
  },
  settings: {
    pageTitle: "Paramètres",
    securityTitle: "Sécurité du compte", securityDesc: "Gérez la sécurité de votre compte.",
    twoFaLabel: "Authentification à deux facteurs", twoFaDesc: "Ajoutez une couche de sécurité supplémentaire via une application d'authentification.",
    enabled: "Activée", disabled: "Désactivée",
    sessionsLabel: "Sessions actives", sessionsDesc: "Gérez les appareils connectés à votre compte.",
    viewDevicesBtn: "Voir les appareils",
    devicesTitle: "Appareils actifs", devicesDesc: "Consultez et révoquez les appareils connectés.",
    noDevices: "Aucun appareil actif.",
    passwordTitle: "Changer le mot de passe", passwordDesc: "Mettez à jour votre mot de passe. Doit respecter toutes les exigences.",
    currentPw: "Mot de passe actuel", newPw: "Nouveau mot de passe", confirmPw: "Confirmer le nouveau mot de passe",
    updatePwBtn: "Mettre à jour le mot de passe",
    pwRules: [
      "Au moins 12 caractères",
      "Une lettre majuscule (A–Z)",
      "Une lettre minuscule (a–z)",
      "Un chiffre (0–9)",
      "Un caractère spécial (!@#$…)",
    ],
    toastPwTitle: "Mot de passe mis à jour", toastPwDesc: "Votre mot de passe a été modifié.",
    toastSecTitle: "Sécurité mise à jour", toastSecEnabled: "Authentification à deux facteurs activée.", toastSecDisabled: "Authentification à deux facteurs désactivée.",
    toastRevokeTitle: "Appareil révoqué", toastRevokeDesc: "La session a été terminée.",
  },
  faq: {
    title: "Foire aux questions",
    items: [
      { q: "Qu'est-ce qu'OREXUP Cloud ?", a: "OREXUP Cloud est une plateforme de performance navigateur qui délègue les workloads lourds — rendu WebGL, exécution Wasm, tâches intensives en données — à des environnements cloud optimisés, pour que votre machine locale reste rapide." },
      { q: "Comment fonctionne la connexion navigateur ?", a: "Installez l'extension OREXUP, connectez-vous, et vos sessions navigateur sont automatiquement acheminées via nos nœuds cloud. Aucune configuration complexe requise." },
      { q: "Puis-je annuler mon abonnement à tout moment ?", a: "Oui. Vous pouvez annuler à tout moment depuis vos paramètres de facturation. Votre forfait reste actif jusqu'à la fin de la période en cours, sans frais supplémentaires." },
      { q: "Quels navigateurs et plateformes sont pris en charge ?", a: "Nous supportons actuellement Chrome, Firefox et Edge sur Windows, macOS et Linux. La prise en charge des navigateurs mobiles est dans notre feuille de route." },
      { q: "Y a-t-il un essai gratuit ?", a: "Nous ne proposons pas d'essai classique, mais chaque forfait bénéficie d'une garantie de remboursement de 30 jours — sans questions." },
    ],
  },
};

/* ─── SPANISH ─── */
const es: Translations = {
  nav: { signIn: "Iniciar sesión", signUp: "Registrarse" },
  footer: {
    tagline: "Conecta tu navegador y accede a entornos cloud optimizados para tareas exigentes.",
    company: "Empresa", aboutUs: "Sobre nosotros", blog: "Blog", careers: "Empleos", support: "Soporte",
    legal: "Legal", privacy: "Política de privacidad", terms: "Términos de servicio", cookies: "Política de cookies", security: "Seguridad",
    copyright: "OREXUP Cloud Platform. Todos los derechos reservados.",
  },
  home: {
    heroTitle: "Ejecuta cargas pesadas en el navegador con", heroTitleHighlight: "OREXUP Cloud",
    heroCta: "Conectar OREXUP Cloud",
    demoTitle: "Véalo en acción",
    demoSubtitle: "Mira cómo OREXUP enruta tus cargas del navegador a la nube en tiempo real.",
    featuresTitle: "Características", featuresSubtitle: "Diseñado para un rendimiento absoluto.",
    features: [
      { title: "Sesiones Cloud",              desc: "Crea entornos aislados al instante con asignaciones dedicadas de RAM y CPU." },
      { title: "Métricas de rendimiento",     desc: "Telemetría en tiempo real: carga de red, tiempos de fotograma y uso del heap." },
      { title: "Optimización del navegador",  desc: "Inyección automática de flags y ajustes de motor para cargas WebGL y Wasm." },
      { title: "Perfiles de rendimiento IA",  desc: "Redistribución dinámica de recursos basada en análisis predictivo de cargas." },
    ],
    pricingTitle: "Precios", monthly: "Mensual", annual: "Anual", save: "Ahorra 20 %",
    includes: "Incluye:",
    starterName: "Inicial",   starterDesc: "Para comenzar",                 starterFeature: "120 horas / mes",
    premiumName: "Premium",   premiumDesc: "Para desarrolladores pro",       premiumFeature: "240 horas / mes",
    ultimateName: "Ultimate", ultimateDesc: "Para usuarios avanzados",       ultimateFeature: "Uso ilimitado",
    connectCta: "Conectar OREXUP Cloud",
    year: "año", month: "mes",
  },
  signIn: {
    title: "Iniciar sesión", desc: "Accede a tus entornos cloud.",
    emailLabel: "Correo electrónico", passwordLabel: "Contraseña",
    forgotBtn: "¿Olvidaste tu contraseña?",
    submitBtn: "Iniciar sesión", submittingBtn: "Iniciando sesión…",
    noAccount: "¿No tienes cuenta?", signUpLink: "Registrarse",
    unverifiedMsg: "Por favor, verifica tu correo primero.", resendLink: "Reenviar verificación",
    toastFailTitle: "Error al iniciar sesión", toastSuccessTitle: "Sesión iniciada", toastSuccessDesc: "Bienvenido a OREXUP.",
    forgotTitle: "Restablecer contraseña", forgotDesc: "Ingresa tu correo y te enviaremos un enlace de restablecimiento.",
    forgotSentTitle: "¡Enlace enviado!", forgotSentDesc: "Si existe una cuenta para", forgotDoneBtn: "Listo",
    forgotSendBtn: "Enviar enlace", forgotSendingBtn: "Enviando…",
  },
  signUp: {
    title: "Crear cuenta", desc: "Ingresa tus datos para comenzar con OREXUP.",
    nameLabel: "Nombre completo", emailLabel: "Correo electrónico", passwordLabel: "Contraseña",
    submitBtn: "Crear cuenta", submittingBtn: "Creando cuenta…",
    hasAccount: "¿Ya tienes una cuenta?", signInLink: "Iniciar sesión",
    toastFailTitle: "Error al registrarse", toastSuccessTitle: "¡Cuenta creada!", toastSuccessDesc: "Revisa tu bandeja de entrada para verificar tu correo.",
    pwRules: [
      "Al menos 8 caracteres",
      "Una letra mayúscula (A–Z)",
      "Una letra minúscula (a–z)",
      "Un número (0–9)",
    ],
  },
  verifyEmail: {
    titlePending: "Verifica tu correo", titleDone: "¡Correo verificado!",
    descDone: "Redirigiendo al inicio de sesión…", descVerifying: "Verificando tu correo…",
    descPendingPrefix: "Enviamos un enlace de verificación a", descPendingSuffix: ". Haz clic en el enlace para activar tu cuenta.",
    descGeneric: "Enviamos un enlace de verificación a tu correo. Haz clic en él para activar tu cuenta.",
    inactiveWarning: "Tu cuenta permanece inactiva hasta que completes la verificación de correo.",
    resendBtn: "Reenviar correo de verificación", resentBtn: "¡Correo enviado!",
    backToSignIn: "Volver al inicio de sesión",
    toastVerifiedTitle: "¡Correo verificado!", toastVerifiedDesc: "Ya puedes iniciar sesión.",
    toastFailTitle: "Error de verificación", toastFailDefault: "Enlace inválido o expirado.",
    toastNetworkTitle: "Error de red", toastNetworkDesc: "No se pudo verificar el correo.",
    toastResendTitle: "Correo de verificación enviado",
    toastNoPendingTitle: "Sin correo pendiente", toastNoPendingDesc: "Por favor, regístrate de nuevo.",
  },
  profile: {
    pageTitle: "Perfil",
    changePhoto: "Cambiar foto",
    personalTitle: "Información personal", personalDesc: "Actualiza tus datos personales aquí.",
    editBtn: "Editar perfil", saveBtn: "Guardar cambios", cancelBtn: "Cancelar",
    nameLabel: "Nombre completo", emailLabel: "Correo electrónico",
    verifiedBadge: "Verificado",
    dangerTitle: "Zona peligrosa", dangerDesc: "Elimina permanentemente tu cuenta y todos tus datos.",
    dangerBody: "Una vez eliminada tu cuenta, no hay vuelta atrás. Por favor, asegúrate.",
    deleteBtn: "Eliminar cuenta",
    confirmTitle: "¿Estás completamente seguro?",
    confirmDesc: "Esta acción no se puede deshacer. Todos tus datos, registros de sesiones y configuraciones cloud se eliminarán permanentemente.",
    confirmCancel: "Cancelar", confirmDelete: "Sí, eliminar cuenta",
    toastUpdated: "Perfil actualizado", toastUpdatedDesc: "Tus datos han sido guardados.",
    toastPhoto: "Foto de perfil actualizada", toastPhotoDesc: "Nuevo avatar establecido.",
    toastDeleted: "Cuenta eliminada", toastDeletedDesc: "Has cerrado sesión.",
  },
  settings: {
    pageTitle: "Configuración",
    securityTitle: "Seguridad de la cuenta", securityDesc: "Gestiona cómo proteges tu cuenta.",
    twoFaLabel: "Autenticación en dos pasos", twoFaDesc: "Añade una capa extra de seguridad usando una app de autenticación.",
    enabled: "Activada", disabled: "Desactivada",
    sessionsLabel: "Sesiones activas", sessionsDesc: "Gestiona los dispositivos conectados a tu cuenta.",
    viewDevicesBtn: "Ver dispositivos",
    devicesTitle: "Dispositivos activos", devicesDesc: "Revisa y revoca el acceso a dispositivos conectados.",
    noDevices: "Sin dispositivos activos.",
    passwordTitle: "Cambiar contraseña", passwordDesc: "Actualiza tu contraseña. Debe cumplir todos los requisitos.",
    currentPw: "Contraseña actual", newPw: "Nueva contraseña", confirmPw: "Confirmar nueva contraseña",
    updatePwBtn: "Actualizar contraseña",
    pwRules: [
      "Al menos 12 caracteres",
      "Una letra mayúscula (A–Z)",
      "Una letra minúscula (a–z)",
      "Un número (0–9)",
      "Un carácter especial (!@#$…)",
    ],
    toastPwTitle: "Contraseña actualizada", toastPwDesc: "Tu contraseña ha sido cambiada.",
    toastSecTitle: "Seguridad actualizada", toastSecEnabled: "Autenticación en dos pasos activada.", toastSecDisabled: "Autenticación en dos pasos desactivada.",
    toastRevokeTitle: "Dispositivo revocado", toastRevokeDesc: "La sesión ha sido terminada.",
  },
  faq: {
    title: "Preguntas frecuentes",
    items: [
      { q: "¿Qué es OREXUP Cloud?", a: "OREXUP Cloud es una plataforma de rendimiento para navegadores que traslada cargas pesadas —renderizado WebGL, ejecución Wasm y tareas intensivas en datos— a entornos cloud optimizados, para que tu máquina local siga siendo rápida." },
      { q: "¿Cómo funciona la conexión del navegador?", a: "Instala la extensión OREXUP, inicia sesión y tus sesiones de navegador se enrutan automáticamente a través de nuestros nodos en la nube. No se requiere configuración compleja." },
      { q: "¿Puedo cancelar mi suscripción en cualquier momento?", a: "Sí. Puedes cancelar en cualquier momento desde la configuración de facturación. Tu plan permanece activo hasta el final del período de facturación actual sin cargos adicionales." },
      { q: "¿Qué navegadores y plataformas son compatibles?", a: "Actualmente soportamos Chrome, Firefox y Edge en Windows, macOS y Linux. La compatibilidad con navegadores móviles está en nuestra hoja de ruta." },
      { q: "¿Hay una prueba gratuita?", a: "No ofrecemos una prueba tradicional, pero cada plan incluye una garantía de devolución de dinero de 30 días, sin preguntas." },
    ],
  },
};

/* ─── ARABIC ─── */
const ar: Translations = {
  nav: { signIn: "تسجيل الدخول", signUp: "إنشاء حساب" },
  footer: {
    tagline: "اربط متصفحك وادخل إلى بيئات سحابية محسّنة للمهام المتطلبة.",
    company: "الشركة", aboutUs: "من نحن", blog: "المدونة", careers: "وظائف", support: "الدعم",
    legal: "قانوني", privacy: "سياسة الخصوصية", terms: "شروط الخدمة", cookies: "سياسة الكوكيز", security: "الأمان",
    copyright: "OREXUP Cloud Platform. جميع الحقوق محفوظة.",
  },
  home: {
    heroTitle: "شغّل أحمال المتصفح الثقيلة مع", heroTitleHighlight: "OREXUP Cloud",
    heroCta: "ربط OREXUP Cloud",
    demoTitle: "شاهده في العمل",
    demoSubtitle: "اكتشف كيف يوجّه OREXUP أحمال متصفحك إلى السحابة في الوقت الفعلي.",
    featuresTitle: "المميزات", featuresSubtitle: "مصمّم لأداء مطلق.",
    features: [
      { title: "جلسات سحابية",            desc: "أنشئ بيئات معزولة فوراً مع تخصيص مخصص للذاكرة ووحدة المعالجة المركزية." },
      { title: "مقاييس الأداء",           desc: "قياسات آنية لعبء الشبكة وأوقات الإطارات واستخدام الكومة." },
      { title: "تحسين المتصفح",           desc: "حقن تلقائي للعلامات وتعديلات المحرك لأحمال WebGL وWasm الثقيلة." },
      { title: "ملفات أداء ذكاء اصطناعي", desc: "توزيع ديناميكي للموارد استناداً إلى تحليل تنبؤي للأحمال." },
    ],
    pricingTitle: "الأسعار", monthly: "شهري", annual: "سنوي", save: "وفّر 20%",
    includes: "يشمل:",
    starterName: "مبتدئ",  starterDesc: "للبداية",                   starterFeature: "120 ساعة / شهر",
    premiumName: "مميّز",  premiumDesc: "للمطورين المحترفين",          premiumFeature: "240 ساعة / شهر",
    ultimateName: "أقصى", ultimateDesc: "للمستخدمين المتقدمين",       ultimateFeature: "استخدام غير محدود",
    connectCta: "ربط OREXUP Cloud",
    year: "سنة", month: "شهر",
  },
  signIn: {
    title: "تسجيل الدخول", desc: "ادخل إلى بيئاتك السحابية.",
    emailLabel: "البريد الإلكتروني", passwordLabel: "كلمة المرور",
    forgotBtn: "نسيت كلمة المرور؟",
    submitBtn: "تسجيل الدخول", submittingBtn: "جارٍ تسجيل الدخول…",
    noAccount: "ليس لديك حساب؟", signUpLink: "إنشاء حساب",
    unverifiedMsg: "يرجى التحقق من بريدك الإلكتروني أولاً.", resendLink: "إعادة إرسال التحقق",
    toastFailTitle: "فشل تسجيل الدخول", toastSuccessTitle: "تم تسجيل الدخول", toastSuccessDesc: "مرحباً بك في OREXUP.",
    forgotTitle: "إعادة تعيين كلمة المرور", forgotDesc: "أدخل بريدك الإلكتروني وسنرسل لك رابط إعادة التعيين.",
    forgotSentTitle: "تم إرسال الرابط!", forgotSentDesc: "إذا كان هناك حساب لـ", forgotDoneBtn: "تم",
    forgotSendBtn: "إرسال الرابط", forgotSendingBtn: "جارٍ الإرسال…",
  },
  signUp: {
    title: "إنشاء حساب", desc: "أدخل بياناتك للبدء مع OREXUP.",
    nameLabel: "الاسم الكامل", emailLabel: "البريد الإلكتروني", passwordLabel: "كلمة المرور",
    submitBtn: "إنشاء حساب", submittingBtn: "جارٍ إنشاء الحساب…",
    hasAccount: "لديك حساب بالفعل؟", signInLink: "تسجيل الدخول",
    toastFailTitle: "فشل التسجيل", toastSuccessTitle: "تم إنشاء الحساب!", toastSuccessDesc: "تحقق من بريدك الإلكتروني قبل تسجيل الدخول.",
    pwRules: [
      "8 أحرف على الأقل",
      "حرف كبير واحد (A–Z)",
      "حرف صغير واحد (a–z)",
      "رقم واحد (0–9)",
    ],
  },
  verifyEmail: {
    titlePending: "تحقق من بريدك الإلكتروني", titleDone: "تم التحقق من البريد!",
    descDone: "جارٍ إعادة التوجيه لتسجيل الدخول…", descVerifying: "جارٍ التحقق من بريدك…",
    descPendingPrefix: "أرسلنا رابط تحقق إلى", descPendingSuffix: ". انقر على الرابط لتفعيل حسابك.",
    descGeneric: "أرسلنا رابط تحقق إلى بريدك الإلكتروني. انقر عليه لتفعيل حسابك.",
    inactiveWarning: "يظل حسابك غير نشط حتى اكتمال التحقق من البريد الإلكتروني.",
    resendBtn: "إعادة إرسال رابط التحقق", resentBtn: "تم إرسال البريد!",
    backToSignIn: "العودة لتسجيل الدخول",
    toastVerifiedTitle: "تم التحقق من البريد!", toastVerifiedDesc: "يمكنك الآن تسجيل الدخول.",
    toastFailTitle: "فشل التحقق", toastFailDefault: "الرابط غير صالح أو منتهي الصلاحية.",
    toastNetworkTitle: "خطأ في الشبكة", toastNetworkDesc: "تعذّر التحقق من البريد الإلكتروني.",
    toastResendTitle: "تم إرسال بريد التحقق",
    toastNoPendingTitle: "لا يوجد بريد معلّق", toastNoPendingDesc: "يرجى التسجيل مجدداً.",
  },
  profile: {
    pageTitle: "الملف الشخصي",
    changePhoto: "تغيير الصورة",
    personalTitle: "المعلومات الشخصية", personalDesc: "حدّث بياناتك الشخصية هنا.",
    editBtn: "تعديل الملف", saveBtn: "حفظ التغييرات", cancelBtn: "إلغاء",
    nameLabel: "الاسم الكامل", emailLabel: "البريد الإلكتروني",
    verifiedBadge: "موثّق",
    dangerTitle: "منطقة الخطر", dangerDesc: "احذف حسابك وجميع بياناتك نهائياً.",
    dangerBody: "بمجرد حذف حسابك لا يمكن التراجع. تأكد من قرارك.",
    deleteBtn: "حذف الحساب",
    confirmTitle: "هل أنت متأكد تماماً؟",
    confirmDesc: "هذا الإجراء لا يمكن التراجع عنه. ستُحذف جميع بياناتك وسجلات الجلسات والإعدادات السحابية نهائياً.",
    confirmCancel: "إلغاء", confirmDelete: "نعم، احذف الحساب",
    toastUpdated: "تم تحديث الملف", toastUpdatedDesc: "تم حفظ بياناتك بنجاح.",
    toastPhoto: "تم تحديث الصورة", toastPhotoDesc: "تم تعيين الصورة الرمزية الجديدة.",
    toastDeleted: "تم حذف الحساب", toastDeletedDesc: "تم تسجيل خروجك.",
  },
  settings: {
    pageTitle: "الإعدادات",
    securityTitle: "أمان الحساب", securityDesc: "إدارة أمان حسابك.",
    twoFaLabel: "المصادقة الثنائية", twoFaDesc: "أضف طبقة أمان إضافية باستخدام تطبيق المصادقة.",
    enabled: "مفعّلة", disabled: "معطّلة",
    sessionsLabel: "الجلسات النشطة", sessionsDesc: "إدارة الأجهزة المتصلة بحسابك.",
    viewDevicesBtn: "عرض الأجهزة",
    devicesTitle: "الأجهزة النشطة", devicesDesc: "راجع الأجهزة المتصلة وأوقف وصولها.",
    noDevices: "لا توجد أجهزة نشطة.",
    passwordTitle: "تغيير كلمة المرور", passwordDesc: "حدّث كلمة مرورك. يجب استيفاء جميع المتطلبات.",
    currentPw: "كلمة المرور الحالية", newPw: "كلمة المرور الجديدة", confirmPw: "تأكيد كلمة المرور الجديدة",
    updatePwBtn: "تحديث كلمة المرور",
    pwRules: [
      "12 حرفاً على الأقل",
      "حرف كبير واحد (A–Z)",
      "حرف صغير واحد (a–z)",
      "رقم واحد (0–9)",
      "رمز خاص واحد (!@#$…)",
    ],
    toastPwTitle: "تم تحديث كلمة المرور", toastPwDesc: "تم تغيير كلمة مرورك بنجاح.",
    toastSecTitle: "تم تحديث الأمان", toastSecEnabled: "تم تفعيل المصادقة الثنائية.", toastSecDisabled: "تم تعطيل المصادقة الثنائية.",
    toastRevokeTitle: "تم إلغاء الجهاز", toastRevokeDesc: "تم إنهاء الجلسة.",
  },
  faq: {
    title: "الأسئلة الشائعة",
    items: [
      { q: "ما هو OREXUP Cloud؟", a: "OREXUP Cloud منصة أداء للمتصفح تنقل الأحمال الثقيلة — تصيير WebGL وتنفيذ Wasm والمهام كثيفة البيانات — إلى بيئات سحابية محسّنة، حتى يظل جهازك المحلي سريعاً." },
      { q: "كيف تعمل اتصال المتصفح؟", a: "ثبّت امتداد OREXUP وسجّل الدخول، وستُوجَّه جلسات متصفحك تلقائياً عبر عقدنا السحابية. لا يلزم أي إعداد معقد." },
      { q: "هل يمكنني إلغاء اشتراكي في أي وقت؟", a: "نعم. يمكنك الإلغاء في أي وقت من إعدادات الفوترة. يبقى اشتراكك نشطاً حتى نهاية فترة الفوترة الحالية دون رسوم إضافية." },
      { q: "ما المتصفحات والمنصات المدعومة؟", a: "ندعم حالياً Chrome وFirefox وEdge على Windows وmacOS وLinux. دعم متصفحات الجوّال قادم قريباً." },
      { q: "هل يوجد تجربة مجانية؟", a: "لا نقدم تجربة تقليدية، لكن كل خطة تأتي بضمان استرداد المال لمدة 30 يوماً دون أي أسئلة." },
    ],
  },
};

/* ─── DUTCH ─── */
const nl: Translations = {
  nav: { signIn: "Inloggen", signUp: "Registreren" },
  footer: {
    tagline: "Verbind je browser en krijg toegang tot geoptimaliseerde cloudomgevingen voor veeleisende taken.",
    company: "Bedrijf", aboutUs: "Over ons", blog: "Blog", careers: "Vacatures", support: "Ondersteuning",
    legal: "Juridisch", privacy: "Privacybeleid", terms: "Gebruiksvoorwaarden", cookies: "Cookiebeleid", security: "Beveiliging",
    copyright: "OREXUP Cloud Platform. Alle rechten voorbehouden.",
  },
  home: {

    heroTitle: "Voer zware browsertaken uit met", heroTitleHighlight: "OREXUP Cloud",
    heroCta: "Verbinden met OREXUP Cloud",
    demoTitle: "Bekijk het in actie",
    demoSubtitle: "Zie hoe OREXUP jouw browsertaken in realtime naar de cloud stuurt.",
    featuresTitle: "Functies", featuresSubtitle: "Ontworpen voor absolute prestaties.",
    features: [
      { title: "Cloudsessies",            desc: "Spin onmiddellijk geïsoleerde omgevingen op met toegewezen RAM en CPU." },
      { title: "Prestatiestatistieken",   desc: "Realtime telemetrie voor netwerkoverhead, frametijden en heapgebruik." },
      { title: "Browseroptimalisatie",    desc: "Automatische vlaggeninjectie en motoraanpassingen voor zware WebGL- en Wasm-taken." },
      { title: "AI-prestatieprofielen",   desc: "Dynamische herverdeling van resources op basis van voorspellende workloadanalyse." },
    ],
    pricingTitle: "Prijzen", monthly: "Maandelijks", annual: "Jaarlijks", save: "Bespaar 20%",
    includes: "Inclusief:",
    starterName: "Starter",  starterDesc: "Om te beginnen",                   starterFeature: "120 uur / maand",
    premiumName: "Premium",  premiumDesc: "Voor professionele ontwikkelaars",  premiumFeature: "240 uur / maand",
    ultimateName: "Ultiem",  ultimateDesc: "Voor gevorderde gebruikers",       ultimateFeature: "Onbeperkt gebruik",
    connectCta: "Verbinden met OREXUP Cloud",
    year: "jaar", month: "maand",
  },
  signIn: {
    title: "Inloggen", desc: "Toegang tot jouw cloudomgevingen.",
    emailLabel: "E-mail", passwordLabel: "Wachtwoord",
    forgotBtn: "Wachtwoord vergeten?",
    submitBtn: "Inloggen", submittingBtn: "Bezig met inloggen…",
    noAccount: "Nog geen account?", signUpLink: "Registreren",
    unverifiedMsg: "Verifieer eerst je e-mail.", resendLink: "Verificatie opnieuw sturen",
    toastFailTitle: "Inloggen mislukt", toastSuccessTitle: "Succesvol ingelogd", toastSuccessDesc: "Welkom bij OREXUP.",
    forgotTitle: "Wachtwoord opnieuw instellen", forgotDesc: "Voer je e-mailadres in en we sturen je een resetlink.",
    forgotSentTitle: "Resetlink verzonden!", forgotSentDesc: "Als er een account bestaat voor", forgotDoneBtn: "Klaar",
    forgotSendBtn: "Resetlink versturen", forgotSendingBtn: "Versturen…",
  },
  signUp: {
    title: "Account aanmaken", desc: "Voer je gegevens in om te beginnen met OREXUP.",
    nameLabel: "Volledige naam", emailLabel: "E-mail", passwordLabel: "Wachtwoord",
    submitBtn: "Account aanmaken", submittingBtn: "Account aanmaken…",
    hasAccount: "Heb je al een account?", signInLink: "Inloggen",
    toastFailTitle: "Registratie mislukt", toastSuccessTitle: "Account aangemaakt!", toastSuccessDesc: "Controleer je inbox om je e-mail te verifiëren.",
    pwRules: [
      "Minimaal 8 tekens",
      "Één hoofdletter (A–Z)",
      "Één kleine letter (a–z)",
      "Één cijfer (0–9)",
    ],
  },
  verifyEmail: {
    titlePending: "Verifieer je e-mail", titleDone: "E-mail geverifieerd!",
    descDone: "Je wordt doorgestuurd naar inloggen…", descVerifying: "E-mail verifiëren…",
    descPendingPrefix: "We hebben een verificatielink gestuurd naar", descPendingSuffix: ". Klik op de link om je account te activeren.",
    descGeneric: "We hebben een verificatielink naar je e-mailadres gestuurd. Klik erop om je account te activeren.",
    inactiveWarning: "Je account blijft inactief totdat de e-mailverificatie is voltooid.",
    resendBtn: "Verificatie-e-mail opnieuw sturen", resentBtn: "E-mail verzonden!",
    backToSignIn: "Terug naar inloggen",
    toastVerifiedTitle: "E-mail geverifieerd!", toastVerifiedDesc: "Je kunt nu inloggen.",
    toastFailTitle: "Verificatie mislukt", toastFailDefault: "Ongeldige of verlopen link.",
    toastNetworkTitle: "Netwerkfout", toastNetworkDesc: "E-mail kon niet worden geverifieerd.",
    toastResendTitle: "Verificatie-e-mail verzonden",
    toastNoPendingTitle: "Geen e-mail in behandeling", toastNoPendingDesc: "Registreer je opnieuw.",
  },
  profile: {
    pageTitle: "Profiel",
    changePhoto: "Foto wijzigen",
    personalTitle: "Persoonlijke gegevens", personalDesc: "Werk hier je persoonlijke gegevens bij.",
    editBtn: "Profiel bewerken", saveBtn: "Wijzigingen opslaan", cancelBtn: "Annuleren",
    nameLabel: "Volledige naam", emailLabel: "E-mailadres",
    verifiedBadge: "Geverifieerd",
    dangerTitle: "Gevarenzone", dangerDesc: "Verwijder je account en alle gegevens permanent.",
    dangerBody: "Zodra je account is verwijderd, is er geen weg terug. Wees zeker van je beslissing.",
    deleteBtn: "Account verwijderen",
    confirmTitle: "Weet je het zeker?",
    confirmDesc: "Deze actie kan niet ongedaan worden gemaakt. Al je gegevens, sessielogboeken en cloudconfiguraties worden permanent verwijderd.",
    confirmCancel: "Annuleren", confirmDelete: "Ja, account verwijderen",
    toastUpdated: "Profiel bijgewerkt", toastUpdatedDesc: "Je gegevens zijn succesvol opgeslagen.",
    toastPhoto: "Profielfoto bijgewerkt", toastPhotoDesc: "Nieuwe avatar ingesteld.",
    toastDeleted: "Account verwijderd", toastDeletedDesc: "Je bent uitgelogd.",
  },
  settings: {
    pageTitle: "Instellingen",
    securityTitle: "Accountbeveiliging", securityDesc: "Beheer de beveiliging van je account.",
    twoFaLabel: "Tweefactorauthenticatie", twoFaDesc: "Voeg een extra beveiligingslaag toe via een authenticatie-app.",
    enabled: "Ingeschakeld", disabled: "Uitgeschakeld",
    sessionsLabel: "Actieve sessies", sessionsDesc: "Beheer apparaten die momenteel zijn ingelogd op je account.",
    viewDevicesBtn: "Apparaten bekijken",
    devicesTitle: "Actieve apparaten", devicesDesc: "Bekijk en trek toegang in voor ingelogde apparaten.",
    noDevices: "Geen actieve apparaten.",
    passwordTitle: "Wachtwoord wijzigen", passwordDesc: "Werk je wachtwoord bij. Moet aan alle vereisten voldoen.",
    currentPw: "Huidig wachtwoord", newPw: "Nieuw wachtwoord", confirmPw: "Nieuw wachtwoord bevestigen",
    updatePwBtn: "Wachtwoord bijwerken",
    pwRules: [
      "Minimaal 12 tekens",
      "Één hoofdletter (A–Z)",
      "Één kleine letter (a–z)",
      "Één cijfer (0–9)",
      "Één speciaal teken (!@#$…)",
    ],
    toastPwTitle: "Wachtwoord bijgewerkt", toastPwDesc: "Je wachtwoord is succesvol gewijzigd.",
    toastSecTitle: "Beveiliging bijgewerkt", toastSecEnabled: "Tweefactorauthenticatie ingeschakeld.", toastSecDisabled: "Tweefactorauthenticatie uitgeschakeld.",
    toastRevokeTitle: "Apparaat ingetrokken", toastRevokeDesc: "De sessie is beëindigd.",
  },
  faq: {
    title: "Veelgestelde vragen",
    items: [
      { q: "Wat is OREXUP Cloud?", a: "OREXUP Cloud is een browserprestatieplatform dat zware workloads — WebGL-rendering, Wasm-uitvoering en data-intensieve taken — overdraagt aan geoptimaliseerde cloudomgevingen, zodat je lokale machine snel blijft." },
      { q: "Hoe werkt de browserverbinding?", a: "Installeer de OREXUP-extensie, log in en je browsersessies worden automatisch via onze cloudknooppunten gerouteerd. Geen complexe configuratie vereist." },
      { q: "Kan ik mijn abonnement op elk moment opzeggen?", a: "Ja. Je kunt op elk moment opzeggen via je factuurinstellingen. Je plan blijft actief tot het einde van de huidige factureringsperiode zonder extra kosten." },
      { q: "Welke browsers en platforms worden ondersteund?", a: "We ondersteunen momenteel Chrome, Firefox en Edge op Windows, macOS en Linux. Ondersteuning voor mobiele browsers staat op onze roadmap." },
      { q: "Is er een gratis proefperiode?", a: "We bieden geen traditionele proefperiode, maar elk plan heeft een 30 dagen geld-terug-garantie — geen vragen gesteld." },
    ],
  },
};

/* ─── CHINESE (SIMPLIFIED) ─── */
const zh: Translations = {
  nav: { signIn: "登录", signUp: "注册" },
  footer: {
    tagline: "连接您的浏览器，访问针对高需求任务优化的云端性能环境。",
    company: "公司", aboutUs: "关于我们", blog: "博客", careers: "招聘", support: "支持",
    legal: "法律", privacy: "隐私政策", terms: "服务条款", cookies: "Cookie 政策", security: "安全",
    copyright: "OREXUP 云平台。保留所有权利。",
  },
  home: {
    heroTitle: "使用", heroTitleHighlight: "OREXUP Cloud",
    heroCta: "连接 OREXUP Cloud",
    demoTitle: "实际演示",
    demoSubtitle: "查看 OREXUP 如何实时将您的浏览器工作负载路由到云端。",
    featuresTitle: "功能特性", featuresSubtitle: "专为极致性能而设计。",
    features: [
      { title: "云端会话",       desc: "即时启动具有专用 RAM 和 CPU 分配的隔离环境。" },
      { title: "性能指标",       desc: "实时遥测，跟踪网络开销、帧时间和堆内存使用情况。" },
      { title: "浏览器优化",     desc: "自动注入标志并针对 WebGL 和 Wasm 负载进行引擎调优。" },
      { title: "AI 性能配置文件", desc: "基于预测性工作负载分析的动态资源调配。" },
    ],
    pricingTitle: "定价", monthly: "按月", annual: "按年", save: "节省 20%",
    includes: "包含：",
    starterName: "入门版",  starterDesc: "适合入门使用",    starterFeature: "120 小时 / 月",
    premiumName: "专业版",  premiumDesc: "适合专业开发者",  premiumFeature: "240 小时 / 月",
    ultimateName: "旗舰版", ultimateDesc: "适合高级用户",   ultimateFeature: "无限使用时长",
    connectCta: "连接 OREXUP Cloud",
    year: "年", month: "月",
  },
  signIn: {
    title: "登录", desc: "访问您的云端环境。",
    emailLabel: "电子邮件", passwordLabel: "密码",
    forgotBtn: "忘记密码？",
    submitBtn: "登录", submittingBtn: "登录中…",
    noAccount: "还没有账户？", signUpLink: "注册",
    unverifiedMsg: "请先验证您的电子邮件。", resendLink: "重新发送验证邮件",
    toastFailTitle: "登录失败", toastSuccessTitle: "登录成功", toastSuccessDesc: "欢迎使用 OREXUP。",
    forgotTitle: "重置密码", forgotDesc: "输入您的账户邮箱，我们将发送重置链接。",
    forgotSentTitle: "重置链接已发送！", forgotSentDesc: "如果以下邮箱存在账户：", forgotDoneBtn: "完成",
    forgotSendBtn: "发送重置链接", forgotSendingBtn: "发送中…",
  },
  signUp: {
    title: "创建账户", desc: "填写您的信息，开始使用 OREXUP。",
    nameLabel: "全名", emailLabel: "电子邮件", passwordLabel: "密码",
    submitBtn: "创建账户", submittingBtn: "创建中…",
    hasAccount: "已有账户？", signInLink: "登录",
    toastFailTitle: "注册失败", toastSuccessTitle: "账户已创建！", toastSuccessDesc: "请查看收件箱以验证您的电子邮件。",
    pwRules: [
      "至少 8 个字符",
      "一个大写字母（A–Z）",
      "一个小写字母（a–z）",
      "一个数字（0–9）",
    ],
  },
  verifyEmail: {
    titlePending: "验证您的电子邮件", titleDone: "邮件已验证！",
    descDone: "正在跳转到登录页面…", descVerifying: "正在验证您的邮件…",
    descPendingPrefix: "我们已向", descPendingSuffix: "发送了验证链接，请点击邮件中的链接激活账户。",
    descGeneric: "我们已向您的电子邮件地址发送了验证链接，请点击激活账户。",
    inactiveWarning: "完成邮件验证之前，您的账户将保持未激活状态。",
    resendBtn: "重新发送验证邮件", resentBtn: "邮件已发送！",
    backToSignIn: "返回登录",
    toastVerifiedTitle: "邮件已验证！", toastVerifiedDesc: "您现在可以登录了。",
    toastFailTitle: "验证失败", toastFailDefault: "链接无效或已过期。",
    toastNetworkTitle: "网络错误", toastNetworkDesc: "无法验证电子邮件。",
    toastResendTitle: "验证邮件已发送",
    toastNoPendingTitle: "无待验证邮件", toastNoPendingDesc: "请重新注册。",
  },
  profile: {
    pageTitle: "个人资料",
    changePhoto: "更换照片",
    personalTitle: "个人信息", personalDesc: "在此更新您的个人详细信息。",
    editBtn: "编辑资料", saveBtn: "保存更改", cancelBtn: "取消",
    nameLabel: "全名", emailLabel: "电子邮件地址",
    verifiedBadge: "已验证",
    dangerTitle: "危险区域", dangerDesc: "永久删除您的账户及所有数据。",
    dangerBody: "删除账户后将无法恢复，请确认您的决定。",
    deleteBtn: "删除账户",
    confirmTitle: "您确定吗？",
    confirmDesc: "此操作无法撤销。您的所有数据、会话日志和云配置将被永久删除。",
    confirmCancel: "取消", confirmDelete: "是的，删除账户",
    toastUpdated: "资料已更新", toastUpdatedDesc: "您的信息已成功保存。",
    toastPhoto: "头像已更新", toastPhotoDesc: "新头像设置成功。",
    toastDeleted: "账户已删除", toastDeletedDesc: "您已退出登录。",
  },
  settings: {
    pageTitle: "设置",
    securityTitle: "账户安全", securityDesc: "管理您的账户安全设置。",
    twoFaLabel: "双因素认证", twoFaDesc: "通过身份验证器应用添加额外的安全保护。",
    enabled: "已启用", disabled: "已禁用",
    sessionsLabel: "活跃会话", sessionsDesc: "管理当前登录您账户的设备。",
    viewDevicesBtn: "查看设备",
    devicesTitle: "活跃设备", devicesDesc: "查看并撤销已登录设备的访问权限。",
    noDevices: "没有活跃设备。",
    passwordTitle: "修改密码", passwordDesc: "更新您的密码，必须满足所有复杂性要求。",
    currentPw: "当前密码", newPw: "新密码", confirmPw: "确认新密码",
    updatePwBtn: "更新密码",
    pwRules: [
      "至少 12 个字符",
      "一个大写字母（A–Z）",
      "一个小写字母（a–z）",
      "一个数字（0–9）",
      "一个特殊字符（!@#$…）",
    ],
    toastPwTitle: "密码已更新", toastPwDesc: "您的密码已成功修改。",
    toastSecTitle: "安全设置已更新", toastSecEnabled: "双因素认证已启用。", toastSecDisabled: "双因素认证已禁用。",
    toastRevokeTitle: "设备已撤销", toastRevokeDesc: "会话已终止。",
  },
  faq: {
    title: "常见问题",
    items: [
      { q: "什么是 OREXUP Cloud？", a: "OREXUP Cloud 是一款浏览器性能平台，将繁重的工作负载——WebGL 渲染、Wasm 执行和数据密集型任务——卸载到优化的云端环境，让您的本地设备保持流畅。" },
      { q: "浏览器连接是如何工作的？", a: "安装 OREXUP 浏览器扩展并登录后，您的浏览器会话将自动通过我们的云节点路由。无需复杂配置。" },
      { q: "我可以随时取消订阅吗？", a: "是的。您可以随时在账单设置中取消订阅。您的套餐在当前计费周期结束前保持有效，不会产生额外费用。" },
      { q: "支持哪些浏览器和平台？", a: "我们目前支持 Windows、macOS 和 Linux 上的 Chrome、Firefox 和 Edge。移动浏览器支持已在我们的路线图中。" },
      { q: "有免费试用吗？", a: "我们不提供传统的试用期，但每个套餐均提供 30 天无条件退款保证。" },
    ],
  },
};

/* ─── GERMAN ─── */
const de: Translations = {
  nav: { signIn: "Anmelden", signUp: "Registrieren" },
  footer: {
    tagline: "Verbinden Sie Ihren Browser und greifen Sie auf optimierte Cloud-Umgebungen für anspruchsvolle Aufgaben zu.",
    company: "Unternehmen", aboutUs: "Über uns", blog: "Blog", careers: "Karriere", support: "Support",
    legal: "Rechtliches", privacy: "Datenschutzrichtlinie", terms: "Nutzungsbedingungen", cookies: "Cookie-Richtlinie", security: "Sicherheit",
    copyright: "OREXUP Cloud Platform. Alle Rechte vorbehalten.",
  },
  home: {
    heroTitle: "Führen Sie schwere Browser-Workloads aus mit", heroTitleHighlight: "OREXUP Cloud",
    heroCta: "Mit OREXUP Cloud verbinden",
    demoTitle: "In Aktion erleben",
    demoSubtitle: "Sehen Sie, wie OREXUP Ihre Browser-Workloads in Echtzeit in die Cloud leitet.",
    featuresTitle: "Funktionen", featuresSubtitle: "Entwickelt für absolute Leistung.",
    features: [
      { title: "Cloud-Sitzungen",          desc: "Starten Sie sofort isolierte Umgebungen mit dedizierter RAM- und CPU-Zuweisung." },
      { title: "Leistungsmetriken",        desc: "Echtzeit-Telemetrie für Netzwerkauslastung, Frametimes und Heap-Nutzung." },
      { title: "Browser-Optimierung",      desc: "Automatische Flag-Injektion und Engine-Anpassungen für schwere WebGL- und Wasm-Lasten." },
      { title: "KI-Leistungsprofile",      desc: "Dynamische Ressourcenverteilung auf Basis prädiktiver Workload-Analyse." },
    ],
    pricingTitle: "Preise", monthly: "Monatlich", annual: "Jährlich", save: "20 % sparen",
    includes: "Beinhaltet:",
    starterName: "Starter",    starterDesc: "Für den Einstieg",                  starterFeature: "120 Stunden / Monat",
    premiumName: "Premium",    premiumDesc: "Für professionelle Entwickler",      premiumFeature: "240 Stunden / Monat",
    ultimateName: "Ultimate",  ultimateDesc: "Für Power-User",                   ultimateFeature: "Unbegrenzte Nutzung",
    connectCta: "Mit OREXUP Cloud verbinden",
    year: "Jahr", month: "Monat",
  },
  signIn: {
    title: "Anmelden", desc: "Zugriff auf Ihre Cloud-Umgebungen.",
    emailLabel: "E-Mail", passwordLabel: "Passwort",
    forgotBtn: "Passwort vergessen?",
    submitBtn: "Anmelden", submittingBtn: "Anmeldung läuft…",
    noAccount: "Noch kein Konto?", signUpLink: "Registrieren",
    unverifiedMsg: "Bitte bestätigen Sie zuerst Ihre E-Mail.", resendLink: "Bestätigung erneut senden",
    toastFailTitle: "Anmeldung fehlgeschlagen", toastSuccessTitle: "Erfolgreich angemeldet", toastSuccessDesc: "Willkommen bei OREXUP.",
    forgotTitle: "Passwort zurücksetzen", forgotDesc: "Geben Sie Ihre E-Mail ein und wir senden Ihnen einen Reset-Link.",
    forgotSentTitle: "Reset-Link gesendet!", forgotSentDesc: "Falls ein Konto für", forgotDoneBtn: "Fertig",
    forgotSendBtn: "Reset-Link senden", forgotSendingBtn: "Wird gesendet…",
  },
  signUp: {
    title: "Konto erstellen", desc: "Geben Sie Ihre Daten ein, um mit OREXUP zu starten.",
    nameLabel: "Vollständiger Name", emailLabel: "E-Mail", passwordLabel: "Passwort",
    submitBtn: "Konto erstellen", submittingBtn: "Konto wird erstellt…",
    hasAccount: "Bereits ein Konto?", signInLink: "Anmelden",
    toastFailTitle: "Registrierung fehlgeschlagen", toastSuccessTitle: "Konto erstellt!", toastSuccessDesc: "Überprüfen Sie Ihren Posteingang, um Ihre E-Mail zu bestätigen.",
    pwRules: [
      "Mindestens 8 Zeichen",
      "Ein Großbuchstabe (A–Z)",
      "Ein Kleinbuchstabe (a–z)",
      "Eine Ziffer (0–9)",
    ],
  },
  verifyEmail: {
    titlePending: "E-Mail bestätigen", titleDone: "E-Mail bestätigt!",
    descDone: "Sie werden zur Anmeldung weitergeleitet…", descVerifying: "E-Mail wird bestätigt…",
    descPendingPrefix: "Wir haben einen Bestätigungslink an", descPendingSuffix: " gesendet. Klicken Sie auf den Link, um Ihr Konto zu aktivieren.",
    descGeneric: "Wir haben einen Bestätigungslink an Ihre E-Mail-Adresse gesendet. Klicken Sie darauf, um Ihr Konto zu aktivieren.",
    inactiveWarning: "Ihr Konto bleibt inaktiv, bis die E-Mail-Bestätigung abgeschlossen ist.",
    resendBtn: "Bestätigungs-E-Mail erneut senden", resentBtn: "E-Mail gesendet!",
    backToSignIn: "Zurück zur Anmeldung",
    toastVerifiedTitle: "E-Mail bestätigt!", toastVerifiedDesc: "Sie können sich jetzt anmelden.",
    toastFailTitle: "Bestätigung fehlgeschlagen", toastFailDefault: "Ungültiger oder abgelaufener Link.",
    toastNetworkTitle: "Netzwerkfehler", toastNetworkDesc: "E-Mail konnte nicht bestätigt werden.",
    toastResendTitle: "Bestätigungs-E-Mail gesendet",
    toastNoPendingTitle: "Keine ausstehende E-Mail", toastNoPendingDesc: "Bitte registrieren Sie sich erneut.",
  },
  profile: {
    pageTitle: "Profil",
    changePhoto: "Foto ändern",
    personalTitle: "Persönliche Daten", personalDesc: "Aktualisieren Sie hier Ihre persönlichen Daten.",
    editBtn: "Profil bearbeiten", saveBtn: "Änderungen speichern", cancelBtn: "Abbrechen",
    nameLabel: "Vollständiger Name", emailLabel: "E-Mail-Adresse",
    verifiedBadge: "Bestätigt",
    dangerTitle: "Gefahrenbereich", dangerDesc: "Löschen Sie Ihr Konto und alle Daten dauerhaft.",
    dangerBody: "Sobald Sie Ihr Konto löschen, gibt es kein Zurück. Bitte seien Sie sich sicher.",
    deleteBtn: "Konto löschen",
    confirmTitle: "Sind Sie absolut sicher?",
    confirmDesc: "Diese Aktion kann nicht rückgängig gemacht werden. Alle Ihre Daten, Sitzungsprotokolle und Cloud-Konfigurationen werden dauerhaft gelöscht.",
    confirmCancel: "Abbrechen", confirmDelete: "Ja, Konto löschen",
    toastUpdated: "Profil aktualisiert", toastUpdatedDesc: "Ihre Daten wurden erfolgreich gespeichert.",
    toastPhoto: "Profilfoto aktualisiert", toastPhotoDesc: "Neuer Avatar erfolgreich gesetzt.",
    toastDeleted: "Konto gelöscht", toastDeletedDesc: "Sie wurden abgemeldet.",
  },
  settings: {
    pageTitle: "Einstellungen",
    securityTitle: "Kontosicherheit", securityDesc: "Verwalten Sie die Sicherheit Ihres Kontos.",
    twoFaLabel: "Zwei-Faktor-Authentifizierung", twoFaDesc: "Fügen Sie eine zusätzliche Sicherheitsebene über eine Authentifikator-App hinzu.",
    enabled: "Aktiviert", disabled: "Deaktiviert",
    sessionsLabel: "Aktive Sitzungen", sessionsDesc: "Verwalten Sie Geräte, die derzeit bei Ihrem Konto angemeldet sind.",
    viewDevicesBtn: "Geräte anzeigen",
    devicesTitle: "Aktive Geräte", devicesDesc: "Überprüfen und widerrufen Sie den Zugriff auf angemeldete Geräte.",
    noDevices: "Keine aktiven Geräte.",
    passwordTitle: "Passwort ändern", passwordDesc: "Aktualisieren Sie Ihr Passwort. Muss alle Komplexitätsanforderungen erfüllen.",
    currentPw: "Aktuelles Passwort", newPw: "Neues Passwort", confirmPw: "Neues Passwort bestätigen",
    updatePwBtn: "Passwort aktualisieren",
    pwRules: [
      "Mindestens 12 Zeichen",
      "Ein Großbuchstabe (A–Z)",
      "Ein Kleinbuchstabe (a–z)",
      "Eine Ziffer (0–9)",
      "Ein Sonderzeichen (!@#$…)",
    ],
    toastPwTitle: "Passwort aktualisiert", toastPwDesc: "Ihr Passwort wurde erfolgreich geändert.",
    toastSecTitle: "Sicherheit aktualisiert", toastSecEnabled: "Zwei-Faktor-Authentifizierung aktiviert.", toastSecDisabled: "Zwei-Faktor-Authentifizierung deaktiviert.",
    toastRevokeTitle: "Gerät widerrufen", toastRevokeDesc: "Die Sitzung wurde beendet.",
  },
  faq: {
    title: "Häufig gestellte Fragen",
    items: [
      { q: "Was ist OREXUP Cloud?", a: "OREXUP Cloud ist eine Browser-Leistungsplattform, die aufwendige Workloads — WebGL-Rendering, Wasm-Ausführung und datenintensive Aufgaben — in optimierte Cloud-Umgebungen auslagert, damit Ihr lokales Gerät schnell bleibt." },
      { q: "Wie funktioniert die Browserverbindung?", a: "Installieren Sie die OREXUP-Browsererweiterung, melden Sie sich an, und Ihre Browsersitzungen werden automatisch über unsere Cloud-Knoten geleitet. Keine komplexe Konfiguration erforderlich." },
      { q: "Kann ich mein Abonnement jederzeit kündigen?", a: "Ja. Sie können jederzeit in Ihren Abrechnungseinstellungen kündigen. Ihr Plan bleibt bis zum Ende des aktuellen Abrechnungszeitraums ohne zusätzliche Kosten aktiv." },
      { q: "Welche Browser und Plattformen werden unterstützt?", a: "Wir unterstützen derzeit Chrome, Firefox und Edge auf Windows, macOS und Linux. Die Unterstützung für mobile Browser ist in unserer Roadmap." },
      { q: "Gibt es eine kostenlose Testversion?", a: "Wir bieten keine klassische Testversion an, aber jeder Plan enthält eine 30-tägige Geld-zurück-Garantie — ohne Fragen." },
    ],
  },
};

const DICT: Record<Locale, Translations> = { en, fr, es, ar, nl, zh, de };

interface I18nState {
  locale: Locale;
  t: Translations;
  setLocale: (l: Locale) => void;
  isRtl: boolean;
}

const I18nContext = createContext<I18nState | null>(null);

export function I18nProvider({ children }: { children: React.ReactNode }) {
  const [locale, setLocaleState] = useState<Locale>(() => {
    try { return (localStorage.getItem("orexup_locale") as Locale) ?? "en"; } catch { return "en"; }
  });

  const isRtl = LOCALES.find((l) => l.code === locale)?.rtl ?? false;

  useEffect(() => {
    document.documentElement.lang = locale;
    document.documentElement.dir = isRtl ? "rtl" : "ltr";
  }, [locale, isRtl]);

  const setLocale = (l: Locale) => {
    try { localStorage.setItem("orexup_locale", l); } catch {}
    setLocaleState(l);
  };

  return (
    <I18nContext.Provider value={{ locale, t: DICT[locale], setLocale, isRtl }}>
      {children}
    </I18nContext.Provider>
  );
}

export function useI18n(): I18nState {
  const ctx = useContext(I18nContext);
  if (!ctx) throw new Error("useI18n must be used within I18nProvider");
  return ctx;
}

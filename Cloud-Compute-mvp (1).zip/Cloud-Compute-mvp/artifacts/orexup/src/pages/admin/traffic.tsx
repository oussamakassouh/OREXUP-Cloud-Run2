import { AdminLayout } from "@/components/admin-layout";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { Monitor, Smartphone, Tablet, HardDrive } from "lucide-react";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useGetAdminTraffic } from "@workspace/api-client-react";
import { PeriodFilter, usePeriodFilter } from "@/components/period-filter";

const DEVICE_STYLES: Record<string, { icon: typeof Monitor; color: string; bg: string; bar: string }> = {
  Desktop: { icon: Monitor, color: "text-blue-500", bg: "bg-blue-500/10", bar: "bg-blue-500" },
  Mobile: { icon: Smartphone, color: "text-green-500", bg: "bg-green-500/10", bar: "bg-green-500" },
  Tablet: { icon: Tablet, color: "text-purple-500", bg: "bg-purple-500/10", bar: "bg-purple-500" },
};

export default function AdminTrafficPage() {
  const { period, setPeriod, customFrom, setCustomFrom, customTo, setCustomTo, apply, queryParams, label } =
    usePeriodFilter("week");

  const { data, isLoading, isError } = useGetAdminTraffic(queryParams);

  const visitsSeries = data?.visitsSeries ?? [];
  const topCountries = data?.topCountries ?? [];
  const devices = data?.devices ?? [];
  const activeSessionsList = data?.activeSessionsList ?? [];

  return (
    <AdminLayout title="Traffic & Sessions">
      <div className="space-y-6">
        {isError && (
          <Card className="border-red-500/20 bg-red-500/5">
            <CardContent className="py-4 text-sm text-red-400">Failed to load traffic data.</CardContent>
          </Card>
        )}

        <PeriodFilter
          period={period} onPeriodChange={setPeriod}
          customFrom={customFrom} customTo={customTo}
          onCustomFromChange={setCustomFrom} onCustomToChange={setCustomTo}
          onApply={apply}
        />

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <Card className="lg:col-span-2 border-white/5 bg-card/50">
            <CardHeader>
              <CardTitle>Page Visits</CardTitle>
              <CardDescription>{label}</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[300px] w-full">
                {visitsSeries.length === 0 ? (
                  <div className="h-full flex items-center justify-center text-muted-foreground text-sm">
                    {isLoading ? "Loading…" : "No data available"}
                  </div>
                ) : (
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={visitsSeries} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
                      <defs>
                        <linearGradient id="colorVisits" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.3}/>
                          <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0}/>
                        </linearGradient>
                      </defs>
                      <XAxis dataKey="time" stroke="#888888" fontSize={12} tickLine={false} axisLine={false} />
                      <YAxis stroke="#888888" fontSize={12} tickLine={false} axisLine={false} />
                      <CartesianGrid strokeDasharray="3 3" stroke="#333" vertical={false} />
                      <Tooltip
                        contentStyle={{ backgroundColor: '#111827', borderColor: '#1f2937', borderRadius: '8px' }}
                        itemStyle={{ color: 'hsl(var(--primary))' }}
                      />
                      <Area type="monotone" dataKey="visits" stroke="hsl(var(--primary))" fillOpacity={1} fill="url(#colorVisits)" />
                    </AreaChart>
                  </ResponsiveContainer>
                )}
              </div>
            </CardContent>
          </Card>

          <Card className="border-white/5 bg-card/50 flex flex-col">
            <CardHeader>
              <CardTitle>Active Sessions</CardTitle>
            </CardHeader>
            <CardContent className="flex-1 flex flex-col">
              <div className="mb-6 flex items-baseline gap-2">
                <span className="text-5xl font-bold font-heading tracking-tighter">
                  {isLoading ? "—" : (data?.activeSessions ?? 0).toLocaleString()}
                </span>
                {(data?.activeSessions ?? 0) > 0 && (
                  <span className="relative flex h-3 w-3">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-3 w-3 bg-green-500"></span>
                  </span>
                )}
              </div>
              <p className="text-sm text-muted-foreground mb-4">sessions currently active</p>
              <div className="space-y-3 flex-1 overflow-y-auto">
                {activeSessionsList.length === 0 ? (
                  <p className="text-sm text-muted-foreground py-6 text-center">
                    {isLoading ? "Loading…" : "No data available"}
                  </p>
                ) : (
                  activeSessionsList.map((s) => (
                    <div key={s.id} className="flex items-center justify-between text-sm py-2 border-b border-white/5 last:border-0">
                      <div>
                        <div className="font-medium text-foreground">{s.id}</div>
                        <div className="text-xs text-muted-foreground">{s.user}</div>
                      </div>
                      <div className="text-right">
                        <div className="text-foreground">{s.duration}</div>
                        <div className="text-xs text-muted-foreground">{s.location} · {s.profile}</div>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card className="border-white/5 bg-card/50">
            <CardHeader>
              <CardTitle>Top Countries</CardTitle>
              <CardDescription>{label}</CardDescription>
            </CardHeader>
            <CardContent>
              {topCountries.length === 0 ? (
                <p className="text-sm text-muted-foreground py-8 text-center">
                  {isLoading ? "Loading…" : "No data available"}
                </p>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow className="border-white/5 hover:bg-transparent">
                      <TableHead>Country</TableHead>
                      <TableHead className="text-right">Visits</TableHead>
                      <TableHead className="w-[100px]"></TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {topCountries.map((c, i) => (
                      <TableRow key={i} className="border-white/5 hover:bg-white/5">
                        <TableCell className="font-medium">{c.name}</TableCell>
                        <TableCell className="text-right">{c.visits.toLocaleString()}</TableCell>
                        <TableCell>
                          <div className="flex items-center justify-end gap-2">
                            <span className="text-xs text-muted-foreground w-8 text-right">{c.share}%</span>
                            <div className="h-1.5 w-16 bg-white/10 rounded-full overflow-hidden">
                              <div className="h-full bg-primary rounded-full" style={{ width: `${c.share}%` }} />
                            </div>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>

          <Card className="border-white/5 bg-card/50">
            <CardHeader>
              <CardTitle>Devices</CardTitle>
              <CardDescription>{label}</CardDescription>
            </CardHeader>
            <CardContent>
              {devices.length === 0 ? (
                <p className="text-sm text-muted-foreground py-8 text-center">
                  {isLoading ? "Loading…" : "No data available"}
                </p>
              ) : (
                <div className="grid grid-cols-1 gap-4">
                  {devices.map((d) => {
                    const style = DEVICE_STYLES[d.type] ?? { icon: HardDrive, color: "text-muted-foreground", bg: "bg-white/5", bar: "bg-muted-foreground" };
                    const Icon = style.icon;
                    return (
                      <div key={d.type} className="p-4 border border-white/5 rounded-xl bg-black/20 flex items-center justify-between">
                        <div className="flex items-center gap-4">
                          <div className={`p-3 ${style.bg} rounded-lg`}>
                            <Icon className={`h-6 w-6 ${style.color}`} />
                          </div>
                          <div>
                            <h4 className="font-medium">{d.type}</h4>
                            <p className="text-2xl font-bold font-heading mt-1">{d.share}%</p>
                          </div>
                        </div>
                        <div className="w-1/3">
                          <div className="h-2 w-full bg-white/10 rounded-full overflow-hidden">
                            <div className={`h-full ${style.bar} rounded-full`} style={{ width: `${d.share}%` }} />
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </AdminLayout>
  );
}

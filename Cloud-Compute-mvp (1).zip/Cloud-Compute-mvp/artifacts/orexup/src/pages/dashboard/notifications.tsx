import { useState } from "react";
import { DashboardLayout } from "@/components/dashboard-layout";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Cloud, Play, Square, AlertCircle, X } from "lucide-react";

type Notif = {
  id: number;
  type: 'connected' | 'started' | 'ended' | 'error';
  title: string;
  time: string;
};

const initialNotifs: Notif[] = [
  { id: 1, type: 'error', title: 'Connection Lost — Cloud node eu-west-1 unreachable', time: '2 minutes ago' },
  { id: 2, type: 'started', title: 'Session Started — Balanced profile session is now active', time: '1 hour ago' },
  { id: 3, type: 'connected', title: 'Cloud Connected — Successfully connected to eu-west-1 node', time: '1 hour ago' },
  { id: 4, type: 'ended', title: 'Session Ended — Session ran for 1h 24m', time: '5 hours ago' },
  { id: 5, type: 'started', title: 'Session Started — High CPU profile session initialized', time: '6 hours ago' },
  { id: 6, type: 'connected', title: 'Reconnected — Cloud connection restored after brief interruption', time: '1 day ago' },
  { id: 7, type: 'error', title: 'Connection Lost — Network timeout after 30s', time: '1 day ago' },
  { id: 8, type: 'ended', title: 'Session Ended — Manually stopped by user', time: '2 days ago' },
];

export default function NotificationsPage() {
  const [filter, setFilter] = useState("all");
  const [notifs, setNotifs] = useState<Notif[]>(initialNotifs);

  const dismiss = (id: number) => {
    setNotifs(notifs.filter(n => n.id !== id));
  };

  const clearAll = () => setNotifs([]);

  const filtered = notifs.filter(n => {
    if (filter === 'all') return true;
    if (filter === 'connected') return n.type === 'connected';
    if (filter === 'session') return n.type === 'started' || n.type === 'ended';
    if (filter === 'errors') return n.type === 'error';
    return true;
  });

  const getIcon = (type: string) => {
    switch(type) {
      case 'connected': return <Cloud className="text-green-500 h-5 w-5" />;
      case 'started': return <Play className="text-green-500 h-5 w-5" />;
      case 'ended': return <Square className="text-gray-400 h-5 w-5" />;
      case 'error': return <AlertCircle className="text-red-500 h-5 w-5" />;
      default: return <Cloud className="text-primary h-5 w-5" />;
    }
  };

  return (
    <DashboardLayout title="Notifications">
      <div className="space-y-6 max-w-4xl mx-auto">
        <div className="flex justify-between items-center">
          <Tabs value={filter} onValueChange={setFilter}>
            <TabsList className="bg-white/5 border border-white/10">
              <TabsTrigger value="all">All</TabsTrigger>
              <TabsTrigger value="connected">Connected</TabsTrigger>
              <TabsTrigger value="session">Session</TabsTrigger>
              <TabsTrigger value="errors">Errors</TabsTrigger>
            </TabsList>
          </Tabs>
          <Button variant="ghost" onClick={clearAll} disabled={notifs.length === 0}>
            Clear All
          </Button>
        </div>

        <div className="space-y-3">
          {filtered.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">
              <AlertCircle className="h-12 w-12 mx-auto mb-4 opacity-20" />
              <p>No notifications</p>
            </div>
          ) : (
            filtered.map(n => (
              <div key={n.id} className="flex items-start gap-4 p-4 rounded-xl border border-white/5 bg-card/50 hover:bg-white/5 transition-colors">
                <div className="mt-1 bg-background rounded-full p-2 border border-white/10">
                  {getIcon(n.type)}
                </div>
                <div className="flex-1">
                  <div className="font-medium mb-1 text-sm md:text-base">{n.title}</div>
                  <div className="text-xs text-muted-foreground">{n.time}</div>
                </div>
                <Button variant="ghost" size="icon" onClick={() => dismiss(n.id)} className="text-muted-foreground hover:text-foreground">
                  <X className="h-4 w-4" />
                </Button>
              </div>
            ))
          )}
        </div>
      </div>
    </DashboardLayout>
  );
}

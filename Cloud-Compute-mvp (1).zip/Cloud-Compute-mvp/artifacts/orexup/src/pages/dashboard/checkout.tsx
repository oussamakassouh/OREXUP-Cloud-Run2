import { useState } from "react";
import { useLocation } from "wouter";
import { motion } from "framer-motion";
import { Lock, ShieldCheck, Check, ArrowLeft, Zap, ExternalLink } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Switch } from "@/components/ui/switch";
import { Layout } from "@/components/layout";
import { CheckoutSteps } from "@/components/checkout-steps";
import { useToast } from "@/hooks/use-toast";
import type { Plan } from "@/lib/app-context";
import { PLAN_CONFIG } from "@/lib/plans";

export default function CheckoutPage() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const params   = new URLSearchParams(window.location.search);
  const planKey  = (params.get("plan") ?? "standard") as Plan;
  const [annual, setAnnual] = useState(params.get("billing") === "annual");
  const [loading, setLoading] = useState(false);

  const plan    = PLAN_CONFIG[planKey] ?? PLAN_CONFIG.standard;
  const price   = annual ? plan.annual : plan.monthly;
  const period  = annual ? "year" : "month";
  const savings = plan.monthly * 12 - plan.annual;

  const handleCheckout = async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/billing/checkout", {
        method:  "POST",
        headers: { "Content-Type": "application/json" },
        body:    JSON.stringify({ plan: planKey, billing: annual ? "annual" : "monthly" }),
      });
      const data = await res.json() as { url?: string; error?: string };
      if (!res.ok || !data.url) {
        toast({ title: "Checkout error", description: data.error ?? "Could not start checkout.", variant: "destructive" });
        setLoading(false);
        return;
      }
      window.location.href = data.url;
    } catch {
      toast({ title: "Network error", description: "Could not reach the server.", variant: "destructive" });
      setLoading(false);
    }
  };

  return (
    <Layout>
      <div className="min-h-[calc(100vh-16rem)] flex flex-col items-center justify-center p-4 relative">
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#80808012_1px,transparent_1px),linear-gradient(to_bottom,#80808012_1px,transparent_1px)] bg-[size:24px_24px] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_0%,#000_70%,transparent_100%)] pointer-events-none" />

        <div className="w-full max-w-3xl relative z-10">
          <CheckoutSteps current={2} />

          <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
            {/* Payment panel — 3 cols */}
            <motion.div
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.35 }}
              className="md:col-span-3"
            >
              <Card className="border-white/10 bg-card/80 backdrop-blur-xl shadow-2xl">
                <CardHeader className="pb-4">
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Zap className="h-5 w-5 text-primary" />
                    Secure Checkout
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="rounded-xl border border-white/10 bg-white/[0.03] p-5 space-y-3">
                    <p className="text-sm font-medium text-foreground">
                      You're subscribing to the <span className="text-primary">{plan.label}</span> plan
                    </p>
                    <p className="text-2xl font-bold font-heading">
                      ${price}
                      <span className="text-sm font-normal text-muted-foreground ml-1">/ {period}</span>
                    </p>
                    <ul className="space-y-1.5">
                      {plan.features.map((f) => (
                        <li key={f} className="flex items-center gap-2 text-xs text-muted-foreground">
                          <Check className="h-3.5 w-3.5 text-primary shrink-0" />
                          {f}
                        </li>
                      ))}
                    </ul>
                  </div>

                  <Button
                    className="w-full h-12 text-sm font-semibold gap-2"
                    disabled={loading}
                    onClick={handleCheckout}
                    data-testid="button-pay-now"
                  >
                    {loading ? (
                      <>
                        <svg className="animate-spin h-4 w-4" viewBox="0 0 24 24" fill="none">
                          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z" />
                        </svg>
                        Redirecting to Stripe…
                      </>
                    ) : (
                      <>
                        <ExternalLink className="h-4 w-4" />
                        Continue to Secure Checkout · ${price} / {period}
                      </>
                    )}
                  </Button>

                  <div className="flex items-center gap-2 text-xs text-muted-foreground justify-center">
                    <Lock className="h-3.5 w-3.5 text-green-500" />
                    <span>Payments processed securely by Stripe</span>
                    <ShieldCheck className="h-3.5 w-3.5 text-green-500 ml-1" />
                    <span>PCI-DSS compliant</span>
                  </div>

                  <button
                    type="button"
                    onClick={() => setLocation("/dashboard/billing")}
                    className="flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground transition-colors w-full justify-center"
                  >
                    <ArrowLeft className="h-3.5 w-3.5" /> Back to plans
                  </button>
                </CardContent>
              </Card>
            </motion.div>

            {/* Order summary — 2 cols */}
            <motion.div
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.35, delay: 0.07 }}
              className="md:col-span-2 space-y-4"
            >
              <Card className="border-white/10 bg-card/80 backdrop-blur-xl shadow-2xl">
                <CardHeader className="pb-3">
                  <CardTitle className="text-base">Order Summary</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-semibold">{plan.label}</p>
                      <p className="text-xs text-muted-foreground capitalize">{annual ? "Annual" : "Monthly"} billing</p>
                    </div>
                    <Badge variant="outline" className="text-primary border-primary/30 bg-primary/10">
                      {planKey === "premium" ? "Popular" : planKey === "custom" ? "Best Value" : "Starter"}
                    </Badge>
                  </div>

                  <ul className="space-y-1.5">
                    {plan.features.map((f) => (
                      <li key={f} className="flex items-center gap-2 text-xs text-muted-foreground">
                        <Check className="h-3.5 w-3.5 text-primary shrink-0" />
                        {f}
                      </li>
                    ))}
                  </ul>

                  <div className="flex items-center justify-between">
                    <span className="text-xs text-muted-foreground">Billing cycle</span>
                    <div className="flex items-center gap-2 text-xs">
                      <span className={!annual ? "text-foreground font-medium" : "text-muted-foreground"}>Monthly</span>
                      <Switch
                        checked={annual}
                        onCheckedChange={setAnnual}
                        className="scale-75"
                        data-testid="checkout-billing-toggle"
                      />
                      <span className={annual ? "text-foreground font-medium" : "text-muted-foreground"}>Annual</span>
                    </div>
                  </div>

                  {annual && (
                    <div className="text-xs text-green-400 bg-green-500/10 border border-green-500/20 rounded-lg px-3 py-2">
                      You save <strong>${savings}/year</strong> with annual billing
                    </div>
                  )}

                  <Separator className="bg-white/5" />

                  <div className="space-y-1.5 text-sm">
                    <div className="flex justify-between text-muted-foreground">
                      <span>Subtotal</span>
                      <span>${price}</span>
                    </div>
                    <div className="flex justify-between text-muted-foreground">
                      <span>Tax</span>
                      <span>$0.00</span>
                    </div>
                    <div className="flex justify-between font-semibold text-base pt-1">
                      <span>Total</span>
                      <span>${price} <span className="text-xs font-normal text-muted-foreground">/ {period}</span></span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <p className="text-[11px] text-muted-foreground text-center leading-relaxed px-2">
                Cancel anytime. No hidden fees. By subscribing you agree to our Terms of Service.
              </p>
            </motion.div>
          </div>
        </div>
      </div>
    </Layout>
  );
}

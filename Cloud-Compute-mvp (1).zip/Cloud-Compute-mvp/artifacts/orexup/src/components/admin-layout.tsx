import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { 
  LayoutDashboard, 
  Activity, 
  TrendingUp, 
  Users, 
  DollarSign, 
  Handshake, 
  ShieldAlert, 
  Settings, 
  Ticket,
  LogOut,
  ShieldCheck,
  Menu,
  FileText,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { ModeToggle } from "@/components/mode-toggle";
import { Badge } from "@/components/ui/badge";

const BASE = import.meta.env.BASE_URL?.replace(/\/$/, "") ?? "";

const navItems = [
  { icon: LayoutDashboard, label: "Overview", href: "/administrator/overview" },
  { icon: Activity, label: "Traffic", href: "/administrator/traffic" },
  { icon: TrendingUp, label: "Analytics", href: "/administrator/analytics" },
  { icon: Users, label: "Total Users", href: "/administrator/users" },
  { icon: DollarSign, label: "Payments", href: "/administrator/payments" },
  { icon: Handshake, label: "Our Team", href: "/administrator/partners" },
  { icon: ShieldAlert, label: "Security", href: "/administrator/security" },
  { icon: FileText, label: "Content", href: "/administrator/content" },
  { icon: Settings, label: "Settings", href: "/administrator/settings" },
  { icon: Ticket, label: "Support Tickets", href: "/administrator/support" },
];

export function AdminLayout({ children, title = "Admin Dashboard" }: { children: React.ReactNode, title?: string }) {
  const [location, setLocation] = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const handleLogout = async () => {
    try {
      await fetch(`${BASE}/api/admin/session`, { method: "DELETE", credentials: "include" });
    } catch {}
    setLocation("/administrator/login");
  };

  const SidebarContent = () => (
    <div className="flex flex-col h-full bg-[#0a0f16] border-r border-white/5">
      <div className="p-6 flex items-center gap-2">
        <ShieldCheck className="h-6 w-6 text-primary" />
        <Link href="/administrator/overview" className="font-heading font-bold text-xl tracking-tighter text-foreground" data-testid="admin-logo">
          OREXUP Admin
        </Link>
      </div>
      <nav className="flex-1 px-4 space-y-1 overflow-y-auto">
        {navItems.map((item) => {
          const isActive = location === item.href;
          return (
            <Link key={item.href} href={item.href}>
              <div 
                className={`flex items-center gap-3 px-3 py-2.5 rounded-md transition-all duration-200 cursor-pointer ${
                  isActive 
                    ? "bg-primary/10 text-primary font-medium" 
                    : "text-muted-foreground hover:bg-white/5 hover:text-foreground"
                }`}
                onClick={() => setMobileMenuOpen(false)}
                data-testid={`admin-nav-item-${item.label.toLowerCase().replace(/\s+/g, '-')}`}
              >
                <item.icon className={`h-4 w-4 ${isActive ? "text-primary" : "text-muted-foreground"}`} />
                <span className="text-sm">{item.label}</span>
              </div>
            </Link>
          );
        })}
      </nav>
      <div className="p-4 border-t border-white/5">
        <Button 
          variant="ghost" 
          className="w-full justify-start text-muted-foreground hover:text-red-500 hover:bg-red-500/10 transition-colors" 
          onClick={handleLogout}
          data-testid="admin-button-logout"
        >
          <LogOut className="mr-3 h-4 w-4" />
          Logout
        </Button>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-background flex flex-col md:flex-row">
      <aside className="hidden md:flex w-[240px] flex-col fixed inset-y-0 left-0 z-50">
        <SidebarContent />
      </aside>

      <div className="md:hidden flex items-center justify-between p-4 border-b border-white/5 bg-[#0a0f16] sticky top-0 z-40">
        <div className="flex items-center gap-2">
          <ShieldCheck className="h-5 w-5 text-primary" />
          <Link href="/administrator/overview" className="font-heading font-bold text-lg tracking-tighter text-foreground">
            OREXUP
          </Link>
        </div>
        <div className="flex items-center gap-4">
          <ModeToggle />
          <Sheet open={mobileMenuOpen} onOpenChange={setMobileMenuOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="md:hidden" aria-label="Open menu" data-testid="admin-button-mobile-menu">
                <Menu className="h-5 w-5" />
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="p-0 w-[240px] bg-[#0a0f16] border-r-white/10">
              <SidebarContent />
            </SheetContent>
          </Sheet>
        </div>
      </div>

      <main className="flex-1 md:pl-[240px] flex flex-col min-h-screen">
        <header className="flex h-16 items-center justify-between px-6 border-b border-white/5 bg-background/80 backdrop-blur-md sticky top-0 z-30">
          <h1 className="text-xl font-semibold font-heading tracking-tight">{title}</h1>
          <div className="flex items-center gap-4">
            <Badge variant="outline" className="bg-amber-500/10 text-amber-500 border-amber-500/20 font-medium">
              Admin
            </Badge>
            <ModeToggle />
          </div>
        </header>
        <div className="flex-1 p-6 md:p-8 max-w-7xl mx-auto w-full">
          {children}
        </div>
      </main>
    </div>
  );
}

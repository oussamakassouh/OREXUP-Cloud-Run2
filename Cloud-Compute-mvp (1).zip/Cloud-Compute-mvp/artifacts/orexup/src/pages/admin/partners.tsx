import { useState } from "react";
import { AdminLayout } from "@/components/admin-layout";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { CheckCircle2, Ban, Trash2, Pencil, Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle,
} from "@/components/ui/dialog";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useQueryClient } from "@tanstack/react-query";
import {
  useGetAdminPartners,
  useInvitePartner,
  useUpdatePartner,
  useRemovePartner,
  getGetAdminPartnersQueryKey,
  type Partner,
  type InvitePartnerRequestRole,
  type UpdatePartnerRequestRole,
  type UpdatePartnerRequestStatus,
} from "@workspace/api-client-react";

const ROLES = ["Support", "Marketing", "Developer", "Business"] as const;

const PERMISSION_OPTIONS = [
  { id: "view_dashboard", label: "View Dashboard" },
  { id: "api_access", label: "API Access" },
  { id: "view_billing", label: "View Billing" },
  { id: "view_analytics", label: "View Analytics" },
  { id: "manage_support", label: "Manage Support" },
] as const;

const partnerSchema = z.object({
  companyName: z.string().min(2, "Company name required"),
  contactName: z.string().min(2, "Contact name required"),
  businessEmail: z.string().email("Invalid business email"),
  role: z.string().min(1, "Role required"),
  status: z.string().min(1),
  notes: z.string(),
});
type PartnerForm = z.infer<typeof partnerSchema>;

function cap(s: string) {
  return s ? s.charAt(0).toUpperCase() + s.slice(1) : s;
}

function statusClass(status: string) {
  switch (status.toLowerCase()) {
    case "active":
      return "bg-green-500/10 text-green-500 border-green-500/20";
    case "pending":
      return "bg-amber-500/10 text-amber-500 border-amber-500/20";
    case "disabled":
      return "bg-red-500/10 text-red-500 border-red-500/20";
    default:
      return "bg-white/5 text-muted-foreground border-white/10";
  }
}

function permissionLabel(id: string) {
  return PERMISSION_OPTIONS.find((p) => p.id === id)?.label ?? id;
}

export default function AdminPartnersPage() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { data: partners, isLoading, isError } = useGetAdminPartners();

  const invalidate = () =>
    queryClient.invalidateQueries({ queryKey: getGetAdminPartnersQueryKey() });

  const inviteMutation = useInvitePartner({
    mutation: { onSuccess: invalidate },
  });
  const updateMutation = useUpdatePartner({
    mutation: { onSuccess: invalidate },
  });
  const removeMutation = useRemovePartner({
    mutation: { onSuccess: invalidate },
  });

  const [invitePerms, setInvitePerms] = useState<string[]>([]);
  const [editing, setEditing] = useState<Partner | null>(null);
  const [editPerms, setEditPerms] = useState<string[]>([]);
  const [deleteTarget, setDeleteTarget] = useState<Partner | null>(null);

  const inviteForm = useForm<PartnerForm>({
    resolver: zodResolver(partnerSchema),
    defaultValues: { companyName: "", contactName: "", businessEmail: "", role: "", status: "pending", notes: "" },
  });

  const editForm = useForm<PartnerForm>({
    resolver: zodResolver(partnerSchema),
    defaultValues: { companyName: "", contactName: "", businessEmail: "", role: "", status: "pending", notes: "" },
  });

  const togglePerm = (
    list: string[],
    setList: (v: string[]) => void,
    id: string,
  ) => {
    setList(list.includes(id) ? list.filter((p) => p !== id) : [...list, id]);
  };

  const onInvite = (values: PartnerForm) => {
    inviteMutation.mutate(
      {
        data: {
          companyName: values.companyName,
          contactName: values.contactName,
          businessEmail: values.businessEmail,
          role: values.role as InvitePartnerRequestRole,
          permissions: invitePerms,
          notes: values.notes || null,
        },
      },
      {
        onSuccess: () => {
          toast({ title: "Invitation Sent", description: `Invited ${values.companyName} as a ${values.role} team member.` });
          inviteForm.reset();
          setInvitePerms([]);
        },
        onError: () => toast({ title: "Invite failed", description: "Could not send the invitation.", variant: "destructive" }),
      },
    );
  };

  const openEdit = (p: Partner) => {
    setEditing(p);
    setEditPerms(p.permissions ?? []);
    editForm.reset({
      companyName: p.companyName,
      contactName: p.contactName,
      businessEmail: p.businessEmail,
      role: p.role,
      status: p.status,
      notes: p.notes ?? "",
    });
  };

  const onEditSave = (values: PartnerForm) => {
    if (!editing) return;
    updateMutation.mutate(
      {
        id: editing.id,
        data: {
          companyName: values.companyName,
          contactName: values.contactName,
          businessEmail: values.businessEmail,
          role: values.role as UpdatePartnerRequestRole,
          status: values.status as UpdatePartnerRequestStatus,
          permissions: editPerms,
          notes: values.notes || null,
        },
      },
      {
        onSuccess: () => {
          toast({ title: "Team Member Updated", description: `${values.companyName} has been saved.` });
          setEditing(null);
        },
        onError: () => toast({ title: "Update failed", description: "Could not save changes.", variant: "destructive" }),
      },
    );
  };

  const setStatus = (p: Partner, status: "active" | "disabled") => {
    updateMutation.mutate(
      { id: p.id, data: { status } },
      {
        onSuccess: () =>
          toast({
            title: status === "active" ? "Team Member Approved" : "Team Member Disabled",
            description: `${p.companyName} is now ${status}.`,
          }),
        onError: () => toast({ title: "Action failed", description: "Could not update the team member.", variant: "destructive" }),
      },
    );
  };

  const onRemove = () => {
    if (!deleteTarget) return;
    removeMutation.mutate(
      { id: deleteTarget.id },
      {
        onSuccess: () => {
          toast({ title: "Team Member Removed", description: `${deleteTarget.companyName} has been removed.`, variant: "destructive" });
          setDeleteTarget(null);
        },
        onError: () => toast({ title: "Remove failed", description: "Could not remove the team member.", variant: "destructive" }),
      },
    );
  };

  const list = partners ?? [];

  return (
    <AdminLayout title="Team Management">
      <div className="space-y-6">
        {/* Invite */}
        <Card className="border-white/5 bg-card/50">
          <CardHeader>
            <CardTitle>Invite New Team Member</CardTitle>
            <CardDescription>Send an invitation to a prospective team member.</CardDescription>
          </CardHeader>
          <CardContent>
            <Form {...inviteForm}>
              <form onSubmit={inviteForm.handleSubmit(onInvite)} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField control={inviteForm.control} name="companyName" render={({ field }) => (
                    <FormItem>
                      <FormLabel>Company Name</FormLabel>
                      <FormControl><Input placeholder="Acme Corp" className="bg-black/20" {...field} /></FormControl>
                      <FormMessage />
                    </FormItem>
                  )} />
                  <FormField control={inviteForm.control} name="contactName" render={({ field }) => (
                    <FormItem>
                      <FormLabel>Contact Name</FormLabel>
                      <FormControl><Input placeholder="Jane Doe" className="bg-black/20" {...field} /></FormControl>
                      <FormMessage />
                    </FormItem>
                  )} />
                  <FormField control={inviteForm.control} name="businessEmail" render={({ field }) => (
                    <FormItem>
                      <FormLabel>Business Email</FormLabel>
                      <FormControl><Input placeholder="member@company.com" className="bg-black/20" {...field} /></FormControl>
                      <FormMessage />
                    </FormItem>
                  )} />
                  <FormField control={inviteForm.control} name="role" render={({ field }) => (
                    <FormItem>
                      <FormLabel>Role</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger className="bg-black/20"><SelectValue placeholder="Select role" /></SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {ROLES.map((r) => <SelectItem key={r} value={r}>{r}</SelectItem>)}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )} />
                </div>

                <div>
                  <Label>Permissions</Label>
                  <div className="flex flex-wrap gap-4 mt-2">
                    {PERMISSION_OPTIONS.map((perm) => (
                      <label key={perm.id} className="flex items-center gap-2 text-sm cursor-pointer">
                        <Checkbox
                          checked={invitePerms.includes(perm.id)}
                          onCheckedChange={() => togglePerm(invitePerms, setInvitePerms, perm.id)}
                        />
                        {perm.label}
                      </label>
                    ))}
                  </div>
                </div>

                <FormField control={inviteForm.control} name="notes" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Notes</FormLabel>
                    <FormControl><Textarea placeholder="Optional notes about this team member" className="bg-black/20" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />

                <Button type="submit" className="px-8" disabled={inviteMutation.isPending}>
                  {inviteMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  Send Invite
                </Button>
              </form>
            </Form>
          </CardContent>
        </Card>

        {/* List */}
        <Card className="border-white/5 bg-card/50">
          <CardHeader>
            <CardTitle>Current Team</CardTitle>
          </CardHeader>
          <Table>
            <TableHeader>
              <TableRow className="border-white/5 hover:bg-transparent">
                <TableHead>Company</TableHead>
                <TableHead>Contact</TableHead>
                <TableHead>Business Email</TableHead>
                <TableHead>Role</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Permissions</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading && (
                <TableRow><TableCell colSpan={7} className="text-center py-10 text-muted-foreground">Loading…</TableCell></TableRow>
              )}
              {isError && !isLoading && (
                <TableRow><TableCell colSpan={7} className="text-center py-10 text-muted-foreground">No data available</TableCell></TableRow>
              )}
              {!isLoading && !isError && list.length === 0 && (
                <TableRow><TableCell colSpan={7} className="text-center py-10 text-muted-foreground">No data available</TableCell></TableRow>
              )}
              {list.map((p) => (
                <TableRow key={p.id} className="border-white/5 hover:bg-white/5">
                  <TableCell className="font-medium">{p.companyName}</TableCell>
                  <TableCell>{p.contactName}</TableCell>
                  <TableCell className="text-muted-foreground">{p.businessEmail}</TableCell>
                  <TableCell>{p.role}</TableCell>
                  <TableCell>
                    <Badge variant="outline" className={statusClass(p.status)}>{cap(p.status)}</Badge>
                  </TableCell>
                  <TableCell>
                    <div className="flex flex-wrap gap-1 max-w-[220px]">
                      {(p.permissions ?? []).length === 0 ? (
                        <span className="text-muted-foreground/60 italic text-xs">None</span>
                      ) : (
                        (p.permissions ?? []).map((perm) => (
                          <Badge key={perm} variant="outline" className="bg-white/5 border-white/10 text-xs font-normal">
                            {permissionLabel(perm)}
                          </Badge>
                        ))
                      )}
                    </div>
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex items-center justify-end gap-1">
                      {p.status.toLowerCase() !== "active" && (
                        <Button variant="ghost" size="icon" title="Approve" className="h-8 w-8 text-muted-foreground hover:text-green-500 hover:bg-green-500/10"
                          disabled={updateMutation.isPending} onClick={() => setStatus(p, "active")}>
                          <CheckCircle2 className="h-4 w-4" />
                        </Button>
                      )}
                      {p.status.toLowerCase() !== "disabled" && (
                        <Button variant="ghost" size="icon" title="Disable" className="h-8 w-8 text-muted-foreground hover:text-amber-500 hover:bg-amber-500/10"
                          disabled={updateMutation.isPending} onClick={() => setStatus(p, "disabled")}>
                          <Ban className="h-4 w-4" />
                        </Button>
                      )}
                      <Button variant="ghost" size="icon" title="Edit" className="h-8 w-8 text-muted-foreground hover:text-primary hover:bg-primary/10"
                        onClick={() => openEdit(p)}>
                        <Pencil className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="icon" title="Remove" className="h-8 w-8 text-muted-foreground hover:text-red-500 hover:bg-red-500/10"
                        onClick={() => setDeleteTarget(p)}>
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </Card>
      </div>

      {/* Edit dialog */}
      <Dialog open={!!editing} onOpenChange={(o) => !o && setEditing(null)}>
        <DialogContent className="bg-[#0a0f16] border-white/10 max-w-lg">
          <DialogHeader>
            <DialogTitle>Edit Team Member</DialogTitle>
            <DialogDescription>Update team member details, role, status and permissions.</DialogDescription>
          </DialogHeader>
          <Form {...editForm}>
            <form onSubmit={editForm.handleSubmit(onEditSave)} className="space-y-4">
              <FormField control={editForm.control} name="companyName" render={({ field }) => (
                <FormItem>
                  <FormLabel>Company Name</FormLabel>
                  <FormControl><Input className="bg-black/20" {...field} /></FormControl>
                  <FormMessage />
                </FormItem>
              )} />
              <FormField control={editForm.control} name="contactName" render={({ field }) => (
                <FormItem>
                  <FormLabel>Contact Name</FormLabel>
                  <FormControl><Input className="bg-black/20" {...field} /></FormControl>
                  <FormMessage />
                </FormItem>
              )} />
              <FormField control={editForm.control} name="businessEmail" render={({ field }) => (
                <FormItem>
                  <FormLabel>Business Email</FormLabel>
                  <FormControl><Input className="bg-black/20" {...field} /></FormControl>
                  <FormMessage />
                </FormItem>
              )} />
              <div className="grid grid-cols-2 gap-4">
                <FormField control={editForm.control} name="role" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Role</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl><SelectTrigger className="bg-black/20"><SelectValue placeholder="Select role" /></SelectTrigger></FormControl>
                      <SelectContent>{ROLES.map((r) => <SelectItem key={r} value={r}>{r}</SelectItem>)}</SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={editForm.control} name="status" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Status</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl><SelectTrigger className="bg-black/20"><SelectValue placeholder="Select status" /></SelectTrigger></FormControl>
                      <SelectContent>
                        <SelectItem value="active">Active</SelectItem>
                        <SelectItem value="pending">Pending</SelectItem>
                        <SelectItem value="disabled">Disabled</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )} />
              </div>
              <div>
                <Label>Permissions</Label>
                <div className="flex flex-wrap gap-4 mt-2">
                  {PERMISSION_OPTIONS.map((perm) => (
                    <label key={perm.id} className="flex items-center gap-2 text-sm cursor-pointer">
                      <Checkbox checked={editPerms.includes(perm.id)} onCheckedChange={() => togglePerm(editPerms, setEditPerms, perm.id)} />
                      {perm.label}
                    </label>
                  ))}
                </div>
              </div>
              <FormField control={editForm.control} name="notes" render={({ field }) => (
                <FormItem>
                  <FormLabel>Notes</FormLabel>
                  <FormControl><Textarea className="bg-black/20" {...field} /></FormControl>
                  <FormMessage />
                </FormItem>
              )} />
              <DialogFooter>
                <Button type="button" variant="ghost" onClick={() => setEditing(null)}>Cancel</Button>
                <Button type="submit" disabled={updateMutation.isPending}>
                  {updateMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  Save Changes
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Remove confirm */}
      <AlertDialog open={!!deleteTarget} onOpenChange={(o) => !o && setDeleteTarget(null)}>
        <AlertDialogContent className="bg-[#0a0f16] border-white/10">
          <AlertDialogHeader>
            <AlertDialogTitle>Remove team member {deleteTarget?.companyName}?</AlertDialogTitle>
            <AlertDialogDescription>
              They will lose access to team APIs and dashboard resources immediately.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="bg-white/5 border-white/10 hover:bg-white/10">Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={onRemove} className="bg-red-500 hover:bg-red-600 text-white">Remove Team Member</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </AdminLayout>
  );
}

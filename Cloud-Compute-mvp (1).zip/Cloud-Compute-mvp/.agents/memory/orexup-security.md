---
name: OREXUP security hardening
description: Auth storage rules, XSS mitigations, and shared config decisions made during code review fixes
---

## Admin session auth
- `AdminProtectedRoute` in `App.tsx` calls `GET /api/admin/me` (HttpOnly cookie, `orexup_admin_session`) to gate admin routes — never checks localStorage.
- `admin/login.tsx` no longer writes anything to localStorage on success.
- `admin-layout.tsx` logout calls `DELETE /api/admin/session`; pure layout component.

**Why:** localStorage is accessible to JS and vulnerable to XSS; HttpOnly cookies are not.

**How to apply:** Any new admin-gated route must use `<AdminProtectedRoute>` — do not add a separate localStorage flag.

## Cloud token
- `app-context.tsx` stores the cloud token in React state (in-memory) only — never persisted to localStorage or sessionStorage.

**Why:** Tokens in storage are leaked by XSS; in-memory state is cleared on tab close.

## XSS — admin content editor
- Both `dangerouslySetInnerHTML` preview sections in `admin/content.tsx` are wrapped with `DOMPurify.sanitize(...)`.
- `dompurify` and `@types/dompurify` are installed in `artifacts/orexup`.

**Why:** Admin users paste arbitrary HTML; unsanitized preview could run injected scripts.

## Shared plan config
- `PLAN_CONFIG` lives in `artifacts/orexup/src/lib/plans.ts` and is imported by both `checkout.tsx` and `checkout-success.tsx`.
- `admin/payments.tsx` "Save Plan" and "Refund" buttons give honest "Display Only / Use Stripe Dashboard" toasts — they are not wired to live mutation APIs.

**Why:** Prices must stay in sync across pages; admin plan UI is read-only until Stripe webhooks are wired.

## Support ticket endpoints (admin)
- `GET /api/admin/me` — confirms active admin session; used by `AdminProtectedRoute`.
- `POST /api/admin/support/:id/reply` — appends staff message to ticket.
- `PATCH /api/admin/support/:id/status` — sets ticket status (Open/Pending/Closed).
- All three are in `artifacts/api-server/src/routes/admin.ts`, guarded by `adminAuth` middleware.

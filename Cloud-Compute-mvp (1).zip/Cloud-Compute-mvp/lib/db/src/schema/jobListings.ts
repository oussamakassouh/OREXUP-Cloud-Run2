import { pgTable, text, serial, timestamp } from "drizzle-orm/pg-core";

export const jobListingsTable = pgTable("job_listings", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  department: text("department").notNull().default(""),
  location: text("location").notNull().default("Remote"),
  type: text("type").notNull().default("Full-time"),
  description: text("description").notNull().default(""),
  requirements: text("requirements").notNull().default(""),
  status: text("status").notNull().default("open"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export type JobListing = typeof jobListingsTable.$inferSelect;

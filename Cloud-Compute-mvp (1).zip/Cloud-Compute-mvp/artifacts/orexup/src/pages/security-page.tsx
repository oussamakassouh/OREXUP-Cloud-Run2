import { PublicPage } from "./public-page";
export default function SecurityPage() {
  return <PublicPage slug="security" title="Security" />;
}

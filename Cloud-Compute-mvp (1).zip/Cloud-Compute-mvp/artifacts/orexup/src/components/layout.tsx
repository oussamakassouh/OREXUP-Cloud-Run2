import { Link } from "wouter";
import { ModeToggle } from "./mode-toggle";
import { Button } from "./ui/button";
import { CookieBanner } from "./cookie-banner";
import { Linkedin, Instagram } from "lucide-react";
import { LanguageSwitcher } from "./language-switcher";
import { useI18n } from "@/lib/i18n";

function XIcon({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" className={className} aria-hidden="true">
      <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-4.714-6.231-5.401 6.231H2.747l7.73-8.835L1.254 2.25H8.08l4.259 5.63 5.905-5.63Zm-1.161 17.52h1.833L7.084 4.126H5.117Z" />
    </svg>
  );
}

const SOCIAL_LINKS = [
  { icon: XIcon,     label: "X",         href: "https://x.com/orexup" },
  { icon: Instagram, label: "Instagram", href: "https://instagram.com/orexup" },
  { icon: Linkedin,  label: "LinkedIn",  href: "https://linkedin.com/company/orexup" },
];

export function Layout({ children }: { children: React.ReactNode }) {
  const { t } = useI18n();

  const footerCols = [
    {
      heading: t.footer.company,
      links: [
        { label: t.footer.support,  href: "/dashboard/support" },
        { label: t.footer.aboutUs,  href: "/about-us" },
        { label: t.footer.blog,     href: "/blog" },
        { label: t.footer.careers,  href: "/careers" },
      ],
    },
    {
      heading: t.footer.legal,
      links: [
        { label: t.footer.privacy,  href: "/privacy" },
        { label: t.footer.terms,    href: "/terms" },
        { label: t.footer.cookies,  href: "/cookies" },
        { label: t.footer.security, href: "/security" },
      ],
    },
  ];

  return (
    <div className="min-h-screen flex flex-col">
      <header className="sticky top-0 z-50 w-full border-b border-white/5 bg-background/80 backdrop-blur-md">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-8">
            <Link href="/" className="font-heading font-bold text-2xl tracking-tighter hover:text-primary transition-colors" data-testid="link-home-logo">
              OREXUP
            </Link>
            <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-muted-foreground">
            </nav>
          </div>
          <div className="flex items-center gap-2">
            <div className="hidden sm:flex items-center gap-2">
              <Link href="/signin">
                <Button variant="ghost" data-testid="button-nav-signin">{t.nav.signIn}</Button>
              </Link>
              <Link href="/signup">
                <Button data-testid="button-nav-signup">{t.nav.signUp}</Button>
              </Link>
            </div>
          </div>
        </div>
      </header>

      <main className="flex-1">
        {children}
      </main>

      <CookieBanner />

      {/* ── FOOTER ── */}
      <footer className="border-t border-white/5 bg-card">
        <div className="container mx-auto px-4 pt-16 pb-8">

          {/* Top: brand + columns */}
          <div className="grid grid-cols-2 md:grid-cols-6 gap-10 mb-12">
            {/* Brand block — spans 2 cols */}
            <div className="col-span-2">
              <Link href="/" className="font-heading font-bold text-xl tracking-tighter hover:text-primary transition-colors">
                OREXUP
              </Link>
              <p className="mt-4 text-sm text-muted-foreground leading-relaxed max-w-xs">
                {t.footer.tagline}
              </p>
              {/* Social icons */}
              <div className="flex items-center gap-3 mt-6">
                {SOCIAL_LINKS.map(({ icon: Icon, label, href }) => (
                  <a
                    key={label}
                    href={href}
                    aria-label={label}
                    className="p-2 rounded-lg border border-white/10 bg-white/5 hover:bg-white/10 hover:border-primary/30 text-muted-foreground hover:text-primary transition-colors"
                  >
                    <Icon className="h-4 w-4" />
                  </a>
                ))}
              </div>
            </div>

            {/* Nav columns */}
            {footerCols.map((col) => (
              <div key={col.heading}>
                <h4 className="font-semibold text-sm mb-4">{col.heading}</h4>
                <ul className="space-y-2.5">
                  {col.links.map(({ label, href }) => {
                    const isInternal = href.startsWith("/");
                    const content = (
                      <span className="text-sm text-muted-foreground hover:text-primary transition-colors">
                        {label}
                      </span>
                    );
                    return (
                      <li key={label}>
                        {isInternal ? <Link href={href}>{content}</Link> : <a href={href}>{content}</a>}
                      </li>
                    );
                  })}
                </ul>
              </div>
            ))}
          </div>

          {/* Bottom bar */}
          <div className="border-t border-white/5 pt-8 flex flex-col sm:flex-row items-center justify-between gap-4">
            <p className="text-xs text-muted-foreground">
              © {new Date().getFullYear()} {t.footer.copyright}
            </p>
            <div className="flex items-center gap-3">
              <LanguageSwitcher />
              <ModeToggle />
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

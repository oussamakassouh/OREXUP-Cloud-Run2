import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle,
} from "@/components/ui/dialog";
import { ShieldCheck, Loader2, Copy, Check } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";
import {
  useGetAdminTwoFactorStatus,
  useSetupAdminTwoFactor,
  useVerifyAdminTwoFactor,
  useDisableAdminTwoFactor,
  getGetAdminTwoFactorStatusQueryKey,
} from "@workspace/api-client-react";

export function TwoFactorSetup() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { data: status, isLoading } = useGetAdminTwoFactorStatus();
  const enabled = status?.enabled ?? false;

  const [open, setOpen] = useState(false);
  const [qr, setQr] = useState<string | null>(null);
  const [secret, setSecret] = useState<string>("");
  const [token, setToken] = useState("");
  const [copied, setCopied] = useState(false);

  const invalidate = () =>
    queryClient.invalidateQueries({ queryKey: getGetAdminTwoFactorStatusQueryKey() });

  const setupMutation = useSetupAdminTwoFactor({
    mutation: {
      onSuccess: (data) => {
        setQr(data.qrCodeDataUrl);
        setSecret(data.secret);
      },
      onError: () =>
        toast({ title: "Setup failed", description: "Could not generate a QR code.", variant: "destructive" }),
    },
  });

  const verifyMutation = useVerifyAdminTwoFactor({
    mutation: {
      onSuccess: () => {
        toast({ title: "2FA enabled", description: "Two-factor authentication is now active." });
        invalidate();
        closeDialog();
      },
      onError: () =>
        toast({ title: "Invalid code", description: "That code didn't match. Try again.", variant: "destructive" }),
    },
  });

  const disableMutation = useDisableAdminTwoFactor({
    mutation: {
      onSuccess: () => {
        toast({ title: "2FA disabled", description: "Two-factor authentication has been turned off." });
        invalidate();
      },
      onError: () =>
        toast({ title: "Error", description: "Could not disable 2FA.", variant: "destructive" }),
    },
  });

  function startSetup() {
    setOpen(true);
    setQr(null);
    setSecret("");
    setToken("");
    setupMutation.mutate();
  }

  function closeDialog() {
    setOpen(false);
    setQr(null);
    setSecret("");
    setToken("");
  }

  function handleToggle(checked: boolean) {
    if (checked) {
      startSetup();
    } else {
      disableMutation.mutate();
    }
  }

  function handleVerify() {
    const clean = token.replace(/\s/g, "");
    if (clean.length !== 6) {
      toast({ title: "Enter 6 digits", description: "The code is 6 digits long.", variant: "destructive" });
      return;
    }
    verifyMutation.mutate({ data: { token: clean } });
  }

  async function copySecret() {
    await navigator.clipboard.writeText(secret);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  }

  return (
    <>
      <div className="flex items-center justify-between p-4 border border-white/5 rounded-lg bg-black/20">
        <div className="space-y-0.5">
          <div className="flex items-center gap-2">
            <span className="text-sm font-medium leading-none">Require 2FA for Admin</span>
            {enabled && (
              <Badge variant="outline" className="bg-green-500/10 text-green-500 border-green-500/20">
                Active
              </Badge>
            )}
          </div>
          <p className="text-xs text-muted-foreground">
            Scan a QR code with Google Authenticator, Authy, or 1Password to secure the admin login.
          </p>
        </div>
        <div className="flex items-center gap-3">
          {enabled && (
            <Button
              variant="outline"
              size="sm"
              onClick={startSetup}
              disabled={setupMutation.isPending}
            >
              Re-scan
            </Button>
          )}
          <Switch
            checked={enabled}
            onCheckedChange={handleToggle}
            disabled={isLoading || disableMutation.isPending}
          />
        </div>
      </div>

      <Dialog open={open} onOpenChange={(o) => (o ? setOpen(true) : closeDialog())}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <ShieldCheck className="h-5 w-5 text-primary" />
              Set up Two-Factor Authentication
            </DialogTitle>
            <DialogDescription>
              Scan this QR code with your authenticator app, then enter the 6-digit code it shows.
            </DialogDescription>
          </DialogHeader>

          <div className="flex flex-col items-center gap-4 py-2">
            {setupMutation.isPending || !qr ? (
              <div className="flex h-48 w-48 items-center justify-center rounded-lg bg-white/5">
                <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
              </div>
            ) : (
              <img
                src={qr}
                alt="2FA QR code"
                className="h-48 w-48 rounded-lg bg-white p-2"
              />
            )}

            {secret && (
              <div className="w-full space-y-1.5">
                <p className="text-xs text-muted-foreground text-center">
                  Can't scan? Enter this key manually:
                </p>
                <button
                  type="button"
                  onClick={copySecret}
                  className="flex w-full items-center justify-center gap-2 rounded-md bg-black/30 px-3 py-2 font-mono text-xs tracking-wider hover:bg-black/40 transition"
                >
                  {secret}
                  {copied ? <Check className="h-3.5 w-3.5 text-green-500" /> : <Copy className="h-3.5 w-3.5" />}
                </button>
              </div>
            )}

            <div className="w-full space-y-2">
              <Input
                value={token}
                onChange={(e) => setToken(e.target.value.replace(/[^0-9]/g, "").slice(0, 6))}
                placeholder="123456"
                inputMode="numeric"
                maxLength={6}
                className="bg-black/20 text-center text-lg tracking-[0.5em] font-mono"
              />
            </div>
          </div>

          <DialogFooter>
            <Button variant="ghost" onClick={closeDialog}>Cancel</Button>
            <Button onClick={handleVerify} disabled={verifyMutation.isPending || !qr}>
              {verifyMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Verify & Enable
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}

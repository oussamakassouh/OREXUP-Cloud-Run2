import { Router, type IRouter } from "express";
import { eq, desc } from "drizzle-orm";
import { db, contentPagesTable, blogPostsTable, jobListingsTable } from "@workspace/db";
import { logger } from "../lib/logger";

const router: IRouter = Router();

// ── Seed default pages ────────────────────────────────────────────────────────
const DEFAULT_PAGES = [
  { slug: "privacy",  title: "Privacy Policy" },
  { slug: "terms",    title: "Terms of Service" },
  { slug: "security", title: "Security" },
  { slug: "cookies",  title: "Cookies Policy" },
  { slug: "about-us", title: "About Us" },
  { slug: "blog",     title: "Blog" },
  { slug: "careers",  title: "Careers" },
] as const;

async function ensurePages() {
  for (const p of DEFAULT_PAGES) {
    const existing = await db
      .select()
      .from(contentPagesTable)
      .where(eq(contentPagesTable.slug, p.slug))
      .limit(1);
    if (existing.length === 0) {
      await db.insert(contentPagesTable).values({ slug: p.slug, title: p.title, content: "", status: "draft" });
    }
  }
}

function serializePage(p: typeof contentPagesTable.$inferSelect) {
  return { ...p, createdAt: p.createdAt.toISOString(), updatedAt: p.updatedAt.toISOString() };
}
function serializeBlog(p: typeof blogPostsTable.$inferSelect) {
  return { ...p, publishedAt: p.publishedAt?.toISOString() ?? null, createdAt: p.createdAt.toISOString(), updatedAt: p.updatedAt.toISOString() };
}
function serializeJob(j: typeof jobListingsTable.$inferSelect) {
  return { ...j, createdAt: j.createdAt.toISOString(), updatedAt: j.updatedAt.toISOString() };
}

// ── Admin: Pages ──────────────────────────────────────────────────────────────
router.get("/admin/content/pages", async (_req, res): Promise<void> => {
  await ensurePages();
  const rows = await db.select().from(contentPagesTable).orderBy(contentPagesTable.id);
  res.json(rows.map(serializePage));
});

router.get("/admin/content/pages/:slug", async (req, res): Promise<void> => {
  await ensurePages();
  const rows = await db.select().from(contentPagesTable).where(eq(contentPagesTable.slug, req.params.slug)).limit(1);
  if (!rows[0]) { res.status(404).json({ error: "Not found" }); return; }
  res.json(serializePage(rows[0]));
});

router.patch("/admin/content/pages/:slug", async (req, res): Promise<void> => {
  const { title, content, status } = req.body as { title?: string; content?: string; status?: string };
  const update: Partial<typeof contentPagesTable.$inferInsert> & { updatedAt: Date } = { updatedAt: new Date() };
  if (title !== undefined) update.title = title;
  if (content !== undefined) update.content = content;
  if (status !== undefined) update.status = status;
  const rows = await db
    .update(contentPagesTable)
    .set(update)
    .where(eq(contentPagesTable.slug, req.params.slug))
    .returning();
  if (!rows[0]) { res.status(404).json({ error: "Not found" }); return; }
  res.json(serializePage(rows[0]));
});

// ── Admin: Blog ───────────────────────────────────────────────────────────────
router.get("/admin/content/blog", async (_req, res): Promise<void> => {
  const rows = await db.select().from(blogPostsTable).orderBy(desc(blogPostsTable.createdAt));
  res.json(rows.map(serializeBlog));
});

router.get("/admin/content/blog/:id", async (req, res): Promise<void> => {
  const id = parseInt(req.params.id, 10);
  const rows = await db.select().from(blogPostsTable).where(eq(blogPostsTable.id, id)).limit(1);
  if (!rows[0]) { res.status(404).json({ error: "Not found" }); return; }
  res.json(serializeBlog(rows[0]));
});

router.post("/admin/content/blog", async (req, res): Promise<void> => {
  const { title, slug, content, excerpt, authorName, status } = req.body as Record<string, string>;
  const now = new Date();
  const inserted = await db.insert(blogPostsTable).values({
    title: title ?? "Untitled",
    slug: slug ?? `post-${now.getTime()}`,
    content: content ?? "",
    excerpt: excerpt ?? "",
    authorName: authorName ?? "OREXUP Team",
    status: status ?? "draft",
    publishedAt: status === "published" ? now : null,
  }).returning();
  res.status(201).json(serializeBlog(inserted[0]));
});

router.patch("/admin/content/blog/:id", async (req, res): Promise<void> => {
  const id = parseInt(req.params.id, 10);
  const { title, slug, content, excerpt, authorName, status } = req.body as Record<string, string>;
  const now = new Date();
  const update: Record<string, unknown> = { updatedAt: now };
  if (title !== undefined) update.title = title;
  if (slug !== undefined) update.slug = slug;
  if (content !== undefined) update.content = content;
  if (excerpt !== undefined) update.excerpt = excerpt;
  if (authorName !== undefined) update.authorName = authorName;
  if (status !== undefined) {
    update.status = status;
    if (status === "published") update.publishedAt = now;
  }
  const rows = await db.update(blogPostsTable).set(update as Partial<typeof blogPostsTable.$inferInsert>).where(eq(blogPostsTable.id, id)).returning();
  if (!rows[0]) { res.status(404).json({ error: "Not found" }); return; }
  res.json(serializeBlog(rows[0]));
});

router.delete("/admin/content/blog/:id", async (req, res): Promise<void> => {
  const id = parseInt(req.params.id, 10);
  await db.delete(blogPostsTable).where(eq(blogPostsTable.id, id));
  res.json({ success: true });
});

// ── Admin: Jobs ───────────────────────────────────────────────────────────────
router.get("/admin/content/jobs", async (_req, res): Promise<void> => {
  const rows = await db.select().from(jobListingsTable).orderBy(desc(jobListingsTable.createdAt));
  res.json(rows.map(serializeJob));
});

router.get("/admin/content/jobs/:id", async (req, res): Promise<void> => {
  const id = parseInt(req.params.id, 10);
  const rows = await db.select().from(jobListingsTable).where(eq(jobListingsTable.id, id)).limit(1);
  if (!rows[0]) { res.status(404).json({ error: "Not found" }); return; }
  res.json(serializeJob(rows[0]));
});

router.post("/admin/content/jobs", async (req, res): Promise<void> => {
  const { title, department, location, type, description, requirements, status } = req.body as Record<string, string>;
  const inserted = await db.insert(jobListingsTable).values({
    title: title ?? "Untitled",
    department: department ?? "",
    location: location ?? "Remote",
    type: type ?? "Full-time",
    description: description ?? "",
    requirements: requirements ?? "",
    status: status ?? "open",
  }).returning();
  res.status(201).json(serializeJob(inserted[0]));
});

router.patch("/admin/content/jobs/:id", async (req, res): Promise<void> => {
  const id = parseInt(req.params.id, 10);
  const { title, department, location, type, description, requirements, status } = req.body as Record<string, string>;
  const update: Record<string, unknown> = { updatedAt: new Date() };
  if (title !== undefined) update.title = title;
  if (department !== undefined) update.department = department;
  if (location !== undefined) update.location = location;
  if (type !== undefined) update.type = type;
  if (description !== undefined) update.description = description;
  if (requirements !== undefined) update.requirements = requirements;
  if (status !== undefined) update.status = status;
  const rows = await db.update(jobListingsTable).set(update as Partial<typeof jobListingsTable.$inferInsert>).where(eq(jobListingsTable.id, id)).returning();
  if (!rows[0]) { res.status(404).json({ error: "Not found" }); return; }
  res.json(serializeJob(rows[0]));
});

router.delete("/admin/content/jobs/:id", async (req, res): Promise<void> => {
  const id = parseInt(req.params.id, 10);
  await db.delete(jobListingsTable).where(eq(jobListingsTable.id, id));
  res.json({ success: true });
});

// PUT /admin/content — general content update (type: page | blog | job)
router.put("/admin/content", async (req, res): Promise<void> => {
  const { type, id, data } = req.body as { type?: string; id?: string | number; data?: Record<string, unknown> };
  if (!type || !id || !data) {
    res.status(400).json({ error: "type, id, and data are required." });
    return;
  }
  try {
    if (type === "page") {
      const rows = await db.update(contentPagesTable).set(data).where(eq(contentPagesTable.slug, String(id))).returning();
      if (!rows[0]) { res.status(404).json({ error: "Page not found." }); return; }
      res.json({ updated: true, content: rows[0] });
    } else if (type === "blog") {
      const rows = await db.update(blogPostsTable).set(data).where(eq(blogPostsTable.id, Number(id))).returning();
      if (!rows[0]) { res.status(404).json({ error: "Post not found." }); return; }
      res.json({ updated: true, content: rows[0] });
    } else if (type === "job") {
      const rows = await db.update(jobListingsTable).set(data).where(eq(jobListingsTable.id, Number(id))).returning();
      if (!rows[0]) { res.status(404).json({ error: "Job not found." }); return; }
      res.json({ updated: true, content: rows[0] });
    } else {
      res.status(400).json({ error: "type must be page, blog, or job." });
    }
  } catch (err) {
    logger.error({ err }, "PUT /admin/content error");
    res.status(500).json({ error: "Content update failed." });
  }
});

export default router;

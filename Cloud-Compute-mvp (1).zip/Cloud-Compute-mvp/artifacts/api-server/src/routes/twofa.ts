import { Router, type IRouter } from "express";
import { eq } from "drizzle-orm";
import { authenticator } from "otplib";
import QRCode from "qrcode";
import { db, adminTwoFactorTable } from "@workspace/db";
import {
  GetAdminTwoFactorStatusResponse,
  SetupAdminTwoFactorResponse,
  VerifyAdminTwoFactorBody,
  VerifyAdminTwoFactorResponse,
  DisableAdminTwoFactorResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

const ADMIN_EMAIL = "admin@orexup.com";
const ISSUER = "OREXUP Admin";

async function getRecord() {
  const rows = await db
    .select()
    .from(adminTwoFactorTable)
    .where(eq(adminTwoFactorTable.adminEmail, ADMIN_EMAIL))
    .limit(1);
  return rows[0] ?? null;
}

// Current 2FA status
router.get("/admin/2fa", async (_req, res): Promise<void> => {
  const record = await getRecord();
  res.json(
    GetAdminTwoFactorStatusResponse.parse({ enabled: record?.enabled ?? false }),
  );
});

// Generate a new secret + QR code to scan
router.post("/admin/2fa/setup", async (_req, res): Promise<void> => {
  const secret = authenticator.generateSecret();
  const otpauthUrl = authenticator.keyuri(ADMIN_EMAIL, ISSUER, secret);
  const qrCodeDataUrl = await QRCode.toDataURL(otpauthUrl);

  const existing = await getRecord();
  if (existing) {
    await db
      .update(adminTwoFactorTable)
      .set({ secret, enabled: false, updatedAt: new Date() })
      .where(eq(adminTwoFactorTable.adminEmail, ADMIN_EMAIL));
  } else {
    await db.insert(adminTwoFactorTable).values({
      adminEmail: ADMIN_EMAIL,
      secret,
      enabled: false,
    });
  }

  res.json(
    SetupAdminTwoFactorResponse.parse({ otpauthUrl, qrCodeDataUrl, secret }),
  );
});

// Verify a 6-digit code and enable 2FA
router.post("/admin/2fa/verify", async (req, res): Promise<void> => {
  const parsed = VerifyAdminTwoFactorBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid request body" });
    return;
  }

  const record = await getRecord();
  if (!record) {
    res.status(400).json({ error: "No 2FA setup in progress. Start setup first." });
    return;
  }

  const token = parsed.data.token.replace(/\s/g, "");
  const isValid = authenticator.verify({ token, secret: record.secret });
  if (!isValid) {
    res.status(400).json({ error: "Invalid code. Please try again." });
    return;
  }

  await db
    .update(adminTwoFactorTable)
    .set({ enabled: true, updatedAt: new Date() })
    .where(eq(adminTwoFactorTable.adminEmail, ADMIN_EMAIL));

  res.json(VerifyAdminTwoFactorResponse.parse({ enabled: true }));
});

// Disable 2FA
router.post("/admin/2fa/disable", async (_req, res): Promise<void> => {
  await db
    .update(adminTwoFactorTable)
    .set({ enabled: false, updatedAt: new Date() })
    .where(eq(adminTwoFactorTable.adminEmail, ADMIN_EMAIL));
  res.json(DisableAdminTwoFactorResponse.parse({ enabled: false }));
});

export default router;

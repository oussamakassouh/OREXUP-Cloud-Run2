import { Router, type IRouter } from "express";
import Stripe from "stripe";

const router: IRouter = Router();

function getStripe(): Stripe {
  const key = process.env.STRIPE_SECRET_KEY;
  if (!key) throw new Error("STRIPE_SECRET_KEY is not configured");
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  return new Stripe(key, { apiVersion: (Stripe as any).LATEST_API_VERSION });
}

const PLAN_PRICES: Record<string, Record<string, number>> = {
  standard: { monthly: 900,  annual: 9900  },
  premium:  { monthly: 2900, annual: 29900 },
  custom:   { monthly: 4900, annual: 49900 },
};

const PLAN_NAMES: Record<string, string> = {
  standard: "Starter",
  premium:  "Premium",
  custom:   "Ultimate",
};

function getAppUrl(): string {
  if (process.env.APP_URL) return process.env.APP_URL.replace(/\/$/, "");
  if (process.env.REPLIT_DEV_DOMAIN) return `https://${process.env.REPLIT_DEV_DOMAIN}`;
  return "http://localhost:5173";
}

// GET /billing/stripe-status — no auth required, used by admin UI
router.get("/billing/stripe-status", (_req, res) => {
  const secretKey  = process.env.STRIPE_SECRET_KEY  ?? "";
  const publicKey  = process.env.STRIPE_PUBLISHABLE_KEY ?? "";
  const connected  = secretKey.length > 0 && publicKey.length > 0;
  const mode: "test" | "live" = secretKey.startsWith("sk_live_") ? "live" : "test";
  res.json({ connected, mode, publicKey: connected ? publicKey : null });
});

// POST /billing/checkout — create a Stripe Checkout Session
router.post("/billing/checkout", async (req, res): Promise<void> => {
  const { plan, billing } = req.body as { plan?: string; billing?: string };
  if (!plan || !PLAN_PRICES[plan]) {
    res.status(400).json({ error: "Invalid plan" });
    return;
  }
  const cycle   = billing === "annual" ? "annual" : "monthly";
  const amount  = PLAN_PRICES[plan][cycle];
  const interval: Stripe.PriceCreateParams.Recurring.Interval = cycle === "annual" ? "year" : "month";
  const appUrl  = getAppUrl();

  try {
    const stripe  = getStripe();
    const session = await stripe.checkout.sessions.create({
      mode: "subscription",
      payment_method_types: ["card"],
      line_items: [{
        price_data: {
          currency: "usd",
          unit_amount: amount,
          recurring: { interval },
          product_data: {
            name: `OREXUP ${PLAN_NAMES[plan]} Plan`,
            description: `${cycle === "annual" ? "Annual" : "Monthly"} subscription`,
          },
        },
        quantity: 1,
      }],
      success_url: `${appUrl}/dashboard/checkout/success?session_id={CHECKOUT_SESSION_ID}&plan=${plan}&billing=${cycle}`,
      cancel_url:  `${appUrl}/dashboard/billing`,
      metadata:    { plan, billing: cycle },
    });
    res.json({ url: session.url });
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : "Stripe error";
    res.status(502).json({ error: msg });
  }
});

// GET /billing/session/:id — verify a completed checkout session
router.get("/billing/session/:id", async (req, res): Promise<void> => {
  try {
    const stripe  = getStripe();
    const session = await stripe.checkout.sessions.retrieve(req.params.id);
    res.json({
      status:        session.payment_status,
      plan:          session.metadata?.plan ?? null,
      billing:       session.metadata?.billing ?? null,
      customerEmail: session.customer_details?.email ?? null,
      customerId:    typeof session.customer === "string" ? session.customer : null,
    });
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : "Stripe error";
    res.status(502).json({ error: msg });
  }
});

// POST /billing/portal — create a Stripe Customer Portal session
router.post("/billing/portal", async (req, res): Promise<void> => {
  const { customerId } = req.body as { customerId?: string };
  const appUrl = getAppUrl();

  if (!customerId) {
    res.status(400).json({ error: "No Stripe customer ID provided" });
    return;
  }

  try {
    const stripe  = getStripe();
    const session = await stripe.billingPortal.sessions.create({
      customer:   customerId,
      return_url: `${appUrl}/dashboard/billing`,
    });
    res.json({ url: session.url });
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : "Stripe error";
    res.status(502).json({ error: msg });
  }
});

// POST /billing/webhook — handle Stripe webhook events
router.post("/billing/webhook", async (req, res): Promise<void> => {
  const sig           = req.headers["stripe-signature"] as string | undefined;
  const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;
  let event: Stripe.Event;

  try {
    const stripe = getStripe();
    if (webhookSecret && sig) {
      event = stripe.webhooks.constructEvent(req.body as Buffer, sig, webhookSecret);
    } else {
      const body = req.body as Record<string, unknown>;
      event = body as unknown as Stripe.Event;
    }
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : "Webhook error";
    res.status(400).json({ error: msg });
    return;
  }

  switch (event.type) {
    case "checkout.session.completed":
    case "invoice.payment_succeeded":
    case "customer.subscription.updated":
    case "customer.subscription.deleted":
      break;
    default:
      break;
  }

  res.json({ received: true });
});

export default router;

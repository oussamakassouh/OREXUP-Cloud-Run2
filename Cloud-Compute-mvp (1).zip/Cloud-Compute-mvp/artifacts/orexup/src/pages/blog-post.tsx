import DOMPurify from "dompurify";
import { Layout } from "@/components/layout";
import { useGetPublicBlogPost } from "@workspace/api-client-react";
import { Link } from "wouter";
import { Loader2, ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function BlogPostPage({ params }: { params: { id: string } }) {
  const id = parseInt(params.id, 10);
  const { data: post, isLoading, isError } = useGetPublicBlogPost(id);

  return (
    <Layout>
      <div className="container mx-auto px-4 py-16 max-w-3xl">
        <Link href="/blog">
          <Button variant="ghost" size="sm" className="mb-8 -ml-2 text-muted-foreground">
            <ArrowLeft className="h-4 w-4 mr-2" />Back to Blog
          </Button>
        </Link>

        {isLoading && (
          <div className="flex items-center justify-center py-24">
            <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
          </div>
        )}

        {isError && (
          <div className="py-24 text-center">
            <p className="text-muted-foreground">Post not found or not yet published.</p>
          </div>
        )}

        {post && (
          <>
            <h1 className="text-3xl md:text-4xl font-bold font-heading tracking-tight mb-3">{post.title}</h1>
            <div className="flex items-center gap-3 text-sm text-muted-foreground mb-10">
              <span>{post.authorName}</span>
              {post.publishedAt && (
                <><span>·</span><span>{new Date(post.publishedAt).toLocaleDateString("en-US", { month: "long", day: "numeric", year: "numeric" })}</span></>
              )}
            </div>
            <div
              className="prose prose-invert prose-sm md:prose-base max-w-none"
              dangerouslySetInnerHTML={{ __html: DOMPurify.sanitize(post.content) }}
            />
          </>
        )}
      </div>
    </Layout>
  );
}

import { Router, type IRouter, type Request, type Response } from "express";
import { Resend } from "resend";
import { adminAuth } from "../middlewares/adminAuth";
import { strictLimiter } from "../middlewares/rateLimiter";
import { logger } from "../lib/logger";

const router: IRouter = Router();

function escapeHtml(str: string): string {
  return str
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#x27;");
}

function getResend(): Resend | null {
  return process.env.RESEND_API_KEY ? new Resend(process.env.RESEND_API_KEY) : null;
}

// POST /notification/send-email — send a transactional email (admin-protected)
router.post(
  "/notification/send-email",
  adminAuth,
  strictLimiter,
  async (req: Request, res: Response): Promise<void> => {
    const { to, subject, html, text } = req.body as {
      to?: string;
      subject?: string;
      html?: string;
      text?: string;
    };
    if (!to || !subject || (!html && !text)) {
      res.status(400).json({ error: "to, subject, and html or text are required." });
      return;
    }
    const resend = getResend();
    if (!resend) {
      res.status(503).json({ error: "Email service not configured (RESEND_API_KEY missing)." });
      return;
    }
    try {
      const result = await resend.emails.send({
        from: "OREXUP <noreply@orexup.com>",
        to,
        subject,
        html: html ?? `<p>${text}</p>`,
      });
      logger.info({ to, subject }, "Notification email sent");
      res.json({ sent: true, id: result.data?.id ?? null });
    } catch (err) {
      logger.error({ err }, "Send email error");
      res.status(502).json({ error: "Failed to send email." });
    }
  }
);

// POST /notification/security-alert — send a security alert email (admin-protected)
router.post(
  "/notification/security-alert",
  adminAuth,
  strictLimiter,
  async (req: Request, res: Response): Promise<void> => {
    const { to, event, description, ip } = req.body as {
      to?: string;
      event?: string;
      description?: string;
      ip?: string;
    };
    if (!to || !event) {
      res.status(400).json({ error: "to and event are required." });
      return;
    }
    const resend = getResend();
    if (!resend) {
      res.status(503).json({ error: "Email service not configured." });
      return;
    }
    try {
      const result = await resend.emails.send({
        from: "OREXUP Security <security@orexup.com>",
        to,
        subject: `Security Alert: ${event}`,
        html: `
          <div style="font-family:sans-serif;max-width:480px;margin:0 auto;padding:32px 24px">
            <h2 style="color:#ef4444;margin-bottom:8px">Security Alert</h2>
            <p style="color:#555;font-size:16px;font-weight:600">${escapeHtml(event)}</p>
            ${description ? `<p style="color:#555">${escapeHtml(description)}</p>` : ""}
            ${ip ? `<p style="color:#999;font-size:12px">Source IP: ${escapeHtml(ip)}</p>` : ""}
            <p style="color:#999;font-size:12px;margin-top:24px">
              If this wasn't you, change your password immediately at
              <a href="https://orexup.com/reset-password">orexup.com</a>.
            </p>
          </div>
        `,
      });
      logger.info({ to, event }, "Security alert sent");
      res.json({ sent: true, id: result.data?.id ?? null });
    } catch (err) {
      logger.error({ err }, "Security alert error");
      res.status(502).json({ error: "Failed to send security alert." });
    }
  }
);

export default router;

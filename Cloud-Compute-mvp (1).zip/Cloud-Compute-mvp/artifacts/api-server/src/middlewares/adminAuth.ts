import { createHmac, timingSafeEqual } from "crypto";
import type { Request, Response, NextFunction } from "express";

const COOKIE_NAME = "orexup_admin_session";
const SESSION_TTL_MS = 24 * 60 * 60 * 1000; // 24 hours

const FALLBACK_SECRET = "orexup-admin-dev-secret-change-in-production";

function secret(): string {
  const s = process.env.ADMIN_SESSION_SECRET ?? FALLBACK_SECRET;
  if (s === FALLBACK_SECRET && process.env.NODE_ENV === "production") {
    console.error("[SECURITY] ADMIN_SESSION_SECRET is not set — using insecure default in production!");
  }
  return s;
}

function sign(ts: number): string {
  return createHmac("sha256", secret()).update(String(ts)).digest("hex");
}

function verify(token: string): boolean {
  const parts = token.split(".");
  if (parts.length !== 2) return false;
  const ts = Number(parts[0]);
  const mac = parts[1];
  if (!ts || isNaN(ts)) return false;
  if (Date.now() - ts > SESSION_TTL_MS) return false;
  const expected = sign(ts);
  try {
    return timingSafeEqual(Buffer.from(mac, "hex"), Buffer.from(expected, "hex"));
  } catch {
    return false;
  }
}

export function createSessionToken(): string {
  const ts = Date.now();
  return `${ts}.${sign(ts)}`;
}

export function setAdminSession(res: Response): void {
  res.cookie(COOKIE_NAME, createSessionToken(), {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    maxAge: SESSION_TTL_MS,
    path: "/",
  });
}

export function clearAdminSession(res: Response): void {
  res.clearCookie(COOKIE_NAME, { path: "/" });
}

export function isValidAdminToken(token: string | undefined): boolean {
  return !!token && verify(token);
}

export function adminAuth(req: Request, res: Response, next: NextFunction): void {
  const token = req.cookies?.[COOKIE_NAME] as string | undefined;
  if (isValidAdminToken(token)) {
    next();
    return;
  }
  res.status(401).json({ error: "Admin authentication required" });
}

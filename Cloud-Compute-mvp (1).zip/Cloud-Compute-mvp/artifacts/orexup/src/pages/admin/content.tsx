import { useState } from "react";
import DOMPurify from "dompurify";
import { AdminLayout } from "@/components/admin-layout";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription,
} from "@/components/ui/dialog";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  FileText, PenLine, Plus, Trash2, Eye, Save, Globe, EyeOff, Briefcase, Loader2,
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";
import {
  useGetAdminContentPages,
  useUpdateAdminContentPage,
  useGetAdminBlogPosts,
  useCreateAdminBlogPost,
  useUpdateAdminBlogPost,
  useDeleteAdminBlogPost,
  useGetAdminJobListings,
  useCreateAdminJobListing,
  useUpdateAdminJobListing,
  useDeleteAdminJobListing,
  getGetAdminContentPagesQueryKey,
  getGetAdminBlogPostsQueryKey,
  getGetAdminJobListingsQueryKey,
  type ContentPage,
  type BlogPost,
  type JobListing,
  type UpdateContentPageRequestStatus,
  type UpsertBlogPostRequestStatus,
  type UpsertJobListingRequestStatus,
} from "@workspace/api-client-react";

// ─── helpers ──────────────────────────────────────────────────────────────────
function fmtDate(iso: string) {
  return new Date(iso).toLocaleString("en-US", {
    month: "short", day: "numeric", year: "numeric", hour: "2-digit", minute: "2-digit",
  });
}

function StatusBadge({ status }: { status: string }) {
  const published = status === "published" || status === "open";
  return (
    <Badge variant="outline" className={`text-xs ${published ? "bg-green-500/10 text-green-400 border-green-500/20" : "bg-yellow-500/10 text-yellow-400 border-yellow-500/20"}`}>
      {status}
    </Badge>
  );
}

// ─── Pages Tab ────────────────────────────────────────────────────────────────
function PagesTab() {
  const { toast } = useToast();
  const qc = useQueryClient();
  const { data: pages = [], isLoading } = useGetAdminContentPages();
  const updateMutation = useUpdateAdminContentPage({
    mutation: {
      onSuccess: () => {
        qc.invalidateQueries({ queryKey: getGetAdminContentPagesQueryKey() });
        toast({ title: "Saved", description: "Page updated successfully." });
      },
      onError: () => toast({ title: "Error", description: "Failed to save page.", variant: "destructive" }),
    },
  });

  const [selected, setSelected] = useState<ContentPage | null>(null);
  const [editTitle, setEditTitle] = useState("");
  const [editContent, setEditContent] = useState("");
  const [editorTab, setEditorTab] = useState<"write" | "preview">("write");

  function openPage(p: ContentPage) {
    setSelected(p);
    setEditTitle(p.title);
    setEditContent(p.content);
    setEditorTab("write");
  }

  function handleSave(status?: string) {
    if (!selected) return;
    updateMutation.mutate(
      { slug: selected.slug, data: { title: editTitle, content: editContent, ...(status ? { status: status as UpdateContentPageRequestStatus } : {}) } },
      {
        onSuccess: (updated) => {
          setSelected(updated);
          setEditTitle(updated.title);
          setEditContent(updated.content);
        },
      }
    );
  }

  if (isLoading) {
    return <div className="flex items-center gap-2 text-muted-foreground py-12 justify-center"><Loader2 className="h-5 w-5 animate-spin" /> Loading pages…</div>;
  }

  return (
    <div className="flex gap-6 h-full">
      {/* Page list */}
      <div className="w-56 shrink-0 space-y-1">
        {pages.map((p) => (
          <button
            key={p.slug}
            onClick={() => openPage(p)}
            className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-md text-sm text-left transition ${
              selected?.slug === p.slug
                ? "bg-primary/10 text-primary font-medium"
                : "text-muted-foreground hover:bg-white/5 hover:text-foreground"
            }`}
          >
            <FileText className="h-3.5 w-3.5 shrink-0" />
            <span className="truncate">{p.title}</span>
          </button>
        ))}
      </div>

      {/* Editor */}
      {selected ? (
        <div className="flex-1 min-w-0 space-y-4">
          <Card className="border-white/5 bg-card/50">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between gap-4">
                <div className="flex-1 min-w-0">
                  <Input
                    value={editTitle}
                    onChange={(e) => setEditTitle(e.target.value)}
                    className="bg-black/20 text-lg font-semibold h-9 border-transparent focus:border-white/20"
                    placeholder="Page title"
                  />
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <StatusBadge status={selected.status} />
                  <span className="text-xs text-muted-foreground hidden xl:block">
                    Updated {fmtDate(selected.updatedAt)}
                  </span>
                </div>
              </div>
              <div className="text-xs text-muted-foreground mt-1">
                <span className="font-mono bg-black/20 px-1.5 py-0.5 rounded">/{selected.slug}</span>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <Tabs value={editorTab} onValueChange={(v) => setEditorTab(v as "write" | "preview")}>
                <TabsList className="bg-black/20 h-8">
                  <TabsTrigger value="write" className="text-xs h-7"><PenLine className="h-3 w-3 mr-1.5" />Write</TabsTrigger>
                  <TabsTrigger value="preview" className="text-xs h-7"><Eye className="h-3 w-3 mr-1.5" />Preview</TabsTrigger>
                </TabsList>
                <TabsContent value="write">
                  <Textarea
                    value={editContent}
                    onChange={(e) => setEditContent(e.target.value)}
                    placeholder="Write your content here (HTML supported)…"
                    className="bg-black/20 min-h-[380px] font-mono text-sm resize-y"
                  />
                </TabsContent>
                <TabsContent value="preview">
                  <div
                    className="min-h-[380px] p-4 rounded-md bg-black/20 prose prose-invert prose-sm max-w-none"
                    dangerouslySetInnerHTML={{ __html: DOMPurify.sanitize(editContent || "<p class='text-muted-foreground'>Nothing to preview yet.</p>") }}
                  />
                </TabsContent>
              </Tabs>

              <div className="flex items-center gap-3 pt-1">
                <Button
                  onClick={() => handleSave()}
                  disabled={updateMutation.isPending}
                  size="sm"
                >
                  {updateMutation.isPending ? <Loader2 className="h-3.5 w-3.5 animate-spin mr-2" /> : <Save className="h-3.5 w-3.5 mr-2" />}
                  Save
                </Button>
                {selected.status !== "published" ? (
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleSave("published")}
                    disabled={updateMutation.isPending}
                    className="border-green-500/30 text-green-400 hover:bg-green-500/10"
                  >
                    <Globe className="h-3.5 w-3.5 mr-2" />
                    Publish
                  </Button>
                ) : (
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleSave("draft")}
                    disabled={updateMutation.isPending}
                    className="border-yellow-500/30 text-yellow-400 hover:bg-yellow-500/10"
                  >
                    <EyeOff className="h-3.5 w-3.5 mr-2" />
                    Unpublish
                  </Button>
                )}
                <span className="text-xs text-muted-foreground xl:hidden ml-auto">
                  Updated {fmtDate(selected.updatedAt)}
                </span>
              </div>
            </CardContent>
          </Card>
        </div>
      ) : (
        <div className="flex-1 flex items-center justify-center text-muted-foreground text-sm">
          Select a page from the list to edit it.
        </div>
      )}
    </div>
  );
}

// ─── Blog Tab ─────────────────────────────────────────────────────────────────
const EMPTY_POST = { title: "", slug: "", excerpt: "", content: "", authorName: "OREXUP Team", status: "draft" };

function BlogTab() {
  const { toast } = useToast();
  const qc = useQueryClient();
  const { data: posts = [], isLoading } = useGetAdminBlogPosts();
  const createMutation = useCreateAdminBlogPost({ mutation: { onSuccess: () => { qc.invalidateQueries({ queryKey: getGetAdminBlogPostsQueryKey() }); toast({ title: "Post created" }); setDialogOpen(false); }, onError: () => toast({ title: "Error", variant: "destructive" }) } });
  const updateMutation = useUpdateAdminBlogPost({ mutation: { onSuccess: () => { qc.invalidateQueries({ queryKey: getGetAdminBlogPostsQueryKey() }); toast({ title: "Post updated" }); setDialogOpen(false); }, onError: () => toast({ title: "Error", variant: "destructive" }) } });
  const deleteMutation = useDeleteAdminBlogPost({ mutation: { onSuccess: () => { qc.invalidateQueries({ queryKey: getGetAdminBlogPostsQueryKey() }); toast({ title: "Post deleted" }); setDeleteTarget(null); }, onError: () => toast({ title: "Error", variant: "destructive" }) } });

  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState<BlogPost | null>(null);
  const [form, setForm] = useState(EMPTY_POST);
  const [previewTab, setPreviewTab] = useState<"write" | "preview">("write");
  const [deleteTarget, setDeleteTarget] = useState<BlogPost | null>(null);

  function openCreate() { setEditing(null); setForm(EMPTY_POST); setPreviewTab("write"); setDialogOpen(true); }
  function openEdit(p: BlogPost) {
    setEditing(p);
    setForm({ title: p.title, slug: p.slug, excerpt: p.excerpt, content: p.content, authorName: p.authorName, status: p.status });
    setPreviewTab("write");
    setDialogOpen(true);
  }
  function handleSubmit(status?: string) {
    const merged = { ...form, ...(status ? { status } : {}) };
    if (!merged.slug) merged.slug = merged.title.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "") || `post-${Date.now()}`;
    const data = { ...merged, status: merged.status as UpsertBlogPostRequestStatus };
    if (editing) {
      updateMutation.mutate({ id: editing.id, data });
    } else {
      createMutation.mutate({ data });
    }
  }
  const busy = createMutation.isPending || updateMutation.isPending;

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <p className="text-sm text-muted-foreground">{posts.length} post{posts.length !== 1 ? "s" : ""}</p>
        <Button size="sm" onClick={openCreate}><Plus className="h-4 w-4 mr-2" />Create Post</Button>
      </div>

      {isLoading ? (
        <div className="flex items-center gap-2 text-muted-foreground py-8 justify-center"><Loader2 className="h-5 w-5 animate-spin" /> Loading…</div>
      ) : posts.length === 0 ? (
        <Card className="border-white/5 bg-card/50">
          <CardContent className="py-16 text-center text-muted-foreground text-sm">No posts yet. Create your first one.</CardContent>
        </Card>
      ) : (
        <Card className="border-white/5 bg-card/50">
          <div className="divide-y divide-white/5">
            {posts.map((p) => (
              <div key={p.id} className="flex items-center justify-between px-5 py-3.5 hover:bg-white/[0.02] transition">
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2.5">
                    <span className="text-sm font-medium truncate">{p.title}</span>
                    <StatusBadge status={p.status} />
                  </div>
                  <p className="text-xs text-muted-foreground mt-0.5 truncate">{p.excerpt || "No excerpt"}</p>
                </div>
                <div className="flex items-center gap-2 ml-4 shrink-0">
                  <span className="text-xs text-muted-foreground hidden sm:block">{fmtDate(p.updatedAt)}</span>
                  {p.status !== "published" ? (
                    <Button size="sm" variant="ghost" className="text-green-400 hover:text-green-300 hover:bg-green-500/10 h-7 px-2"
                      onClick={() => updateMutation.mutate({ id: p.id, data: { status: "published" } })}>
                      <Globe className="h-3.5 w-3.5 mr-1" />Publish
                    </Button>
                  ) : (
                    <Button size="sm" variant="ghost" className="text-yellow-400 hover:text-yellow-300 hover:bg-yellow-500/10 h-7 px-2"
                      onClick={() => updateMutation.mutate({ id: p.id, data: { status: "draft" } })}>
                      <EyeOff className="h-3.5 w-3.5 mr-1" />Draft
                    </Button>
                  )}
                  <Button size="sm" variant="ghost" className="h-7 px-2" onClick={() => openEdit(p)}><PenLine className="h-3.5 w-3.5" /></Button>
                  <Button size="sm" variant="ghost" className="h-7 px-2 text-red-400 hover:text-red-300 hover:bg-red-500/10" onClick={() => setDeleteTarget(p)}>
                    <Trash2 className="h-3.5 w-3.5" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </Card>
      )}

      {/* Create/Edit Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editing ? "Edit Post" : "Create Post"}</DialogTitle>
            <DialogDescription>Fill in the post details below.</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label>Title</Label>
                <Input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} className="bg-black/20" placeholder="Post title" />
              </div>
              <div className="space-y-1.5">
                <Label>Slug</Label>
                <Input value={form.slug} onChange={(e) => setForm({ ...form, slug: e.target.value })} className="bg-black/20 font-mono text-sm" placeholder="auto-generated" />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label>Author</Label>
                <Input value={form.authorName} onChange={(e) => setForm({ ...form, authorName: e.target.value })} className="bg-black/20" />
              </div>
              <div className="space-y-1.5">
                <Label>Status</Label>
                <Select value={form.status} onValueChange={(v) => setForm({ ...form, status: v })}>
                  <SelectTrigger className="bg-black/20"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="draft">Draft</SelectItem>
                    <SelectItem value="published">Published</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-1.5">
              <Label>Excerpt</Label>
              <Input value={form.excerpt} onChange={(e) => setForm({ ...form, excerpt: e.target.value })} className="bg-black/20" placeholder="Short summary shown in listings" />
            </div>
            <div className="space-y-1.5">
              <Label>Content</Label>
              <Tabs value={previewTab} onValueChange={(v) => setPreviewTab(v as "write" | "preview")}>
                <TabsList className="bg-black/20 h-8">
                  <TabsTrigger value="write" className="text-xs h-7"><PenLine className="h-3 w-3 mr-1.5" />Write</TabsTrigger>
                  <TabsTrigger value="preview" className="text-xs h-7"><Eye className="h-3 w-3 mr-1.5" />Preview</TabsTrigger>
                </TabsList>
                <TabsContent value="write">
                  <Textarea value={form.content} onChange={(e) => setForm({ ...form, content: e.target.value })} className="bg-black/20 min-h-[260px] font-mono text-sm resize-y" placeholder="HTML content…" />
                </TabsContent>
                <TabsContent value="preview">
                  <div className="min-h-[260px] p-4 rounded-md bg-black/20 prose prose-invert prose-sm max-w-none" dangerouslySetInnerHTML={{ __html: DOMPurify.sanitize(form.content || "<p class='text-muted-foreground'>Nothing to preview.</p>") }} />
                </TabsContent>
              </Tabs>
            </div>
          </div>
          <DialogFooter className="gap-2">
            <Button variant="ghost" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={() => handleSubmit()} disabled={busy}>
              {busy && <Loader2 className="h-4 w-4 animate-spin mr-2" />}
              <Save className="h-4 w-4 mr-2" />Save Changes
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirm */}
      <AlertDialog open={!!deleteTarget} onOpenChange={(o) => { if (!o) setDeleteTarget(null); }}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete post?</AlertDialogTitle>
            <AlertDialogDescription>"{deleteTarget?.title}" will be permanently deleted.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction className="bg-red-500 hover:bg-red-600" onClick={() => deleteTarget && deleteMutation.mutate({ id: deleteTarget.id })}>Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

// ─── Careers Tab ──────────────────────────────────────────────────────────────
const EMPTY_JOB = { title: "", department: "", location: "Remote", type: "Full-time", description: "", requirements: "", status: "open" };

function CareersTab() {
  const { toast } = useToast();
  const qc = useQueryClient();
  const { data: jobs = [], isLoading } = useGetAdminJobListings();
  const createMutation = useCreateAdminJobListing({ mutation: { onSuccess: () => { qc.invalidateQueries({ queryKey: getGetAdminJobListingsQueryKey() }); toast({ title: "Job created" }); setDialogOpen(false); }, onError: () => toast({ title: "Error", variant: "destructive" }) } });
  const updateMutation = useUpdateAdminJobListing({ mutation: { onSuccess: () => { qc.invalidateQueries({ queryKey: getGetAdminJobListingsQueryKey() }); toast({ title: "Job updated" }); setDialogOpen(false); }, onError: () => toast({ title: "Error", variant: "destructive" }) } });
  const deleteMutation = useDeleteAdminJobListing({ mutation: { onSuccess: () => { qc.invalidateQueries({ queryKey: getGetAdminJobListingsQueryKey() }); toast({ title: "Job removed" }); setDeleteTarget(null); }, onError: () => toast({ title: "Error", variant: "destructive" }) } });

  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState<JobListing | null>(null);
  const [form, setForm] = useState(EMPTY_JOB);
  const [deleteTarget, setDeleteTarget] = useState<JobListing | null>(null);

  function openCreate() { setEditing(null); setForm(EMPTY_JOB); setDialogOpen(true); }
  function openEdit(j: JobListing) { setEditing(j); setForm({ title: j.title, department: j.department, location: j.location, type: j.type, description: j.description, requirements: j.requirements, status: j.status }); setDialogOpen(true); }
  function handleSubmit() {
    const data = { ...form, status: form.status as UpsertJobListingRequestStatus };
    if (editing) updateMutation.mutate({ id: editing.id, data });
    else createMutation.mutate({ data });
  }
  const busy = createMutation.isPending || updateMutation.isPending;

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <p className="text-sm text-muted-foreground">{jobs.length} listing{jobs.length !== 1 ? "s" : ""}</p>
        <Button size="sm" onClick={openCreate}><Plus className="h-4 w-4 mr-2" />Create Job</Button>
      </div>

      {isLoading ? (
        <div className="flex items-center gap-2 text-muted-foreground py-8 justify-center"><Loader2 className="h-5 w-5 animate-spin" /> Loading…</div>
      ) : jobs.length === 0 ? (
        <Card className="border-white/5 bg-card/50">
          <CardContent className="py-16 text-center text-muted-foreground text-sm">No job listings yet.</CardContent>
        </Card>
      ) : (
        <Card className="border-white/5 bg-card/50">
          <div className="divide-y divide-white/5">
            {jobs.map((j) => (
              <div key={j.id} className="flex items-center justify-between px-5 py-3.5 hover:bg-white/[0.02] transition">
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2.5 flex-wrap">
                    <span className="text-sm font-medium truncate">{j.title}</span>
                    <StatusBadge status={j.status} />
                    {j.department && <span className="text-xs text-muted-foreground">{j.department}</span>}
                    <span className="text-xs text-muted-foreground">{j.type} · {j.location}</span>
                  </div>
                </div>
                <div className="flex items-center gap-2 ml-4 shrink-0">
                  {j.status === "open" ? (
                    <Button size="sm" variant="ghost" className="text-yellow-400 hover:text-yellow-300 hover:bg-yellow-500/10 h-7 px-2"
                      onClick={() => updateMutation.mutate({ id: j.id, data: { status: "closed" } })}>
                      Close Job
                    </Button>
                  ) : (
                    <Button size="sm" variant="ghost" className="text-green-400 hover:text-green-300 hover:bg-green-500/10 h-7 px-2"
                      onClick={() => updateMutation.mutate({ id: j.id, data: { status: "open" } })}>
                      Reopen
                    </Button>
                  )}
                  <Button size="sm" variant="ghost" className="h-7 px-2" onClick={() => openEdit(j)}><PenLine className="h-3.5 w-3.5" /></Button>
                  <Button size="sm" variant="ghost" className="h-7 px-2 text-red-400 hover:text-red-300 hover:bg-red-500/10" onClick={() => setDeleteTarget(j)}>
                    <Trash2 className="h-3.5 w-3.5" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </Card>
      )}

      {/* Create/Edit Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editing ? "Edit Job" : "Create Job"}</DialogTitle>
            <DialogDescription>Fill in the job listing details.</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5 col-span-2">
                <Label>Job Title</Label>
                <Input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} className="bg-black/20" placeholder="e.g. Senior Frontend Engineer" />
              </div>
              <div className="space-y-1.5">
                <Label>Department</Label>
                <Input value={form.department} onChange={(e) => setForm({ ...form, department: e.target.value })} className="bg-black/20" placeholder="e.g. Engineering" />
              </div>
              <div className="space-y-1.5">
                <Label>Location</Label>
                <Input value={form.location} onChange={(e) => setForm({ ...form, location: e.target.value })} className="bg-black/20" placeholder="e.g. Remote" />
              </div>
              <div className="space-y-1.5">
                <Label>Type</Label>
                <Select value={form.type} onValueChange={(v) => setForm({ ...form, type: v })}>
                  <SelectTrigger className="bg-black/20"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Full-time">Full-time</SelectItem>
                    <SelectItem value="Part-time">Part-time</SelectItem>
                    <SelectItem value="Contract">Contract</SelectItem>
                    <SelectItem value="Internship">Internship</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label>Status</Label>
                <Select value={form.status} onValueChange={(v) => setForm({ ...form, status: v })}>
                  <SelectTrigger className="bg-black/20"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="open">Open</SelectItem>
                    <SelectItem value="closed">Closed</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-1.5">
              <Label>Description</Label>
              <Textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} className="bg-black/20 min-h-[140px] font-mono text-sm" placeholder="Role description and responsibilities (HTML supported)…" />
            </div>
            <div className="space-y-1.5">
              <Label>Requirements</Label>
              <Textarea value={form.requirements} onChange={(e) => setForm({ ...form, requirements: e.target.value })} className="bg-black/20 min-h-[120px] font-mono text-sm" placeholder="Skills and experience required (HTML supported)…" />
            </div>
          </div>
          <DialogFooter className="gap-2">
            <Button variant="ghost" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleSubmit} disabled={busy}>
              {busy && <Loader2 className="h-4 w-4 animate-spin mr-2" />}
              <Save className="h-4 w-4 mr-2" />Save Changes
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirm */}
      <AlertDialog open={!!deleteTarget} onOpenChange={(o) => { if (!o) setDeleteTarget(null); }}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Remove job listing?</AlertDialogTitle>
            <AlertDialogDescription>"{deleteTarget?.title}" will be permanently removed.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction className="bg-red-500 hover:bg-red-600" onClick={() => deleteTarget && deleteMutation.mutate({ id: deleteTarget.id })}>Remove</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

// ─── Main Page ────────────────────────────────────────────────────────────────
export default function AdminContentPage() {
  return (
    <AdminLayout title="Content Management">
      <div className="space-y-6">
        <Card className="border-white/5 bg-card/50">
          <CardHeader>
            <CardTitle>Content Management</CardTitle>
            <CardDescription>Manage pages, blog posts, and job listings.</CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="pages" className="w-full">
              <TabsList className="bg-black/20 mb-6">
                <TabsTrigger value="pages" className="gap-2"><FileText className="h-4 w-4" />Pages</TabsTrigger>
                <TabsTrigger value="blog" className="gap-2"><PenLine className="h-4 w-4" />Blog</TabsTrigger>
                <TabsTrigger value="careers" className="gap-2"><Briefcase className="h-4 w-4" />Careers</TabsTrigger>
              </TabsList>
              <TabsContent value="pages"><PagesTab /></TabsContent>
              <TabsContent value="blog"><BlogTab /></TabsContent>
              <TabsContent value="careers"><CareersTab /></TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </AdminLayout>
  );
}

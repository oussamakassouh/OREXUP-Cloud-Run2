import { Layout } from "@/components/layout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { motion } from "framer-motion";
import { Link } from "wouter";
import { Cloud, Zap, Cpu, Brain, Check } from "lucide-react";
import { useState } from "react";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { DemoGraphic } from "@/components/demo-graphic";
import { useI18n } from "@/lib/i18n";

const FEATURE_ICONS = [Cloud, Zap, Cpu, Brain];

export default function Home() {
  const [annualBilling, setAnnualBilling] = useState(true);
  const { t } = useI18n();

  return (
    <Layout>
      {/* Hero Section */}
      <section className="relative pt-24 pb-32 overflow-hidden">
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#80808012_1px,transparent_1px),linear-gradient(to_bottom,#80808012_1px,transparent_1px)] bg-[size:24px_24px] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_0%,#000_70%,transparent_100%)]"></div>
        <div className="container mx-auto px-4 relative z-10 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="max-w-4xl mx-auto"
          >
            <h1 className="text-5xl md:text-7xl font-bold font-heading tracking-tight mb-6 leading-tight">
              {t.home.heroTitle} <span className="text-primary">{t.home.heroTitleHighlight}</span>
            </h1>

            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Link href="/signup">
                <Button size="lg" className="w-full sm:w-auto h-12 px-8 text-base" data-testid="button-hero-cta-primary">
                  {t.home.heroCta}
                </Button>
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Demo Graphic */}
      <section className="pb-24 relative">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="max-w-4xl mx-auto"
          >
            <div className="text-center mb-10">
              <h2 className="text-3xl font-bold font-heading mb-3">{t.home.demoTitle}</h2>
              <p className="text-muted-foreground">{t.home.demoSubtitle}</p>
            </div>
            <DemoGraphic />
          </motion.div>
        </div>
      </section>

      {/* Features */}
      <section className="py-24" id="features">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold font-heading mb-4">{t.home.featuresTitle}</h2>
            <p className="text-muted-foreground">{t.home.featuresSubtitle}</p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {t.home.features.map((feature, i) => {
              const Icon = FEATURE_ICONS[i];
              return (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1 }}
                >
                  <Card className="h-full bg-card/50 border-white/5 hover:border-primary/50 transition-colors">
                    <CardHeader>
                      <Icon className="h-10 w-10 text-primary mb-4" />
                      <CardTitle>{feature.title}</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-sm text-muted-foreground">{feature.desc}</p>
                    </CardContent>
                  </Card>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Pricing */}
      <section className="py-24" id="pricing">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold font-heading mb-6">{t.home.pricingTitle}</h2>
            <div className="flex items-center justify-center gap-4">
              <Label htmlFor="billing-toggle" className={!annualBilling ? "text-foreground" : "text-muted-foreground"}>{t.home.monthly}</Label>
              <Switch
                id="billing-toggle"
                checked={annualBilling}
                onCheckedChange={setAnnualBilling}
                data-testid="switch-billing-cycle"
              />
              <Label htmlFor="billing-toggle" className={annualBilling ? "text-foreground" : "text-muted-foreground"}>
                {t.home.annual} <span className="ml-1 text-xs text-primary bg-primary/10 px-2 py-0.5 rounded-full">{t.home.save}</span>
              </Label>
            </div>
          </div>

          <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            {/* Starter */}
            <Card className="border-white/5 bg-card/30 flex flex-col">
              <CardHeader>
                <CardTitle>{t.home.starterName}</CardTitle>
                <CardDescription>{t.home.starterDesc}</CardDescription>
                <div className="mt-4">
                  <span className="text-4xl font-bold font-mono">${annualBilling ? "99" : "9"}</span>
                  <span className="text-muted-foreground">/{annualBilling ? t.home.year : t.home.month}</span>
                </div>
              </CardHeader>
              <CardContent className="flex-1">
                <p className="text-sm font-medium mb-3">{t.home.includes}</p>
                <ul className="space-y-3 text-sm">
                  <li className="flex items-center gap-2">
                    <Check className="h-4 w-4 text-primary shrink-0" />
                    {t.home.starterFeature}
                  </li>
                </ul>
              </CardContent>
              <CardFooter>
                <Link href="/signup?plan=standard" className="w-full">
                  <Button variant="outline" className="w-full" data-testid="button-pricing-starter">{t.home.connectCta}</Button>
                </Link>
              </CardFooter>
            </Card>

            {/* Premium */}
            <Card className="border-primary bg-card relative flex flex-col shadow-2xl shadow-primary/10 scale-105 z-10">
              <div className="absolute top-0 inset-x-0 h-1 bg-primary"></div>
              <CardHeader>
                <CardTitle className="text-primary">{t.home.premiumName}</CardTitle>
                <CardDescription>{t.home.premiumDesc}</CardDescription>
                <div className="mt-4">
                  <span className="text-4xl font-bold font-mono">${annualBilling ? "299" : "29"}</span>
                  <span className="text-muted-foreground">/{annualBilling ? t.home.year : t.home.month}</span>
                </div>
              </CardHeader>
              <CardContent className="flex-1">
                <p className="text-sm font-medium mb-3">{t.home.includes}</p>
                <ul className="space-y-3 text-sm">
                  <li className="flex items-center gap-2">
                    <Check className="h-4 w-4 text-primary shrink-0" />
                    {t.home.premiumFeature}
                  </li>
                </ul>
              </CardContent>
              <CardFooter>
                <Link href="/signup?plan=premium" className="w-full">
                  <Button className="w-full" data-testid="button-pricing-premium">{t.home.connectCta}</Button>
                </Link>
              </CardFooter>
            </Card>

            {/* Ultimate */}
            <Card className="border-white/5 bg-card/30 flex flex-col">
              <CardHeader>
                <CardTitle>{t.home.ultimateName}</CardTitle>
                <CardDescription>{t.home.ultimateDesc}</CardDescription>
                <div className="mt-4">
                  <span className="text-4xl font-bold font-mono">${annualBilling ? "499" : "49"}</span>
                  <span className="text-muted-foreground">/{annualBilling ? t.home.year : t.home.month}</span>
                </div>
              </CardHeader>
              <CardContent className="flex-1">
                <p className="text-sm font-medium mb-3">{t.home.includes}</p>
                <ul className="space-y-3 text-sm">
                  <li className="flex items-center gap-2">
                    <Check className="h-4 w-4 text-primary shrink-0" />
                    {t.home.ultimateFeature}
                  </li>
                </ul>
              </CardContent>
              <CardFooter>
                <Link href="/signup?plan=custom" className="w-full">
                  <Button variant="outline" className="w-full" data-testid="button-pricing-ultimate">{t.home.connectCta}</Button>
                </Link>
              </CardFooter>
            </Card>
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="py-24 border-t border-black/5 dark:border-white/5" id="faq">
        <div className="container mx-auto px-4 max-w-3xl">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            <h2 className="text-3xl font-bold font-heading text-center mb-12">{t.faq.title}</h2>
            <Accordion type="single" collapsible className="space-y-3">
              {t.faq.items.map((item, i) => (
                <AccordionItem
                  key={i}
                  value={`faq-${i}`}
                  className="border border-black/10 dark:border-white/10 rounded-xl px-6 bg-card/40 dark:bg-card/30 shadow-sm"
                >
                  <AccordionTrigger className="text-left font-medium py-5 hover:no-underline">
                    {item.q}
                  </AccordionTrigger>
                  <AccordionContent className="text-muted-foreground text-sm pb-5 leading-relaxed">
                    {item.a}
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </motion.div>
        </div>
      </section>

    </Layout>
  );
}

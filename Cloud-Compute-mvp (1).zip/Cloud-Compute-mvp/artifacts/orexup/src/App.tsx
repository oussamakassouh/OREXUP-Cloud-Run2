import { useEffect, useState } from "react";
import { Switch, Route, Router as WouterRouter, Redirect } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "@/components/theme-provider";
import { AppProvider } from "@/lib/app-context";
import { UserAuthProvider, useUserAuth } from "@/lib/user-auth";
import { I18nProvider } from "@/lib/i18n";

import NotFound from "@/pages/not-found";
import Home from "@/pages/home";
import SignUp from "@/pages/signup";
import SignIn from "@/pages/signin";
import VerifyEmail from "@/pages/verify-email";
import PlansPage from "@/pages/plans";

import DashboardPage from "@/pages/dashboard/index";
import ConnectCloudPage from "@/pages/dashboard/connect-cloud";
import InstallExtensionPage from "@/pages/dashboard/install-extension";
import AnalyticsPage from "@/pages/dashboard/analytics";
import BillingPage from "@/pages/dashboard/billing";
import CheckoutPage from "@/pages/dashboard/checkout";
import CheckoutSuccessPage from "@/pages/dashboard/checkout-success";
import SupportPage from "@/pages/dashboard/support";
import SettingsPage from "@/pages/dashboard/settings";
import ProfilePage from "@/pages/dashboard/profile";
import ExtensionPage from "@/pages/dashboard/extension";
import CloudSessionPage from "@/pages/dashboard/cloud-session";
import MetricsPage from "@/pages/dashboard/metrics";
import NotificationsPage from "@/pages/dashboard/notifications";
import FlowPage from "@/pages/dashboard/flow";

import AdminLoginPage from "@/pages/admin/login";
import AdminOverviewPage from "@/pages/admin/overview";
import AdminTrafficPage from "@/pages/admin/traffic";
import AdminAnalyticsPage from "@/pages/admin/analytics";
import AdminUsersPage from "@/pages/admin/users";
import AdminPaymentsPage from "@/pages/admin/payments";
import AdminPartnersPage from "@/pages/admin/partners";
import AdminSecurityPage from "@/pages/admin/security";
import AdminSettingsPage from "@/pages/admin/settings";
import AdminSupportPage from "@/pages/admin/support";
import AdminContentPage from "@/pages/admin/content";

import { PWAInstallBanner } from "@/components/pwa-install-banner";
import PrivacyPage from "@/pages/privacy";
import TermsPage from "@/pages/terms";
import SecurityPagePublic from "@/pages/security-page";
import CookiesPage from "@/pages/cookies";
import AboutUsPage from "@/pages/about-us";
import BlogPage from "@/pages/blog";
import BlogPostPage from "@/pages/blog-post";
import CareersPage from "@/pages/careers";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: 1,
      staleTime: 30_000,
    },
  },
});

const BASE = import.meta.env.BASE_URL?.replace(/\/$/, "") ?? "";

function ProtectedRoute({ component: Component }: { component: React.ComponentType }) {
  const { isAuthenticated, isLoading } = useUserAuth();
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="h-6 w-6 rounded-full border-2 border-primary border-t-transparent animate-spin" />
      </div>
    );
  }
  if (!isAuthenticated) return <Redirect to="/signin" />;
  return <Component />;
}

function AdminProtectedRoute({ component: Component }: { component: React.ComponentType }) {
  const [status, setStatus] = useState<"loading" | "ok" | "denied">("loading");

  useEffect(() => {
    let cancelled = false;
    let retryTimer: ReturnType<typeof setTimeout> | null = null;
    async function checkSession(attempt = 0) {
      try {
        const r = await fetch(`${BASE}/api/admin/me`, { credentials: "include" });
        if (cancelled) return;
        if (r.ok) { setStatus("ok"); return; }
        if (attempt === 0) { retryTimer = setTimeout(() => checkSession(1), 800); return; }
        setStatus("denied");
      } catch {
        if (cancelled) return;
        if (attempt === 0) { retryTimer = setTimeout(() => checkSession(1), 800); return; }
        setStatus("denied");
      }
    }
    checkSession();
    return () => { cancelled = true; if (retryTimer) clearTimeout(retryTimer); };
  }, []);

  if (status === "loading") {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#0a0f16]">
        <div className="h-6 w-6 rounded-full border-2 border-primary border-t-transparent animate-spin" />
      </div>
    );
  }
  if (status === "denied") return <Redirect to="/administrator/login" />;
  return <Component />;
}

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/signup" component={SignUp} />
      <Route path="/signin" component={SignIn} />
      <Route path="/verify-email" component={VerifyEmail} />
      <Route path="/plans" component={PlansPage} />

      <Route path="/dashboard">{() => <ProtectedRoute component={DashboardPage} />}</Route>
      <Route path="/dashboard/connect-cloud">{() => <ProtectedRoute component={ConnectCloudPage} />}</Route>
      <Route path="/dashboard/install-extension">{() => <ProtectedRoute component={InstallExtensionPage} />}</Route>
      <Route path="/dashboard/extension">{() => <ProtectedRoute component={ExtensionPage} />}</Route>
      <Route path="/dashboard/cloud-session">{() => <ProtectedRoute component={CloudSessionPage} />}</Route>
      <Route path="/dashboard/metrics">{() => <ProtectedRoute component={MetricsPage} />}</Route>
      <Route path="/dashboard/notifications">{() => <ProtectedRoute component={NotificationsPage} />}</Route>
      <Route path="/dashboard/flow">{() => <ProtectedRoute component={FlowPage} />}</Route>
      <Route path="/dashboard/analytics">{() => <ProtectedRoute component={AnalyticsPage} />}</Route>
      <Route path="/dashboard/billing">{() => <ProtectedRoute component={BillingPage} />}</Route>
      <Route path="/dashboard/checkout/success">{() => <ProtectedRoute component={CheckoutSuccessPage} />}</Route>
      <Route path="/dashboard/checkout">{() => <ProtectedRoute component={CheckoutPage} />}</Route>
      <Route path="/dashboard/support">{() => <ProtectedRoute component={SupportPage} />}</Route>
      <Route path="/dashboard/settings">{() => <ProtectedRoute component={SettingsPage} />}</Route>
      <Route path="/dashboard/profile">{() => <ProtectedRoute component={ProfilePage} />}</Route>

      <Route path="/administrator/login" component={AdminLoginPage} />
      <Route path="/administrator/overview">{() => <AdminProtectedRoute component={AdminOverviewPage} />}</Route>
      <Route path="/administrator/traffic">{() => <AdminProtectedRoute component={AdminTrafficPage} />}</Route>
      <Route path="/administrator/analytics">{() => <AdminProtectedRoute component={AdminAnalyticsPage} />}</Route>
      <Route path="/administrator/users">{() => <AdminProtectedRoute component={AdminUsersPage} />}</Route>
      <Route path="/administrator/payments">{() => <AdminProtectedRoute component={AdminPaymentsPage} />}</Route>
      <Route path="/administrator/partners">{() => <AdminProtectedRoute component={AdminPartnersPage} />}</Route>
      <Route path="/administrator/security">{() => <AdminProtectedRoute component={AdminSecurityPage} />}</Route>
      <Route path="/administrator/settings">{() => <AdminProtectedRoute component={AdminSettingsPage} />}</Route>
      <Route path="/administrator/support">{() => <AdminProtectedRoute component={AdminSupportPage} />}</Route>
      <Route path="/administrator/content">{() => <AdminProtectedRoute component={AdminContentPage} />}</Route>

      <Route path="/privacy" component={PrivacyPage} />
      <Route path="/terms" component={TermsPage} />
      <Route path="/security" component={SecurityPagePublic} />
      <Route path="/cookies" component={CookiesPage} />
      <Route path="/about-us" component={AboutUsPage} />
      <Route path="/blog/:id" component={BlogPostPage} />
      <Route path="/blog" component={BlogPage} />
      <Route path="/careers" component={CareersPage} />

      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ThemeProvider defaultTheme="light" storageKey="vite-ui-theme">
      <I18nProvider>
      <UserAuthProvider>
        <AppProvider>
          <QueryClientProvider client={queryClient}>
            <TooltipProvider>
              <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
                <Router />
              </WouterRouter>
              <Toaster />
              <PWAInstallBanner />
            </TooltipProvider>
          </QueryClientProvider>
        </AppProvider>
      </UserAuthProvider>
      </I18nProvider>
    </ThemeProvider>
  );
}

export default App;
